java -cp bin/ org.cyrano.xclass.tools.SourceGenerator $1 $2 $3 $4
