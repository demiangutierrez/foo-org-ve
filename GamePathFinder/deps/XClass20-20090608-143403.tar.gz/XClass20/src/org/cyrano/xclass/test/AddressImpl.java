/*
 * Created on Nov 15, 2003
 */
package org.cyrano.xclass.test;

import java.io.Serializable;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class AddressImpl implements Address, Serializable
{
	private int id;

	private String country;

	private String city;

	private String street;

	private byte houseNo;

	/**
	 *
	 */
	public AddressImpl()
	{
		// Empty
	}

	/*
	 * Get / set methods for id
	 */

	/**
	 *
	 */
	public int getId()
	{
		return id;
	}

	/**
	 *
	 */
	public void setId(int id)
	{
		this.id = id;
	}

	/*
	 * Get / set methods for country
	 */

	/**
	 *
	 */
	public String getCountry()
	{
		return country;
	}

	/**
	 *
	 */
	public void setCountry(String country)
	{
		this.country = country;
	}

	/*
	 * Get / set methods for city
	 */

	/**
	 *
	 */
	public String getCity()
	{
		return city;
	}

	/**
	 *
	 */
	public void setCity(String city)
	{
		this.city = city;
	}

	/*
	 * Get / set methods for street
	 */

	/**
	 *
	 */
	public String getStreet()
	{
		return street;
	}

	/**
	 *
	 */
	public void setStreet(String street)
	{
		this.street = street;
	}

	/*
	 * Get / set methods for houseNo
	 */

	/**
	 *
	 */
	public byte getHouseNo()
	{
		return houseNo;
	}

	/**
	 *
	 */
	public void setHouseNo(byte houseNo)
	{
		this.houseNo = houseNo;
	}
}
