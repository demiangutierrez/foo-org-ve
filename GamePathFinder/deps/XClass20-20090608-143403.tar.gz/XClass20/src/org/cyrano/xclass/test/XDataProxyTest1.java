/*
 * Created on Apr 8, 2004
 */
package org.cyrano.xclass.test;

import java.lang.reflect.Proxy;

import org.cyrano.xclass.base.XDataObject;
import org.cyrano.xclass.base.XDataProxy;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class XDataProxyTest1
{
	/**
	 *
	 */
	public XDataProxyTest1()
	{
		// Empy
	}

	/**
	 *
	 */
	public static void main(String[] args) throws Exception
	{
		Address address = null;

		try
		{
			address = (Address) XDataProxy.createXDataProxy(Address.class);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		address.setId(10);
		System.err.println(address.getId());

		address.setCountry("Venezuela");
		System.err.println(address.getCountry());

		address.setCity("Merida");
		System.err.println(address.getCity());

		address.setStreet("Mucunutan");
		System.err.println(address.getCity());

		address.setHouseNo((byte) 5);
		System.err.println(address.getHouseNo());

		Proxy p = (Proxy) address;
		XDataObject xdo = (XDataObject) Proxy.getInvocationHandler(address);

		System.err.println(address);
		System.err.println(address.getClass());
		System.err.println(address instanceof Address);
		System.err.println(address instanceof Proxy);

		Address address2 = new AddressImpl();

		System.err.println(address2);
		System.err.println(address2.getClass());
		System.err.println(address2 instanceof Address);
		System.err.println(address2 instanceof Proxy);
	}
}
