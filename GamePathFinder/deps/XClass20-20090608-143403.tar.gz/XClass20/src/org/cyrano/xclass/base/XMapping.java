/*
 * Created on Oct 7, 2003
 */
package org.cyrano.xclass.base;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class XMapping
{
	private Map xClassMap = new HashMap();

	/**
	 *
	 */
	public XMapping()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// Get / Set methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Map getXClassMap()
	{
		return xClassMap;
	}

	/**
	 *
	 *
	 * @param xClassMap
	 */
	public void setXClassMap(Map xClassMap)
	{
		this.xClassMap = xClassMap;
	}

	// --------------------------------------------------------------------------------
	// xClassMap methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param xClass
	 */
	public void addXClass(XClass xClass)
	{
		xClassMap.put(xClass.getName(), xClass);
	}

	/**
	 *
	 *
	 * @param name
	 *
	 * @return
	 */
	public XClass getXClass(String name)
	{
		return (XClass) xClassMap.get(name);
	}

	/**
	 *
	 *
	 * @param name
	 *
	 * @return
	 */
	public XClass delXClass(String name)
	{
		return (XClass) xClassMap.remove(name);
	}

	/**
	 *
	 *
	 * @return
	 */
	public Iterator xClassIterator()
	{
		return xClassMap.values().iterator();
	}

	/**
	 *
	 *
	 * @return
	 */
	public XClass[] toXClassArray()
	{
		return (XClass[]) xClassMap.values().toArray(new XClass[0]);
	}
}
