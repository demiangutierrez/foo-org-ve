/*
 * Generated automatically by Source Generator on Thu May 27 20:19:57 VET 2004
 */
package org.cyrano.xclass.test;

import java.beans.PropertyVetoException;

/**
 *
 */
public interface Address
{
	/*
	 * Get / set methods for id
	 */

	/**
	 *
	 */
	public int getId();

	/**
	 *
	 */
	public void setId(int id) throws PropertyVetoException;

	/*
	 * Get / set methods for country
	 */

	/**
	 *
	 */
	public String getCountry();

	/**
	 *
	 */
	public void setCountry(String country) throws PropertyVetoException;

	/*
	 * Get / set methods for city
	 */

	/**
	 *
	 */
	public String getCity();

	/**
	 *
	 */
	public void setCity(String city) throws PropertyVetoException;

	/*
	 * Get / set methods for street
	 */

	/**
	 *
	 */
	public String getStreet();

	/**
	 *
	 */
	public void setStreet(String street) throws PropertyVetoException;

	/*
	 * Get / set methods for houseNo
	 */

	/**
	 *
	 */
	public byte getHouseNo();

	/**
	 *
	 */
	public void setHouseNo(byte houseNo) throws PropertyVetoException;
}
