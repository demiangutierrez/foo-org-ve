package org.cyrano.xclass.test;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import org.cyrano.xclass.base.XDataObject;
import org.cyrano.xclass.base.XMapping;
import org.cyrano.xclass.base.XMappingFactory;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class XMappingTest
{
	/**
	 *
	 */
	public XMappingTest()
	{
		// Empty
	}

	/**
	 *
	 */
	public static void main(String[] args)
	{
		System.err.println("Begin...");

		XMapping xMapping = new XMapping();

		InputStream inputStream;
		OutputStream outputStream;

		try
		{
			inputStream = XMappingTest.class.getResourceAsStream("mapping_in_A.xml");
			xMapping = XMappingFactory.load(inputStream);

			outputStream = new FileOutputStream("mapping_out_A.xml");
			XMappingFactory.save(outputStream, xMapping);

			inputStream = XMappingTest.class.getResourceAsStream("mapping_in_B.xml");
			xMapping = XMappingFactory.load(inputStream, xMapping);

			outputStream = new FileOutputStream("mapping_out_B.xml");
			XMappingFactory.save(outputStream, xMapping);

			AddressImpl address = new AddressImpl();

			xMapping = XMappingFactory.load(address);
			outputStream = new FileOutputStream("mapping_out_C.xml");
			XMappingFactory.save(outputStream, xMapping);

			xMapping = XMappingFactory.load(AddressImpl.class);
			outputStream = new FileOutputStream("mapping_out_D.xml");
			XMappingFactory.save(outputStream, xMapping);

			XDataObject dataObject = new XDataObject();
			dataObject.setType("org.cyrano.xclass.test.AddressImpl");

			xMapping = XMappingFactory.load(dataObject);
			outputStream = new FileOutputStream("mapping_out_E.xml");
			XMappingFactory.save(outputStream, xMapping);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		System.err.println("End...");
	}
}
