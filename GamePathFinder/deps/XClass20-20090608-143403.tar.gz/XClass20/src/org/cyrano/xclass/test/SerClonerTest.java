/*
 * Created on Nov 19, 2003
 */
package org.cyrano.xclass.test;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

/**
 * Do not erase
 * Shows how to serialize an object to a PipedOutputStream and
 * read it from a PipedInputStream. This is usefull to clone objects.
 *
 * If one object does not implements cloneable but it is serializable
 * this this class can clone it.
 *
 * The inconvenient of this is the need of use Threads with Piped Streams.
 * An adapter must be done for CloneableMap to work
 *
 * @author DMI: Demian Gutierrez
 */
public class SerClonerTest implements Runnable
{
	private PipedOutputStream pos;

	private PipedInputStream pis;

	private AddressImpl aBeg;

	private AddressImpl aEnd;

	private Integer iBeg;

	private Integer iEnd;

	/**
	 *
	 */
	public SerClonerTest()
	{
		try
		{
			pos = new PipedOutputStream();
			pis = new PipedInputStream(pos);

			ObjectOutputStream oos = new ObjectOutputStream(pos);

			aBeg = new AddressImpl();
			oos.writeObject(aBeg);

			iBeg = new Integer(10);
			oos.writeObject(iBeg);

			Thread th = new Thread(this);
			th.start();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	/**
	 *
	 */
	public void run()
	{
		try
		{
			ObjectInputStream ois = new ObjectInputStream(pis);

			aEnd = (AddressImpl) ois.readObject();
			System.err.println(aEnd);
			System.err.println(aBeg == aEnd);
			System.err.println(aBeg.equals(aEnd));

			iEnd = (Integer) ois.readObject();
			System.err.println(iEnd);
			System.err.println(iBeg == iEnd);
			System.err.println(iEnd.equals(iEnd));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	/**
	 *
	 *
	 * @param args
	 */
	public static void main(String[] args)
	{
		new SerClonerTest();
	}
}
