/*
 * Created on Oct 6, 2003
 */
package org.cyrano.xclass.base;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class XExtension
{
	private String name;

	private Map xPropertyMap = new HashMap();

	private Vector propertyOrder;

	/**
	 *
	 */
	public XExtension()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// Get / Set methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public String getName()
	{
		return name;
	}

	/**
	 *
	 *
	 * @param name
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Map getXPropertyMap()
	{
		return xPropertyMap;
	}

	/**
	 *
	 *
	 * @param xPropertyMap
	 */
	public void setXPropertyMap(Map xPropertyMap)
	{
		this.xPropertyMap = xPropertyMap;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Vector getPropertyOrder()
	{
		return propertyOrder;
	}

	/**
	 *
	 *
	 * @param propertyOrder
	 */
	public void setPropertyOrder(Vector propertyOrder)
	{
		this.propertyOrder = propertyOrder;
	}

	// --------------------------------------------------------------------------------
	// xPropertyMap methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param xProperty
	 */
	public void addXProperty(XProperty xProperty)
	{
		xPropertyMap.put(xProperty.getKey(), xProperty);
	}

	/**
	 *
	 *
	 * @param key
	 *
	 * @return
	 */
	public XProperty getXProperty(String key)
	{
		return (XProperty) xPropertyMap.get(key);
	}

	/**
	 *
	 *
	 * @param key
	 *
	 * @return
	 */
	public XProperty delXProperty(String key)
	{
		return (XProperty) xPropertyMap.remove(key);
	}

	/**
	 *
	 *
	 * @return
	 */
	public Iterator xPropertyIterator()
	{
		return xPropertyMap.values().iterator();
	}

	/**
	 *
	 *
	 * @return
	 */
	public XProperty[] toXPropertyArray()
	{
		return (XProperty[]) xPropertyMap.values().toArray(new XProperty[0]);
	}
}
