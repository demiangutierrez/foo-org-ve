package org.cyrano.xclass.util;

import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class Messages
{
	private ResourceBundle resourceBundle;

	/**
	 * Constructor for Messages.
	 */
	public Messages(String resourceName)
	{
		resourceBundle = ResourceBundle.getBundle(resourceName);
	}

	/**
	 *
	 */
	public String getString(String key)
	{
		String ret;

		try
		{
			ret = resourceBundle.getString(key);
		}
		catch (MissingResourceException e)
		{
			ret = "# " + key;
		}

		return ret.trim();
	}

	/**
	 *
	 */
	public String getString(String key, Object[] obj)
	{
		String ret;

		try
		{
			ret = resourceBundle.getString(key);

			MessageFormat.format(ret, obj);
		}
		catch (MissingResourceException e)
		{
			StringBuffer str = new StringBuffer("# ");

			str.append(key);
			str.append(": ");

			for (int i = 0; i < obj.length; i++)
			{
				str.append(obj[i]);

				if (i < obj.length - 1)
				{
					str.append(", ");
				}
			}

			ret = str.toString();
		}

		return ret.trim();
	}

	/**
	 *
	 */
	public String getString(String key, Object obj1)
	{
		return getString(key, new Object[] { obj1 });
	}

	/**
	 *
	 */
	public String getString(String key, Object obj1, Object obj2)
	{
		return getString(key, new Object[] { obj1, obj2 });
	}

	/**
	 *
	 */
	public String getString(String key, Object obj1, Object obj2, Object obj3)
	{
		return getString(key, new Object[] { obj1, obj2, obj3 });
	}
}
