/*
 * Created on Apr 8, 2004
 */
package org.cyrano.xclass.test;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;
import java.io.InputStream;
import java.lang.reflect.Proxy;
import java.lang.reflect.UndeclaredThrowableException;

import org.cyrano.xclass.base.XDataObject;
import org.cyrano.xclass.base.XDataProxy;
import org.cyrano.xclass.base.XMapping;
import org.cyrano.xclass.base.XMappingFactory;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class XDataProxyTest3
{
	/**
	 *
	 */
	public XDataProxyTest3()
	{
		// Empy
	}

	/**
	 *
	 */
	public static void main(String[] args)
	{
		Address address = null;

		InputStream inputStream = XMappingTest.class.getResourceAsStream("AddressImpl.xml");

		XMapping xMapping = null;

		try
		{
			xMapping = XMappingFactory.load(inputStream);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		try
		{
			address =
				(Address) XDataProxy.createXDataProxy(
					Address.class,
					xMapping.getXClass("org.cyrano.xclass.test.AddressImpl"));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		XDataObject xdo = (XDataObject) Proxy.getInvocationHandler(address);

		xdo.addVetoableChangeListener(new VetoableChangeListener()
		{
			public void vetoableChange(PropertyChangeEvent evt) throws PropertyVetoException
			{
				// Veto all
				throw new PropertyVetoException("", evt);
			}
		});

		try
		{
			address.setId(10);
		}
		catch (UndeclaredThrowableException e)
		{
			System.err.println("This is ok : " + e.getMessage());
		}
		catch (PropertyVetoException e)
		{
			System.err.println("Empty");
		}

		System.err.println(address.getId());

		try
		{
			address.setCountry("Venezuela");
		}
		catch (UndeclaredThrowableException e)
		{
			System.err.println("This is ok : " + e.getMessage());
		}
		catch (PropertyVetoException e)
		{
			System.err.println("Empty");
		}

		System.err.println(address.getCountry());

		try
		{
			address.setStreet("Merida");
		}
		catch (UndeclaredThrowableException e)
		{
			System.err.println("This is ok : " + e.getMessage());
		}
		catch (PropertyVetoException e)
		{
			System.err.println("Empty");
		}

		System.err.println(address.getStreet());

		try
		{
			address.setStreet("Mucunutan");
		}
		catch (UndeclaredThrowableException e)
		{
			System.err.println("This is ok : " + e.getMessage());
		}
		catch (PropertyVetoException e)
		{
			System.err.println("Empty");
		}

		System.err.println(address.getStreet());

		try
		{
			address.setHouseNo((byte) 5);
		}
		catch (UndeclaredThrowableException e)
		{
			System.err.println("This is ok : " + e.getMessage());
		}
		catch (PropertyVetoException e)
		{
			System.err.println("Empty");
		}

		System.err.println(address.getHouseNo());
	}
}
