/*
 * Generated automatically by Source Generator on Thu May 27 20:19:57 VET 2004
 */
package org.cyrano.xclass.test;

import java.beans.PropertyVetoException;
import java.util.Date;

/**
 *
 */
public interface Employee
{
	/*
	 * Get / set methods for id
	 */

	/**
	 *
	 */
	public int getId();

	/**
	 *
	 */
	public void setId(int id) throws PropertyVetoException;

	/*
	 * Get / set methods for firstName
	 */

	/**
	 *
	 */
	public String getFirstName();

	/**
	 *
	 */
	public void setFirstName(String firstName) throws PropertyVetoException;

	/*
	 * Get / set methods for lastName
	 */

	/**
	 *
	 */
	public String getLastName();

	/**
	 *
	 */
	public void setLastName(String lastName) throws PropertyVetoException;

	/*
	 * Get / set methods for birth
	 */

	/**
	 *
	 */
	public Date getBirth();

	/**
	 *
	 */
	public void setBirth(Date birth) throws PropertyVetoException;
}
