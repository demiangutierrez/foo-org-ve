/*
 * Created on Oct 7, 2003
 */
package org.cyrano.xclass.base;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.MessageFormat;
import java.util.Iterator;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.cyrano.xclass.handlers.XMappingHandler;
import org.xml.sax.SAXException;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class XMappingFactory
{
	/**
	 *
	 */
	private XMappingFactory()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param object
	 *
	 * @return
	 */
	public static XMapping load(Object object) throws SAXException, ParserConfigurationException, IOException
	{
		XMapping xMapping = new XMapping();

		return load(object, xMapping, null);
	}

	/**
	 *
	 *
	 * @param object
	 * @param cl
	 *
	 * @return
	 */
	public static XMapping load(Object object, ClassLoader cl)
		throws SAXException, ParserConfigurationException, IOException
	{
		XMapping xMapping = new XMapping();

		return load(object, xMapping, cl);
	}

	/**
	 *
	 *
	 * @param object
	 * @param xMapping
	 *
	 * @return
	 */
	public static XMapping load(Object object, XMapping xMapping)
		throws SAXException, ParserConfigurationException, IOException
	{
		return load(object, xMapping, null);
	}

	/**
	 *
	 *
	 * @param object
	 * @param xMapping
	 * @param cl
	 *
	 * @return
	 */
	public static XMapping load(Object object, XMapping xMapping, ClassLoader cl)
		throws SAXException, ParserConfigurationException, IOException
	{
		String resName;

		if (object instanceof XDataObject)
		{
			XDataObject dataObject = (XDataObject) object;

			resName = dataObject.getType().replace('.', '/') + ".xml";
		}
		else if (object instanceof Class)
		{
			Class clazz = (Class) object;

			resName = clazz.getName().replace('.', '/') + ".xml";
		}
		else if (object instanceof String)
		{
			String name = (String) object;

			resName = name.replace('.', '/') + ".xml";
		}
		else
		{
			resName = object.getClass().getName().replace('.', '/') + ".xml";
		}

		if (cl == null)
		{
			return load(ClassLoader.getSystemResourceAsStream(resName), xMapping);
		}
		else
		{
			return load(cl.getResourceAsStream(resName), xMapping);
		}
	}

	/**
	 *
	 *
	 * @param inputStream
	 *
	 * @return
	 */
	public static XMapping load(InputStream inputStream) throws SAXException, ParserConfigurationException, IOException
	{
		XMapping xMapping = new XMapping();

		return load(inputStream, xMapping);
	}

	/**
	 *
	 *
	 * @param inputStream
	 * @param xMapping
	 *
	 * @return
	 */
	public static XMapping load(InputStream inputStream, XMapping xMapping)
		throws SAXException, ParserConfigurationException, IOException
	{
		SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
		XMappingHandler handler = new XMappingHandler(xMapping);
		parser.parse(inputStream, handler);

		return xMapping;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param writer
	 * @param xProperty
	 * @param indent
	 */
	private static void saveXProperty(PrintWriter writer, XProperty xProperty, int indent)
	{
		StringBuffer indentStr = new StringBuffer();

		for (int i = 0; i < indent; i++)
		{
			indentStr.append("\t");
		}

		Map xPropertyMap = xProperty.getXPropertyMap();

		if (!xPropertyMap.isEmpty() || xProperty.getText() != null)
		{
			writer.println(
				MessageFormat.format(
					indentStr + "<property key=\"{0}\" value=\"{1}\">",
					new Object[] { xProperty.getKey(), xProperty.getValue()}));

			if (xProperty.getText() != null)
			{
				writer.println(xProperty.getText());
			}

			if (!xPropertyMap.isEmpty())
			{
				Iterator itt = xProperty.xPropertyIterator();

				while (itt.hasNext())
				{
					XProperty xPropertyChild = (XProperty) itt.next();

					saveXProperty(writer, xPropertyChild, indent + 1);
				}
			}

			writer.println(indentStr + "</property>");
		}
		else
		{
			writer.println(
				MessageFormat.format(
					indentStr + "<property key=\"{0}\" value=\"{1}\"/>",
					new Object[] { xProperty.getKey(), xProperty.getValue()}));
		}
	}

	/**
	 *
	 *
	 * @param outputStream
	 * @param xMapping
	 */
	public static void save(OutputStream outputStream, XMapping xMapping)
	{
		PrintWriter writer = new PrintWriter(outputStream, true);

		writer.println("<mapping>");

		Iterator xClassItt = xMapping.xClassIterator();

		while (xClassItt.hasNext())
		{
			XClass xClass = (XClass) xClassItt.next();
			writer.println(MessageFormat.format("\t<class name=\"{0}\">", new Object[] { xClass.getName()}));
			Iterator xExtensionItt = xClass.xExtensionIterator();

			while (xExtensionItt.hasNext())
			{
				XExtension xExtension = (XExtension) xExtensionItt.next();
				writer.println(
					MessageFormat.format("\t\t<extension name=\"{0}\">", new Object[] { xExtension.getName()}));

				Iterator xPropertyItt = xExtension.xPropertyIterator();

				while (xPropertyItt.hasNext())
				{
					XProperty xProperty = (XProperty) xPropertyItt.next();

					saveXProperty(writer, xProperty, 3);
				}

				writer.println("\t\t</extension>");
			}

			Iterator xFieldItt = xClass.xFieldIterator();

			while (xFieldItt.hasNext())
			{
				XField xField = (XField) xFieldItt.next();
				writer.println(
					MessageFormat.format(
						"\t\t<field name=\"{0}\" type=\"{1}\">",
						new Object[] { xField.getName(), xField.getType()}));
				xExtensionItt = xField.xExtensionIterator();

				while (xExtensionItt.hasNext())
				{
					XExtension xExtension = (XExtension) xExtensionItt.next();
					writer.println(
						MessageFormat.format("\t\t\t<extension name=\"{0}\">", new Object[] { xExtension.getName()}));

					Iterator xPropertyItt = xExtension.xPropertyIterator();

					while (xPropertyItt.hasNext())
					{
						XProperty xProperty = (XProperty) xPropertyItt.next();

						saveXProperty(writer, xProperty, 4);
					}

					writer.println("\t\t\t</extension>");
				}

				writer.println("\t\t</field>");
			}

			writer.println("\t</class>");
		}

		writer.println("</mapping>");
	}
}
