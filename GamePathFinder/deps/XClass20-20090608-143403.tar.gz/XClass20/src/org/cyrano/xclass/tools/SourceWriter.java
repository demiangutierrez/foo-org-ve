/*
 * Created on Sep 18, 2003
 */
package org.cyrano.xclass.tools;

import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class SourceWriter
{
	public static final String PUBLIC = "public";

	public static final String PROTECTED = "protected";

	public static final String PRIVATE = "private";

	public static final String STATIC = "static";

	public static final String FINAL = "final";

	private Vector primitiveDataTypes = new Vector();

	private PrintWriter writer;

	private int indentationLevel;

	private String indentationString = "\t";

	/**
	 *
	 */
	public SourceWriter()
	{
		primitiveDataTypes.add("boolean");
		primitiveDataTypes.add("char");
		primitiveDataTypes.add("byte");
		primitiveDataTypes.add("short");
		primitiveDataTypes.add("int");
		primitiveDataTypes.add("long");
		primitiveDataTypes.add("float");
		primitiveDataTypes.add("double");
	}

	// --------------------------------------------------------------------------------
	// Comment writers
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param comment
	 */
	public void cStyleComment(Vector comment)
	{
		writer.println(getIndentation() + "/*");

		Enumeration en = comment.elements();

		while (en.hasMoreElements())
		{
			String currentComment = (String) en.nextElement();

			if ((currentComment == null) || currentComment.equals(""))
			{
				writer.println(getIndentation() + " *");
			}
			else
			{
				writer.println(getIndentation() + " * " + currentComment);
			}
		}

		writer.println(getIndentation() + " */");
	}

	/**
	 *
	 *
	 * @param comment
	 */
	public void singleLineComment(Vector comment)
	{
		Enumeration en = comment.elements();

		while (en.hasMoreElements())
		{
			String currentComment = (String) en.nextElement();

			if ((currentComment == null) || currentComment.equals(""))
			{
				writer.println(getIndentation() + "//");
			}
			else
			{
				writer.println(getIndentation() + "// " + currentComment);
			}
		}
	}

	/**
	 *
	 *
	 * @param comment
	 */
	public void documentationComment(Vector comment)
	{
		writer.println(getIndentation() + "/**");

		Enumeration en = comment.elements();

		while (en.hasMoreElements())
		{
			String currentComment = (String) en.nextElement();

			if ((currentComment == null) || currentComment.equals(""))
			{
				writer.println(getIndentation() + " *");
			}
			else
			{
				writer.println(getIndentation() + " * " + currentComment);
			}
		}

		writer.println(getIndentation() + " */");
	}

	// --------------------------------------------------------------------------------
	// Statement writers
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param className
	 */
	public void packageStatement(String className)
	{
		if (!getPackageName(className).equals(""))
		{
			writer.println("package " + getPackageName(className) + ";");
			writer.println();
		}
	}

	/**
	 *
	 *
	 * @param typeSet
	 */
	public void importStatement(Set typeSet)
	{
		String importPrefix = null;

		Iterator itt = typeSet.iterator();

		while (itt.hasNext())
		{
			String importString = (String) itt.next();

			if (primitiveDataTypes.contains(importString) || getPackageName(importString).equals("java.lang"))
			{
				itt.remove();
			}
		}

		itt = typeSet.iterator();

		while (itt.hasNext())
		{
			String importString = (String) itt.next();

			if (importPrefix == null)
			{
				importPrefix = getDotPrefix(importString, 1);
			}
			else if (!importPrefix.equals(getDotPrefix(importString, 1)))
			{
				writer.println();

				importPrefix = getDotPrefix(importString, 1);
			}

			writer.println("import " + importString + ";");
		}

		if (!typeSet.isEmpty())
		{
			writer.println();
		}
	}

	/**
	 *
	 *
	 * @param modifiers
	 * @param className
	 * @param extendsName
	 * @param implementsVector
	 */
	public void classStatement(Vector modifiers, String className, String extendsName, Vector implementsVector)
	{
		writer.print(getIndentation());

		if (modifiers != null)
		{
			Enumeration en = modifiers.elements();

			while (en.hasMoreElements())
			{
				String modifier = (String) en.nextElement();

				writer.print(modifier + " ");
			}
		}

		writer.print("class " + getClassName(className));

		if (extendsName != null)
		{
			writer.print(" extends " + getClassName(extendsName));
		}

		if ((implementsVector != null) && !implementsVector.isEmpty())
		{
			writer.print(" implements ");

			Enumeration en = implementsVector.elements();

			while (en.hasMoreElements())
			{
				String implementsName = (String) en.nextElement();

				writer.print(getClassName(implementsName));

				if (en.hasMoreElements())
				{
					writer.print(", ");
				}
			}
		}
	}

	/**
	 *
	 *
	 * @param modifiers
	 * @param interfaceName
	 * @param extendsVector
	 */
	public void interfaceStatement(Vector modifiers, String interfaceName, Vector extendsVector)
	{
		writer.print(getIndentation());

		if (modifiers != null)
		{
			Enumeration en = modifiers.elements();

			while (en.hasMoreElements())
			{
				String modifier = (String) en.nextElement();

				writer.print(modifier + " ");
			}
		}

		writer.print("interface " + getClassName(interfaceName));

		if ((extendsVector != null) && !extendsVector.isEmpty())
		{
			writer.print(" extends ");

			Enumeration en = extendsVector.elements();

			while (en.hasMoreElements())
			{
				String extendsName = (String) en.nextElement();

				writer.print(getClassName(extendsName));

				if (en.hasMoreElements())
				{
					writer.print(", ");
				}
			}
		}
	}

	/**
	 *
	 *
	 * @param modifiers
	 * @param returnType
	 * @param methodName
	 * @param arguments
	 * @param throwsVector
	 */
	public void methodStatement(
		Vector modifiers,
		String returnType,
		String methodName,
		Vector arguments,
		Vector throwsVector)
	{
		writer.print(getIndentation());

		if (modifiers != null)
		{
			Enumeration en = modifiers.elements();

			while (en.hasMoreElements())
			{
				String modifier = (String) en.nextElement();

				writer.print(modifier + " ");
			}
		}

		if (returnType != null)
		{
			writer.print(getClassName(returnType) + " ");
		}

		writer.print(methodName + "(");

		if ((arguments != null) && !arguments.isEmpty())
		{
			Enumeration en = arguments.elements();

			while (en.hasMoreElements())
			{
				Argument argument = (Argument) en.nextElement();

				writer.print(getClassName(argument.getType()) + " " + argument.getName());

				if (en.hasMoreElements())
				{
					writer.print(", ");
				}
			}
		}

		writer.print(")");

		if ((throwsVector != null) && !throwsVector.isEmpty())
		{
			writer.print(" throws ");

			Enumeration en = throwsVector.elements();

			while (en.hasMoreElements())
			{
				String throwsString = (String) en.nextElement();

				writer.print(getClassName(throwsString));

				if (en.hasMoreElements())
				{
					writer.print(", ");
				}
			}
		}
	}

	// --------------------------------------------------------------------------------
	// Curly writers
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param nextLine
	 */
	public void beginCurly(boolean nextLine)
	{
		if (nextLine)
		{
			writer.println();
			writer.println(getIndentation() + "{");
		}
		else
		{
			writer.println(" {");
		}

		indentationLevel++;
	}

	/**
	 *
	 */
	public void endCurly()
	{
		indentationLevel--;

		writer.println(getIndentation() + "}");
	}

	// --------------------------------------------------------------------------------
	// Misc methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public String getIndentation()
	{
		StringBuffer ret = new StringBuffer();

		for (int i = 0; i < indentationLevel; i++)
		{
			ret.append(indentationString);
		}

		return ret.toString();
	}

	/**
	 *
	 *
	 * @param fullClassName
	 *
	 * @return
	 */
	public String getClassName(String fullClassName)
	{
		int dot = fullClassName.lastIndexOf('.');

		if (dot != -1)
		{
			return fullClassName.substring(dot + 1);
		}

		return fullClassName;
	}

	/**
	 *
	 *
	 * @param fullClassName
	 *
	 * @return
	 */
	public String getPackageName(String fullClassName)
	{
		int dot = fullClassName.lastIndexOf('.');

		if (dot != -1)
		{
			return fullClassName.substring(0, dot);
		}

		return "";
	}

	/**
	 *
	 *
	 * @param string
	 * @param dotCount
	 *
	 * @return
	 */
	public String getDotPrefix(String string, int dotCount)
	{
		int dot = -1;

		for (int i = 0; i < dotCount; i++)
		{
			dot = string.indexOf('.', dot + 1);
		}

		if (dot == -1)
		{
			return "";
		}

		return string.substring(0, dot);
	}

	// --------------------------------------------------------------------------------
	// Get / Set methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public PrintWriter getWriter()
	{
		return writer;
	}

	/**
	 *
	 *
	 * @param writer
	 */
	public void setWriter(PrintWriter writer)
	{
		this.writer = writer;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public int getIndentationLevel()
	{
		return indentationLevel;
	}

	/**
	 *
	 *
	 * @param indentationLevel
	 */
	public void setIndentationLevel(int indentationLevel)
	{
		this.indentationLevel = indentationLevel;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public String getIndentationString()
	{
		return indentationString;
	}

	/**
	 *
	 *
	 * @param indentationString
	 */
	public void setIndentationString(String indentationString)
	{
		this.indentationString = indentationString;
	}
}
