/*
 * Created on Oct 6, 2003
 */
package org.cyrano.xclass.exceptions;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class PropertyNotFoundException extends RuntimeException
{
	/**
	 *
	 */
	public PropertyNotFoundException()
	{
		super();
	}

	/**
	 *
	 */
	public PropertyNotFoundException(String message)
	{
		super(message);
	}

	/**
	 *
	 */
	public PropertyNotFoundException(String message, Throwable cause)
	{
		super(message, cause);
	}

	/**
	 *
	 */
	public PropertyNotFoundException(Throwable cause)
	{
		super(cause);
	}
}
