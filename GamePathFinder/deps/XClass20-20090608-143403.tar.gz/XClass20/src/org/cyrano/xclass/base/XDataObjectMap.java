/*
 * Created on Sep 12, 2004
 */
package org.cyrano.xclass.base;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class XDataObjectMap extends XDataMonitorImpl
{
	private Map xDataObjectMap = new HashMap();

	/**
	 *
	 */
	private PropertyChangeListener propertyChangeListener = new PropertyChangeListener()
	{
		public void propertyChange(PropertyChangeEvent evt)
		{
			firePropertyChange(evt);
		}
	};

	/**
	 *
	 */
	public XDataObjectMap()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// Get / Set methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Map getXDataObjectMap()
	{
		return xDataObjectMap;
	}

	/**
	 *
	 *
	 * @param dataObjectMap
	 */
	public void setXDataObjectMap(Map dataObjectMap)
	{
		xDataObjectMap = dataObjectMap;
	}

	// --------------------------------------------------------------------------------
	// xDataObjectMap methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param xDataObject
	 */
	public void addXDataObject(XDataObject xDataObject)
	{
		xDataObjectMap.put(xDataObject.getName(), xDataObject);

		xDataObject.addPropertyChangeListener(propertyChangeListener);
	}

	/**
	 *
	 *
	 * @param name
	 *
	 * @return
	 */
	public XDataObject getXDataObject(String name)
	{
		return (XDataObject) xDataObjectMap.get(name);
	}

	/**
	 *
	 *
	 * @param name
	 *
	 * @return
	 */
	public XDataObject delXDataObject(String name)
	{
		XDataObject ret = (XDataObject) xDataObjectMap.get(name);

		ret.delPropertyChangeListener(propertyChangeListener);

		return ret;
	}

	/**
	 *
	 *
	 * @return
	 */
	public Iterator xDataObjectIterator()
	{
		return xDataObjectMap.values().iterator();
	}

	/**
	 *
	 *
	 * @return
	 */
	public XDataObject[] toXDataObjectArray()
	{
		return (XDataObject[]) xDataObjectMap.values().toArray(new XExtension[0]);
	}
}