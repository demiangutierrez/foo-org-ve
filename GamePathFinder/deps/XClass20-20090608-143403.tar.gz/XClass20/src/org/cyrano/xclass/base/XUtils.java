/*
 * Created on Oct 6, 2003
 */
package org.cyrano.xclass.base;

import java.beans.PropertyVetoException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class XUtils
{
	private static Map primitiveWrapperClass = new HashMap();

	private static Map primitiveWrapperValue = new HashMap();

	/**
	 *
	 */
	static {

		primitiveWrapperClass.put("boolean", Boolean.class);
		primitiveWrapperClass.put("char", Character.class);
		primitiveWrapperClass.put("byte", Byte.class);
		primitiveWrapperClass.put("short", Short.class);
		primitiveWrapperClass.put("int", Integer.class);
		primitiveWrapperClass.put("long", Long.class);
		primitiveWrapperClass.put("float", Float.class);
		primitiveWrapperClass.put("double", Double.class);

		primitiveWrapperValue.put("boolean", new Boolean(false));
		primitiveWrapperValue.put("char", new Character((char) 0));
		primitiveWrapperValue.put("byte", new Byte((byte) 0));
		primitiveWrapperValue.put("short", new Short((short) 0));
		primitiveWrapperValue.put("int", new Integer(0));
		primitiveWrapperValue.put("long", new Long(0));
		primitiveWrapperValue.put("float", new Float(0));
		primitiveWrapperValue.put("double", new Double(0));
	}

	/**
	 *
	 */
	private XUtils()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param type
	 *
	 * @return
	 */
	public static String getPrimitiveWrapperName(String type)
	{
		Class ret = (Class) primitiveWrapperClass.get(type);

		return ret == null ? type : ret.getName();
	}

	/**
	 *
	 *
	 * @param type
	 *
	 * @return
	 */
	public static Class getPrimitiveWrapperClass(String type)
	{
		return (Class) primitiveWrapperClass.get(type);
	}

	/**
	 *
	 *
	 * @param type
	 *
	 * @return
	 */
	public static Object getPrimitiveWrapperValue(String type)
	{
		return primitiveWrapperValue.get(type);
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 * @param type
	 * @param value
	 *
	 * @return
	 */
	public static Object parsePrimitiveValue(String type, String value)
	{
		Object ret;

		if (type.equals("boolean") || type.equals("java.lang.Boolean"))
		{
			ret = (value == null || value.equals("")) ? getPrimitiveWrapperValue(type) : new Boolean(value);
		}
		else if (type.equals("char") || type.equals("java.lang.Character"))
		{
			ret = (value == null || value.equals("")) ? getPrimitiveWrapperValue(type) : new Character(value.charAt(0));
		}
		else if (type.equals("byte") || type.equals("java.lang.Byte"))
		{
			ret = (value == null || value.equals("")) ? getPrimitiveWrapperValue(type) : new Byte(value);
		}
		else if (type.equals("short") || type.equals("java.lang.Short"))
		{
			ret = (value == null || value.equals("")) ? getPrimitiveWrapperValue(type) : new Short(value);
		}
		else if (type.equals("int") || type.equals("java.lang.Integer"))
		{
			ret = (value == null || value.equals("")) ? getPrimitiveWrapperValue(type) : new Integer(value);
		}
		else if (type.equals("long") || type.equals("java.lang.Long"))
		{
			ret = (value == null || value.equals("")) ? getPrimitiveWrapperValue(type) : new Long(value);
		}
		else if (type.equals("float") || type.equals("java.lang.Float"))
		{
			ret = (value == null || value.equals("")) ? getPrimitiveWrapperValue(type) : new Float(value);
		}
		else if (type.equals("double") || type.equals("java.lang.Double"))
		{
			ret = (value == null || value.equals("")) ? getPrimitiveWrapperValue(type) : new Double(value);
		}
		else
		{
			ret = (value == null || value.equals("")) ? getPrimitiveWrapperValue(type) : value;
		}

		return ret;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param object
	 * @param name
	 *
	 * @return
	 *
	 * @throws NoSuchMethodException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	public static Object getProperty(Object object, String name)
		throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Object ret;

		if (object instanceof XDataObject)
		{
			XDataObject dataObject = (XDataObject) object;

			ret = dataObject.getObject(name);
		}
		else
		{
			Method method =
				object.getClass().getMethod("get" + name.substring(0, 1).toUpperCase() + name.substring(1), null);

			ret = method.invoke(object, null);
		}

		return ret;
	}

	/**
	 *
	 *
	 * @param object
	 * @param name
	 * @param value
	 *
	 *
	 * @throws NoSuchMethodException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws PropertyVetoException
	 */
	public static void setProperty(Object object, String name, Object value)
		throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, PropertyVetoException
	{
		if (object instanceof XDataObject)
		{
			XDataObject dataObject = (XDataObject) object;

			dataObject.setObject(name, value);
		}
		else
		{
			Method method =
				object.getClass().getMethod(
					"set" + name.substring(0, 1).toUpperCase() + name.substring(1),
					new Class[] { value.getClass()});

			method.invoke(object, new Object[] { value });
		}
	}
}
