/*
 * Created on Oct 6, 2003
 */
package org.cyrano.xclass.base;

import java.beans.PropertyVetoException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.cyrano.xclass.exceptions.PropertyNotFoundException;
import org.cyrano.xclass.exceptions.TypeCheckingException;
import org.cyrano.xclass.util.Messages;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class XDataObject extends XDataMonitorImpl implements Serializable
{
	protected static Messages msg = new Messages("org.cyrano.xclass.nls.XDataObject");

	private String name;

	private String type;

	private XClass xClass;

	private Map propertyMap = new HashMap();

	/**
	 *
	 */
	public XDataObject()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// Private methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param key
	 * @param value
	 */
	private void typeChecking(String key, Object value)
	{
		if (xClass == null || value == null)
		{
			return;
		}

		String type;

		XField xField = xClass.getXField(key);

		if (value instanceof XDataObject)
		{
			XDataObject dataObject = (XDataObject) value;

			type = dataObject.getType();

			if (!type.equals(XUtils.getPrimitiveWrapperName(xField.getType())))
			{
				throw new TypeCheckingException(msg.getString("type_checking", type, xField.getType()));
			}
		}
		else
		{
			type = value.getClass().getName();

			Class dstClass;
			Class srcClass;

			try
			{
				srcClass = Class.forName(type);

				dstClass = XUtils.getPrimitiveWrapperClass(xField.getType());
				dstClass = dstClass == null ? Class.forName(xField.getType()) : dstClass;
			}
			catch (ClassNotFoundException e)
			{
				// TODO: Throw this or improve it?
				throw new TypeCheckingException(e);
			}

			if (!dstClass.isAssignableFrom(srcClass))
			{
				throw new TypeCheckingException(msg.getString("type_checking", type, xField.getType()));
			}
		}
	}

	/**
	 *
	 *
	 * @param key
	 */
	private void propChecking(String key)
	{
		if (xClass == null)
		{
			return;
		}

		XField xField = xClass.getXField(key);

		if (xField == null)
		{
			throw new PropertyNotFoundException(msg.getString("prop_checking", xClass.getName(), key));
		}
	}

	/**
	 *
	 *
	 * @param key
	 * @param value
	 *
	 *  @return
	 */
	private Object nullChecking(String key, Object value)
	{
		Object ret = value;

		if (xClass == null)
		{
			return ret;
		}

		XField xField = xClass.getXField(key);

		if (value == null)
		{
			ret = XUtils.getPrimitiveWrapperValue(xField.getType());
		}

		return ret;
	}

	// --------------------------------------------------------------------------------
	// Get / Set methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public String getName()
	{
		return name;
	}

	/**
	 *
	 *
	 * @param name
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public String getType()
	{
		return type;
	}

	/**
	 *
	 *
	 * @param type
	 */
	public void setType(String type)
	{
		this.type = type;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public XClass getXClass()
	{
		return xClass;
	}

	/**
	 *
	 *
	 * @param xClass
	 */
	public void setXClass(XClass xClass)
	{
		this.xClass = xClass;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Map getPropertyMap()
	{
		return propertyMap;
	}

	/**
	 *
	 *
	 * @param propertyMap
	 */
	public void setPropertyMap(Map propertyMap)
	{
		this.propertyMap = propertyMap;
	}

	// --------------------------------------------------------------------------------
	// Property Get / Set methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param key
	 *
	 * @return
	 */
	public Object getObject(String key)
	{
		Object ret = propertyMap.get(key);

		ret = nullChecking(key, ret);

		propChecking(key);
		typeChecking(key, ret);

		return ret;
	}

	/**
	 *
	 *
	 * @param key
	 * @param newValue
	 * 
	 * @throws PropertyVetoException
	 */
	public void setObject(String key, Object newValue) throws PropertyVetoException
	{
		propChecking(key);
		typeChecking(key, newValue);

		Object oldValue = propertyMap.get(key);

		fireVetoableChange(key, oldValue, newValue);
		propertyMap.put(key, newValue);
		firePropertyChange(key, oldValue, newValue);
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public boolean getBoolean(String key)
	{
		Boolean ret = (Boolean) getObject(key);

		return ret.booleanValue();
	}

	/**
	 *
	 *
	 * @param key
	 * @param newValue
	 * 
	 * @throws PropertyVetoException
	 */
	public void setBoolean(String key, boolean newValue) throws PropertyVetoException
	{
		setObject(key, new Boolean(newValue));
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public char getCharacter(String key)
	{
		Character ret = (Character) getObject(key);

		return ret.charValue();
	}

	/**
	 *
	 *
	 * @param key
	 * @param newValue
	 * 
	 * @throws PropertyVetoException
	 */
	public void setCharacter(String key, char newValue) throws PropertyVetoException
	{
		setObject(key, new Character(newValue));
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public byte getByte(String key)
	{
		Byte ret = (Byte) getObject(key);

		return ret.byteValue();
	}

	/**
	 *
	 *
	 * @param key
	 * @param newValue
	 * 
	 * @throws PropertyVetoException
	 */
	public void setByte(String key, byte newValue) throws PropertyVetoException
	{
		setObject(key, new Byte(newValue));
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public short getShort(String key)
	{
		Short ret = (Short) getObject(key);

		return ret.shortValue();
	}

	/**
	 *
	 *
	 * @param key
	 * @param newValue
	 * 
	 * @throws PropertyVetoException
	 */
	public void setShort(String key, short newValue) throws PropertyVetoException
	{
		setObject(key, new Short(newValue));
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public int getInteger(String key)
	{
		Integer ret = (Integer) getObject(key);

		return ret.intValue();
	}

	/**
	 *
	 *
	 * @param key
	 * @param newValue
	 * 
	 * @throws PropertyVetoException
	 */
	public void setInteger(String key, int newValue) throws PropertyVetoException
	{
		setObject(key, new Integer(newValue));
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public long getLong(String key)
	{
		Long ret = (Long) getObject(key);

		return ret.longValue();
	}

	/**
	 *
	 *
	 * @param key
	 * @param newValue
	 * 
	 * @throws PropertyVetoException
	 */
	public void setLong(String key, long newValue) throws PropertyVetoException
	{
		setObject(key, new Long(newValue));
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public float getFloat(String key)
	{
		Float ret = (Float) getObject(key);

		return ret.floatValue();
	}

	/**
	 *
	 *
	 * @param key
	 * @param newValue
	 * 
	 * @throws PropertyVetoException
	 */
	public void setFloat(String key, float newValue) throws PropertyVetoException
	{
		setObject(key, new Float(newValue));
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public double getDouble(String key)
	{
		Double ret = (Double) getObject(key);

		return ret.doubleValue();
	}

	/**
	 *
	 *
	 * @param key
	 * @param newValue
	 * 
	 * @throws PropertyVetoException
	 */
	public void setDouble(String key, double newValue) throws PropertyVetoException
	{
		setObject(key, new Double(newValue));
	}

	// --------------------------------------------------------------------------------
	// Property methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param key
	 */
	public void delProperty(String key)
	{
		propertyMap.remove(key);
	}

	/**
	 *
	 *
	 * @return
	 */
	public Iterator propertyIterator()
	{
		return propertyMap.entrySet().iterator();
	}

	/**
	 *
	 *
	 * @return
	 */
	public Map.Entry[] toPropertyArray()
	{
		return (Map.Entry[]) propertyMap.entrySet().toArray(new Map.Entry[0]);
	}
}
