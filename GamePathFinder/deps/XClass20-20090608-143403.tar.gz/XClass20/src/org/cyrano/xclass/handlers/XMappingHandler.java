/*
 * Created on Oct 7, 2003
 */
package org.cyrano.xclass.handlers;

import java.util.LinkedList;
import java.util.Vector;

import org.cyrano.xclass.base.XClass;
import org.cyrano.xclass.base.XExtension;
import org.cyrano.xclass.base.XField;
import org.cyrano.xclass.base.XMapping;
import org.cyrano.xclass.base.XProperty;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class XMappingHandler extends DefaultHandler
{
	private LinkedList charactersList = new LinkedList();

	private XMapping xMapping;

	private XClass xClass;

	private XField xField;

	private XExtension xExtension;

	private Vector fieldOrder;

	private LinkedList xPropertyList;

	/**
	 *
	 *
	 * @param xMapping
	 */
	public XMappingHandler(XMapping xMapping)
	{
		this.xMapping = xMapping;
	}

	/**
	 *
	 *
	 * @param str
	 * @param trm
	 *
	 * @return
	 */
	private String trimBeg(String str, String trm)
	{
		int beg = 0;

		while (beg < str.length() && trm.indexOf(str.charAt(beg)) > -1)
		{
			beg++;
		}

		return beg < str.length() ? str.substring(beg, str.length()) : "";
	}

	/**
	 *
	 *
	 * @param str
	 * @param trm
	 *
	 * @return
	 */
	public String trimEnd(String str, String trm)
	{
		int end = str.length() - 1;

		while (end > -1 && trm.indexOf(str.charAt(end)) > -1)
		{
			end--;
		}

		return end > 0 ? str.substring(0, end) : "";
	}

	// --------------------------------------------------------------------------------
	// DefaultHandler
	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public void characters(char[] ch, int start, int length) throws SAXException
	{
		StringBuffer characters = (StringBuffer) charactersList.getFirst();
		characters.append(ch, start, length);
	}

	/**
	 *
	 */
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException
	{
		StringBuffer characters = new StringBuffer();
		charactersList.addFirst(characters);

		if (qName.equals("class"))
		{
			xClass = new XClass();
			fieldOrder = new Vector();

			xClass.setFieldOrder(fieldOrder);
			xClass.setName(attributes.getValue("name"));

			xMapping.addXClass(xClass);
		}
		else if (qName.equals("extension"))
		{
			xExtension = new XExtension();
			xPropertyList = new LinkedList();

			xExtension.setName(attributes.getValue("name"));
			xExtension.setPropertyOrder(new Vector());

			if (xField == null)
			{
				xClass.addXExtension(xExtension);
			}
			else
			{
				xField.addXExtension(xExtension);
			}
		}
		else if (qName.equals("property"))
		{
			XProperty xProperty = new XProperty();
			xProperty.setKey(attributes.getValue("key"));
			xProperty.setValue(attributes.getValue("value"));
			xProperty.setPropertyOrder(new Vector());

			if (xPropertyList.isEmpty())
			{
				xExtension.addXProperty(xProperty);
				xExtension.getPropertyOrder().add(xProperty.getKey());
				xPropertyList.addFirst(xProperty);
			}
			else
			{
				XProperty xPropertyParent = (XProperty) xPropertyList.getFirst();
				xPropertyParent.addXProperty(xProperty);
				xPropertyParent.getPropertyOrder().add(xProperty.getKey());
				xPropertyList.addFirst(xProperty);
			}
		}
		else if (qName.equals("field"))
		{
			xField = new XField();

			xField.setName(attributes.getValue("name"));
			xField.setType(attributes.getValue("type"));

			fieldOrder.add(xField.getName());
			xClass.addXField(xField);
		}
	}

	/**
	 *
	 */
	public void endElement(String uri, String localName, String qName) throws SAXException
	{
		if (qName.equals("field"))
		{
			xField = null;
		}
		else if (qName.equals("property"))
		{
			if (!xPropertyList.isEmpty())
			{
				XProperty xProperty = (XProperty) xPropertyList.removeFirst();

				StringBuffer characters = (StringBuffer) charactersList.getFirst();
				String text = characters.toString();

				text = trimBeg(text, "\n");
				text = trimEnd(text, "\n\t");

				if (text.length() != 0)
				{
					xProperty.setText(text);
				}
			}
		}

		charactersList.removeFirst();
	}
}
