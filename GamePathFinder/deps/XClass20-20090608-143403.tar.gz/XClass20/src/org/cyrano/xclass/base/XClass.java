/*
 * Created on Oct 6, 2003
 */
package org.cyrano.xclass.base;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class XClass implements Serializable
{
	private String name;

	private Map xExtensionMap = new HashMap();

	private Map xFieldMap = new HashMap();

	private Vector fieldOrder;

	/**
	 *
	 */
	public XClass()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// Get / Set methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public String getName()
	{
		return name;
	}

	/**
	 *
	 *
	 * @param name
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Map getXExtensionMap()
	{
		return xExtensionMap;
	}

	/**
	 *
	 *
	 * @param xExtensionMap
	 */
	public void setXExtensionMap(Map xExtensionMap)
	{
		this.xExtensionMap = xExtensionMap;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Map getXFieldMap()
	{
		return xFieldMap;
	}

	/**
	 *
	 *
	 * @param xFieldMap
	 */
	public void setXFieldMap(Map xFieldMap)
	{
		this.xFieldMap = xFieldMap;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Vector getFieldOrder()
	{
		return fieldOrder;
	}

	/**
	 *
	 *
	 * @param fieldOrder
	 */
	public void setFieldOrder(Vector fieldOrder)
	{
		this.fieldOrder = fieldOrder;
	}

	// --------------------------------------------------------------------------------
	// extensionMap methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param xExtension
	 */
	public void addXExtension(XExtension xExtension)
	{
		xExtensionMap.put(xExtension.getName(), xExtension);
	}

	/**
	 *
	 *
	 * @param name
	 *
	 * @return
	 */
	public XExtension getXExtension(String name)
	{
		return (XExtension) xExtensionMap.get(name);
	}

	/**
	 *
	 *
	 * @param name
	 *
	 * @return
	 */
	public XExtension delXExtension(String name)
	{
		return (XExtension) xExtensionMap.remove(name);
	}

	/**
	 *
	 *
	 * @return
	 */
	public Iterator xExtensionIterator()
	{
		return xExtensionMap.values().iterator();
	}

	/**
	 *
	 *
	 * @return
	 */
	public XExtension[] toXExtensionArray()
	{
		return (XExtension[]) xExtensionMap.values().toArray(new XExtension[0]);
	}

	// --------------------------------------------------------------------------------
	// fieldMap methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param xField
	 */
	public void addXField(XField xField)
	{
		xFieldMap.put(xField.getName(), xField);
	}

	/**
	 *
	 *
	 * @param name
	 *
	 * @return
	 */
	public XField getXField(String name)
	{
		return (XField) xFieldMap.get(name);
	}

	/**
	 *
	 *
	 * @param name
	 *
	 * @return
	 */
	public XField delXField(String name)
	{
		return (XField) xFieldMap.remove(name);
	}

	/**
	 *
	 *
	 * @return
	 */
	public Iterator xFieldIterator()
	{
		return xFieldMap.values().iterator();
	}

	/**
	 *
	 *
	 * @return
	 */
	public XField[] toXFieldArray()
	{
		return (XField[]) xFieldMap.values().toArray(new XField[0]);
	}
}
