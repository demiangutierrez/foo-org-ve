/*
 * Created on Apr 8, 2004
 */
package org.cyrano.xclass.base;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class XProperty
{
	private String key;

	private String value;

	private String text;

	private Map xPropertyMap = new HashMap();

	private Vector propertyOrder;

	/**
	 *
	 */
	public XProperty()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// Get / Set methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public String getKey()
	{
		return key;
	}

	/**
	 *
	 *
	 * @param key
	 */
	public void setKey(String key)
	{
		this.key = key;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public String getValue()
	{
		return value;
	}

	/**
	 *
	 *
	 * @param value
	 */
	public void setValue(String value)
	{
		this.value = value;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public String getText()
	{
		return text;
	}

	/**
	 *
	 *
	 * @param text
	 */
	public void setText(String text)
	{
		this.text = text;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Map getXPropertyMap()
	{
		return xPropertyMap;
	}

	/**
	 *
	 *
	 * @param xPropertyMap
	 */
	public void setXPropertyMap(Map xPropertyMap)
	{
		this.xPropertyMap = xPropertyMap;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Vector getPropertyOrder()
	{
		return propertyOrder;
	}

	/**
	 *
	 *
	 * @param propertyOrder
	 */
	public void setPropertyOrder(Vector propertyOrder)
	{
		this.propertyOrder = propertyOrder;
	}

	// --------------------------------------------------------------------------------
	// propertyMap methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param xProperty
	 */
	public void addXProperty(XProperty xProperty)
	{
		xPropertyMap.put(xProperty.getKey(), xProperty);
	}

	/**
	 *
	 *
	 * @param key
	 *
	 * @return
	 */
	public XProperty getXProperty(String key)
	{
		return (XProperty) xPropertyMap.get(key);
	}

	/**
	 *
	 *
	 * @param key
	 *
	 * @return
	 */
	public XProperty delProperty(String key)
	{
		return (XProperty) xPropertyMap.remove(key);
	}

	/**
	 *
	 *
	 * @return
	 */
	public Iterator xPropertyIterator()
	{
		return xPropertyMap.values().iterator();
	}

	/**
	 *
	 *
	 * @return
	 */
	public XProperty[] toXPropertyArray()
	{
		return (XProperty[]) xPropertyMap.values().toArray(new XProperty[0]);
	}

	// --------------------------------------------------------------------------------
	// Value Get / Set methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public boolean getBooleanValue()
	{
		if (value != null)
		{
			return value.equals("true") ? true : false;
		}

		Boolean ret = (Boolean) XUtils.getPrimitiveWrapperValue("boolean");

		return ret.booleanValue();
	}

	/**
	 *
	 *
	 * @param value
	 */
	public void setBooleanValue(boolean value)
	{
		this.value = value ? "true" : "false";
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public char getCharacterValue()
	{
		if (value != null)
		{
			return value.charAt(0);
		}

		Character ret = (Character) XUtils.getPrimitiveWrapperValue("char");

		return ret.charValue();
	}

	/**
	 *
	 *
	 * @param value
	 */
	public void setCharacterValue(char value)
	{
		this.value = Character.toString(value);
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public byte getByteValue()
	{
		if (value != null)
		{
			return Byte.parseByte(value);
		}

		Byte ret = (Byte) XUtils.getPrimitiveWrapperValue("byte");

		return ret.byteValue();
	}

	/**
	 *
	 *
	 * @param value
	 */
	public void setByteValue(byte value)
	{
		this.value = Byte.toString(value);
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public short getShortValue()
	{
		if (value != null)
		{
			return Short.parseShort(value);
		}

		Short ret = (Short) XUtils.getPrimitiveWrapperValue("short");

		return ret.shortValue();
	}

	/**
	 *
	 *
	 * @param value
	 */
	public void setShortValue(short value)
	{
		this.value = Short.toString(value);
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public int getIntegerValue()
	{
		if (value != null)
		{
			return Integer.parseInt(value);
		}

		Integer ret = (Integer) XUtils.getPrimitiveWrapperValue("int");

		return ret.intValue();
	}

	/**
	 *
	 *
	 * @param value
	 */
	public void setIntegerValue(int value)
	{
		this.value = Integer.toString(value);
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public long getLongValue()
	{
		if (value != null)
		{
			return Long.parseLong(value);
		}

		Long ret = (Long) XUtils.getPrimitiveWrapperValue("long");

		return ret.longValue();
	}

	/**
	 *
	 *
	 * @param value
	 */
	public void setLongValue(long value)
	{
		this.value = Long.toString(value);
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public float getFloatValue()
	{
		if (value != null)
		{
			return Float.parseFloat(value);
		}

		Float ret = (Float) XUtils.getPrimitiveWrapperValue("float");

		return ret.floatValue();
	}

	/**
	 *
	 *
	 * @param value
	 */
	public void setFloatValue(float value)
	{
		this.value = Float.toString(value);
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public double getDoubleValue()
	{
		if (value != null)
		{
			return Double.parseDouble(value);
		}

		Double ret = (Double) XUtils.getPrimitiveWrapperValue("double");

		return ret.doubleValue();
	}

	/**
	 *
	 *
	 * @param value
	 */
	public void setDoubleValue(double value)
	{
		this.value = Double.toString(value);
	}
}
