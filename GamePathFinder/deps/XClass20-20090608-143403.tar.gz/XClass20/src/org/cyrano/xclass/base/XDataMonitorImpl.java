/*
 * Created on Oct 5, 2003
 */
package org.cyrano.xclass.base;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;

import javax.swing.event.EventListenerList;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class XDataMonitorImpl implements XDataMonitor
{
	private EventListenerList eventListenerList = new EventListenerList();

	/**
	 *
	 */
	public XDataMonitorImpl()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// XDataMonitor
	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public void addPropertyChangeListener(PropertyChangeListener listener)
	{
		eventListenerList.add(PropertyChangeListener.class, listener);
	}

	/**
	 *
	 */
	public void delPropertyChangeListener(PropertyChangeListener listener)
	{
		eventListenerList.remove(PropertyChangeListener.class, listener);
	}

	/**
	 *
	 */
	public PropertyChangeListener[] getPropertyChangeListeners()
	{
		return (PropertyChangeListener[]) eventListenerList.getListeners(PropertyChangeListener.class);
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public void addVetoableChangeListener(VetoableChangeListener listener)
	{
		eventListenerList.add(VetoableChangeListener.class, listener);
	}

	/**
	 *
	 */
	public void delVetoableChangeListener(VetoableChangeListener listener)
	{
		eventListenerList.remove(VetoableChangeListener.class, listener);
	}

	/**
	 *
	 */
	public VetoableChangeListener[] getVetoableChangeListeners()
	{
		return (VetoableChangeListener[]) eventListenerList.getListeners(VetoableChangeListener.class);
	}

	// --------------------------------------------------------------------------------
	// FirePropertyChange methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param evt
	 */
	public void firePropertyChange(PropertyChangeEvent evt)
	{
		PropertyChangeListener[] listenerArray = getPropertyChangeListeners();

		for (int i = 0; i < listenerArray.length; i++)
		{
			listenerArray[i].propertyChange(evt);
		}
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 */
	public void firePropertyChange(String propertyName, Object oldValue, Object newValue)
	{
		PropertyChangeEvent evt = new PropertyChangeEvent(this, propertyName, oldValue, newValue);

		firePropertyChange(evt);
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 */
	public void firePropertyChange(String propertyName, boolean oldValue, boolean newValue)
	{
		firePropertyChange(propertyName, new Boolean(oldValue), new Boolean(newValue));
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 */
	public void firePropertyChange(String propertyName, char oldValue, char newValue)
	{
		firePropertyChange(propertyName, new Character(oldValue), new Character(newValue));
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 */
	public void firePropertyChange(String propertyName, byte oldValue, byte newValue)
	{
		firePropertyChange(propertyName, new Byte(oldValue), new Byte(newValue));
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 */
	public void firePropertyChange(String propertyName, short oldValue, short newValue)
	{
		firePropertyChange(propertyName, new Short(oldValue), new Short(newValue));
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 */
	public void firePropertyChange(String propertyName, int oldValue, int newValue)
	{
		firePropertyChange(propertyName, new Integer(oldValue), new Integer(newValue));
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 */
	public void firePropertyChange(String propertyName, long oldValue, long newValue)
	{
		firePropertyChange(propertyName, new Long(oldValue), new Long(newValue));
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 */
	public void firePropertyChange(String propertyName, float oldValue, float newValue)
	{
		firePropertyChange(propertyName, new Float(oldValue), new Float(newValue));
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 */
	public void firePropertyChange(String propertyName, double oldValue, double newValue)
	{
		firePropertyChange(propertyName, new Double(oldValue), new Double(newValue));
	}

	// --------------------------------------------------------------------------------
	// FireVetoableChange methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param evt
	 *
	 * @throws PropertyVetoException
	 */
	public void fireVetoableChange(PropertyChangeEvent evt) throws PropertyVetoException
	{
		VetoableChangeListener[] listenerArray = getVetoableChangeListeners();

		for (int i = 0; i < listenerArray.length; i++)
		{
			listenerArray[i].vetoableChange(evt);
		}
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 *
	 * @throws PropertyVetoException
	 */
	public void fireVetoableChange(String propertyName, Object oldValue, Object newValue) throws PropertyVetoException
	{
		PropertyChangeEvent evt = new PropertyChangeEvent(this, propertyName, oldValue, newValue);

		fireVetoableChange(evt);
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 *
	 * @throws PropertyVetoException
	 */
	public void fireVetoableChange(String propertyName, boolean oldValue, boolean newValue)
		throws PropertyVetoException
	{
		fireVetoableChange(propertyName, new Boolean(oldValue), new Boolean(newValue));
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 *
	 * @throws PropertyVetoException
	 */
	public void fireVetoableChange(String propertyName, char oldValue, char newValue) throws PropertyVetoException
	{
		fireVetoableChange(propertyName, new Character(oldValue), new Character(newValue));
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 *
	 * @throws PropertyVetoException
	 */
	public void fireVetoableChange(String propertyName, byte oldValue, byte newValue) throws PropertyVetoException
	{
		fireVetoableChange(propertyName, new Byte(oldValue), new Byte(newValue));
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 *
	 * @throws PropertyVetoException
	 */
	public void fireVetoableChange(String propertyName, short oldValue, short newValue) throws PropertyVetoException
	{
		fireVetoableChange(propertyName, new Short(oldValue), new Short(newValue));
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 *
	 * @throws PropertyVetoException
	 */
	public void fireVetoableChange(String propertyName, int oldValue, int newValue) throws PropertyVetoException
	{
		fireVetoableChange(propertyName, new Integer(oldValue), new Integer(newValue));
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 *
	 * @throws PropertyVetoException
	 */
	public void fireVetoableChange(String propertyName, long oldValue, long newValue) throws PropertyVetoException
	{
		fireVetoableChange(propertyName, new Long(oldValue), new Long(newValue));
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 *
	 * @throws PropertyVetoException
	 */
	public void fireVetoableChange(String propertyName, float oldValue, float newValue) throws PropertyVetoException
	{
		fireVetoableChange(propertyName, new Float(oldValue), new Float(newValue));
	}

	/**
	 *
	 *
	 * @param propertyName
	 * @param oldValue
	 * @param newValue
	 *
	 * @throws PropertyVetoException
	 */
	public void fireVetoableChange(String propertyName, double oldValue, double newValue) throws PropertyVetoException
	{
		fireVetoableChange(propertyName, new Double(oldValue), new Double(newValue));
	}
}
