/*
 * Created on Apr 8, 2004
 */
package org.cyrano.xclass.exceptions;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class InvalidMethodException extends Exception
{
	/**
	 *
	 */
	public InvalidMethodException()
	{
		super();
	}

	/**
	 *
	 */
	public InvalidMethodException(String message)
	{
		super(message);
	}

	/**
	 *
	 */
	public InvalidMethodException(String message, Throwable cause)
	{
		super(message, cause);
	}

	/**
	 *
	 */
	public InvalidMethodException(Throwable cause)
	{
		super(cause);
	}
}
