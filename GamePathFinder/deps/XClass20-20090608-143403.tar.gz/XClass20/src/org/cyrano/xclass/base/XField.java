/*
 * Created on Oct 6, 2003
 */
package org.cyrano.xclass.base;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class XField
{
	private String name;

	private String type;

	private Map xExtensionMap = new HashMap();

	/**
	 *
	 */
	public XField()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// Get / Set methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public String getName()
	{
		return name;
	}

	/**
	 *
	 *
	 * @param name
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public String getType()
	{
		return type;
	}

	/**
	 *
	 *
	 * @param type
	 */
	public void setType(String type)
	{
		this.type = type;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Map getXExtensionMap()
	{
		return xExtensionMap;
	}

	/**
	 *
	 *
	 * @param xExtensionMap
	 */
	public void setXExtensionMap(Map xExtensionMap)
	{
		this.xExtensionMap = xExtensionMap;
	}

	// --------------------------------------------------------------------------------
	// xExtensionMap methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param xExtension
	 */
	public void addXExtension(XExtension xExtension)
	{
		xExtensionMap.put(xExtension.getName(), xExtension);
	}

	/**
	 *
	 *
	 * @param name
	 *
	 *  @return
	 */
	public XExtension getXExtension(String name)
	{
		return (XExtension) xExtensionMap.get(name);
	}

	/**
	 *
	 *
	 * @param name
	 *
	 * @return
	 */
	public XExtension delXExtension(String name)
	{
		return (XExtension) xExtensionMap.remove(name);
	}

	/**
	 *
	 *
	 * @return
	 */
	public Iterator xExtensionIterator()
	{
		return xExtensionMap.values().iterator();
	}

	/**
	 *
	 *
	 * @return
	 */
	public XExtension[] toXExtensionArray()
	{
		return (XExtension[]) xExtensionMap.values().toArray(new XExtension[0]);
	}
}
