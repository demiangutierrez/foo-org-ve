/*
 * Created on May 27, 2004
 */
package org.cyrano.xclass.tools;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class ArgumentException extends Exception
{
	/**
	 *
	 */
	public ArgumentException()
	{
		super();
	}

	/**
	 *
	 */
	public ArgumentException(String message)
	{
		super(message);
	}

	/**
	 *
	 */
	public ArgumentException(Throwable cause)
	{
		super(cause);
	}

	/**
	 *
	 */
	public ArgumentException(String message, Throwable cause)
	{
		super(message, cause);
	}
}
