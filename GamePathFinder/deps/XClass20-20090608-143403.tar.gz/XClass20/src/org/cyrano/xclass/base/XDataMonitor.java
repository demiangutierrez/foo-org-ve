/*
 * Created on Oct 14, 2003
 */
package org.cyrano.xclass.base;

import java.beans.PropertyChangeListener;
import java.beans.VetoableChangeListener;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface XDataMonitor
{
	/**
	 *
	 *
	 * @param listener
	 */
	public void addPropertyChangeListener(PropertyChangeListener listener);

	/**
	 *
	 *
	 * @param listener
	 */
	public void delPropertyChangeListener(PropertyChangeListener listener);

	/**
	 *
	 *
	 * @return
	 */
	public PropertyChangeListener[] getPropertyChangeListeners();

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param listener
	 */
	public void addVetoableChangeListener(VetoableChangeListener listener);

	/**
	 *
	 *
	 * @param listener
	 */
	public void delVetoableChangeListener(VetoableChangeListener listener);

	/**
	 *
	 *
	 * @return
	 */
	public VetoableChangeListener[] getVetoableChangeListeners();
}
