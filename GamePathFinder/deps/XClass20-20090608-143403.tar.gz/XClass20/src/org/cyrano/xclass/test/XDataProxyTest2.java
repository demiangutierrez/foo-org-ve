/*
 * Created on Apr 8, 2004
 */
package org.cyrano.xclass.test;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;
import java.io.InputStream;
import java.lang.reflect.Proxy;
import java.util.Date;

import org.cyrano.xclass.base.XDataObject;
import org.cyrano.xclass.base.XDataProxy;
import org.cyrano.xclass.base.XMapping;
import org.cyrano.xclass.base.XMappingFactory;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class XDataProxyTest2
{
	/**
	 *
	 */
	public XDataProxyTest2()
	{
		// Empy
	}

	/**
	 *
	 */
	public static void main(String[] args)
	{
		Employee employee = null;

		InputStream inputStream = XMappingTest.class.getResourceAsStream("mapping_in_A.xml");

		XMapping xMapping = null;

		try
		{
			xMapping = XMappingFactory.load(inputStream);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		try
		{
			employee =
				(Employee) XDataProxy.createXDataProxy(
					Employee.class,
					xMapping.getXClass("org.cyrano.xclass.test.Employee"));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		XDataObject xdo = (XDataObject) Proxy.getInvocationHandler(employee);

		xdo.addVetoableChangeListener(new VetoableChangeListener()
		{
			public void vetoableChange(PropertyChangeEvent evt) throws PropertyVetoException
			{
				// Veto all
				throw new PropertyVetoException("", evt);
			}
		});

		try
		{
			employee.setId(10);
		}
		catch (PropertyVetoException e)
		{
			System.err.println("This is ok : " + e.getMessage());
		}

		System.err.println(employee.getId());

		try
		{
			employee.setFirstName("Demian");
		}
		catch (PropertyVetoException e)
		{
			System.err.println("This is ok : " + e.getMessage());
		}

		System.err.println(employee.getFirstName());

		try
		{
			employee.setLastName("Gutierrez");
		}
		catch (PropertyVetoException e)
		{
			System.err.println("This is ok : " + e.getMessage());
		}

		System.err.println(employee.getLastName());

		try
		{
			employee.setBirth(new Date());
		}
		catch (PropertyVetoException e)
		{
			System.err.println("This is ok : " + e.getMessage());
		}

		System.err.println(employee.getBirth());
	}
}
