/*
 * Created on Sep 18, 2003
 */
package org.cyrano.xclass.tools;

import java.util.Vector;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class Argument
{
	private Vector modifiers;

	private String type;

	private String name;

	/**
	 *
	 */
	public Argument()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// Get / Set methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Vector getModifiers()
	{
		return modifiers;
	}

	/**
	 *
	 *
	 * @param modifiers
	 */
	public void setModifiers(Vector modifiers)
	{
		this.modifiers = modifiers;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public String getType()
	{
		return type;
	}

	/**
	 *
	 *
	 * @param type
	 */
	public void setType(String type)
	{
		this.type = type;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public String getName()
	{
		return name;
	}

	/**
	 *
	 *
	 * @param name
	 */
	public void setName(String name)
	{
		this.name = name;
	}
}
