/*
 * Created on Apr 8, 2004
 */
package org.cyrano.xclass.base;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import org.cyrano.xclass.exceptions.InvalidMethodException;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class XDataProxy extends XDataObject implements InvocationHandler
{
	/**
	 *
	 */
	private XDataProxy()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param interfaceClass
	 * @param xClass
	 *
	 * @return
	 *
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 */
	public static Object createXDataProxy(Class interfaceClass, XClass xClass)
		throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException
	{
		Class proxyClass = Proxy.getProxyClass(interfaceClass.getClassLoader(), new Class[] { interfaceClass });

		XDataProxy xDataProxy = new XDataProxy();
		xDataProxy.setXClass(xClass);

		Proxy ret =
			(Proxy) proxyClass.getConstructor(new Class[] { InvocationHandler.class }).newInstance(
				new Object[] { xDataProxy });

		return ret;
	}

	/**
	 *
	 *
	 * @param interfaceClass
	 *
	 * @return
	 *
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 */
	public static Object createXDataProxy(Class interfaceClass)
		throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException
	{
		return createXDataProxy(interfaceClass, null);
	}

	// --------------------------------------------------------------------------------
	// InvocationHandler
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param proxy
	 * @param method
	 * @param args
	 *
	 * @return
	 *
	 * @throws Throwable
	 */
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
	{
		Object ret = null;

		String methodName = method.getName();

		if (methodName.startsWith("get"))
		{
			String key = methodName.substring(3);

			if (key.equals(""))
			{
				throw new InvalidMethodException(msg.getString("invalid_method_get_only", methodName));
			}

			key = key.substring(0, 1).toLowerCase() + key.substring(1);

			ret = getObject(key);
		}
		else if (methodName.startsWith("set"))
		{
			String key = methodName.substring(3);

			if (key.equals(""))
			{
				throw new InvalidMethodException(msg.getString("invalid_method_set_only", methodName));
			}

			key = key.substring(0, 1).toLowerCase() + key.substring(1);

			if (args.length != 1)
			{
				throw new InvalidMethodException(msg.getString("invalid_method_args_length", methodName));
			}

			setObject(key, args[0]);
		}
		else if (methodName.startsWith("toString"))
		{
			ret = toString();
		}
		else
		{
			throw new InvalidMethodException(msg.getString("invalid_method_unknown", methodName));
		}

		return ret;
	}
}
