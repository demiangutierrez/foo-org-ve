/*
 * Created on Sep 18, 2003
 */
package org.cyrano.xclass.tools;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import org.cyrano.xclass.base.XClass;
import org.cyrano.xclass.base.XField;
import org.cyrano.xclass.base.XMapping;
import org.cyrano.xclass.base.XMappingFactory;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class SourceGenerator
{
	private static String type;

	private static String veto;

	private static String mapping;

	private static String dir;

	private static SourceWriter sourceWriter = new SourceWriter();

	private static PrintWriter writer;

	private static Vector throwz;

	private static Vector modifiers;

	private static Vector arguments;

	private static Vector comment;

	/**
	 *
	 */
	private SourceGenerator()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	private static void help()
	{
		System.err.println("USAGE: java SourceGenerator <-c|-i> [-v] <MAPPING> <DEST_DIR>");
		System.err.println("\t-c | -i\tCreates a class (-c) or an interface (-i)");
		System.err.println("\t-p setXXX methods throws PropertyVetoException");
		System.exit(-1);
	}

	/**
	 *
	 *
	 * @param args
	 *
	 * @throws ArgumentException
	 */
	private static void parseArguments(String[] args) throws ArgumentException
	{
		for (int i = 0; i < args.length; i++)
		{
			if (args[i].equals("-c") || args[i].equals("-i"))
			{
				if (type != null)
				{
					throw new ArgumentException("Type already defined");
				}

				type = args[i];
			}
			else if (args[i].equals("-p"))
			{
				if (veto != null)
				{
					throw new ArgumentException("PropertyVetoException already defined");
				}

				veto = args[i];
			}
			else
			{
				if (args[i].startsWith("-"))
				{
					throw new ArgumentException("Unknown switch " + args[i]);
				}

				if (mapping == null)
				{
					mapping = args[i];
				}
				else
				{
					dir = args[i];
				}
			}
		}
	}

	/**
	 *
	 *
	 * @throws ArgumentException
	 */
	private static void checkArguments() throws ArgumentException
	{
		if (type == null)
		{
			throw new ArgumentException("Unknown type (Class or Interface)");
		}
		else if (mapping == null)
		{
			throw new ArgumentException("Unknown mapping file");
		}
		else if (dir == null)
		{
			throw new ArgumentException("Unknown destination directory");
		}
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public static void main(String[] args)
	{
		try
		{
			parseArguments(args);
			checkArguments();
		}
		catch (ArgumentException e)
		{
			System.err.println(e.getMessage());
			help();
		}

		XMapping xMapping = new XMapping();

		try
		{
			xMapping = XMappingFactory.load(new FileInputStream(mapping));

			Iterator itt = xMapping.xClassIterator();

			while (itt.hasNext())
			{
				XClass xClass = (XClass) itt.next();

				// --------------------------------------------------------------------------------
				// Open target
				// --------------------------------------------------------------------------------
				writer =
					new PrintWriter(new FileOutputStream(dir + sourceWriter.getClassName(xClass.getName()) + ".java"));
				sourceWriter.setWriter(writer);

				comment = new Vector();
				comment.add("Generated automatically by Source Generator on " + new Date());
				sourceWriter.cStyleComment(comment);

				// Package
				sourceWriter.packageStatement(xClass.getName());

				// Imports
				Set typeSet = new TreeSet();
				Enumeration enum = xClass.getFieldOrder().elements();

				while (enum.hasMoreElements())
				{
					String fieldName = (String) enum.nextElement();
					XField xField = xClass.getXField(fieldName);
					typeSet.add(xField.getType());
				}

				if (veto != null)
				{
					typeSet.add("java.beans.PropertyVetoException");
				}

				sourceWriter.importStatement(typeSet);

				// --------------------------------------------------------------------------------
				// Interface / Class
				// --------------------------------------------------------------------------------
				comment = new Vector();
				comment.add("");
				sourceWriter.documentationComment(comment);

				modifiers = new Vector();
				modifiers.add(SourceWriter.PUBLIC);

				if (type.equals("-c"))
				{
					sourceWriter.classStatement(modifiers, xClass.getName(), null, null);
				}
				else
				{
					sourceWriter.interfaceStatement(modifiers, xClass.getName(), null);
				}

				sourceWriter.beginCurly(true);

				// --------------------------------------------------------------------------------
				// Members / Constructor
				// --------------------------------------------------------------------------------
				if (type.equals("-c"))
				{
					enum = xClass.getFieldOrder().elements();

					while (enum.hasMoreElements())
					{
						String fieldName = (String) enum.nextElement();
						XField xField = xClass.getXField(fieldName);

						writer.println(
							sourceWriter.getIndentation()
								+ SourceWriter.PRIVATE
								+ " "
								+ sourceWriter.getClassName(xField.getType())
								+ " "
								+ fieldName
								+ ";");
						writer.println();
					}

					comment = new Vector();
					comment.add("");
					sourceWriter.documentationComment(comment);
					sourceWriter.methodStatement(
						modifiers,
						"",
						sourceWriter.getClassName(xClass.getName()),
						null,
						null);

					sourceWriter.beginCurly(true);
					comment = new Vector();
					comment.add("Empty");
					sourceWriter.singleLineComment(comment);
					sourceWriter.endCurly();
					writer.println();
				}

				// Get / set methods
				enum = xClass.getFieldOrder().elements();

				while (enum.hasMoreElements())
				{
					String fieldName = (String) enum.nextElement();
					XField xField = xClass.getXField(fieldName);
					String fieldNameToUpper = fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);

					// --------------------------------------------------------------------------------
					// Get
					// --------------------------------------------------------------------------------
					comment = new Vector();
					comment.add("Get / set methods for " + xField.getName());
					sourceWriter.cStyleComment(comment);
					writer.println();

					comment = new Vector();
					comment.add("");
					sourceWriter.documentationComment(comment);
					sourceWriter.methodStatement(modifiers, xField.getType(), "get" + fieldNameToUpper, null, null);

					if (type.equals("-c"))
					{
						sourceWriter.beginCurly(true);
						writer.println(sourceWriter.getIndentation() + "return " + xField.getName() + ";");
						sourceWriter.endCurly();
					}
					else
					{
						writer.println(";");
					}

					writer.println();

					// --------------------------------------------------------------------------------
					// Set
					// --------------------------------------------------------------------------------
					Argument argument = new Argument();
					argument.setType(xField.getType());
					argument.setName(xField.getName());

					arguments = new Vector();
					arguments.add(argument);

					comment = new Vector();
					comment.add("");

					if (veto != null)
					{
						throwz = new Vector();
						throwz.add("PropertyVetoException");
					}

					sourceWriter.documentationComment(comment);
					sourceWriter.methodStatement(modifiers, "void", "set" + fieldNameToUpper, arguments, throwz);

					if (type.equals("-c"))
					{
						sourceWriter.beginCurly(true);
						writer.println(
							sourceWriter.getIndentation()
								+ "this."
								+ xField.getName()
								+ " = "
								+ xField.getName()
								+ ";");
						sourceWriter.endCurly();
					}
					else
					{
						writer.println(";");
					}

					if (enum.hasMoreElements())
					{
						writer.println();
					}
				}

				// --------------------------------------------------------------------------------
				// Close class
				// --------------------------------------------------------------------------------
				sourceWriter.endCurly();
				writer.close();
			}
		}
		catch (Exception e)
		{
			System.err.println(e.getMessage());
		}
	}
}
