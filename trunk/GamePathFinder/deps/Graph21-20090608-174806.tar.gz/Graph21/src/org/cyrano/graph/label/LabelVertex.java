/*
 * Created on Mar 29, 2004
 */
package org.cyrano.graph.label;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface LabelVertex extends LabelItem
{
	// Empty
}
