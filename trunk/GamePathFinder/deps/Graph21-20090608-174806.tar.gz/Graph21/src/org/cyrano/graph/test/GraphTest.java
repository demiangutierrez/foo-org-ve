/*
 * Created on Mar 24, 2004
 */
package org.cyrano.graph.test;

import java.util.Iterator;

import org.cyrano.graph.base.EdgeImpl;
import org.cyrano.graph.base.Graph;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class GraphTest
{
	/**
	 * 
	 */
	private GraphTest()
	{
		// Empty
	}

	/**
	 * 
	 */
	public static void main(String[] args)
	{
		Iterator itt;

		Graph g = new Graph();

		System.err.println("--------------------------------------------------------------------------------");
		System.err.println("Test addVertex");

		g.addVertex("1");
		g.addVertex("2");
		g.addVertex("3");

		System.err.println(g);

		System.err.println("--------------------------------------------------------------------------------");
		System.err.println("Test addEdge");

		g.addEdge(new EdgeImpl("1", "2", "a"));
		g.addEdge(new EdgeImpl("2", "3", "b"));
		g.addEdge(new EdgeImpl("3", "1", "c"));

		g.addEdge(new EdgeImpl("1", "3", "d"));
		g.addEdge(new EdgeImpl("2", "1", "e"));
		g.addEdge(new EdgeImpl("3", "2", "f"));

		System.err.println(g);

		System.err.println("--------------------------------------------------------------------------------");
		System.err.println("Test removeVertex");

		g.removeVertex("1");
		g.removeVertex("2");

		System.err.println(g);

		System.err.println("--------------------------------------------------------------------------------");
		System.err.println("Test removeEdge");

		g.addVertex("1");
		g.addVertex("2");

		g.addEdge(new EdgeImpl("1", "2", "a"));
		g.addEdge(new EdgeImpl("2", "3", "b"));
		g.addEdge(new EdgeImpl("3", "1", "c"));

		g.addEdge(new EdgeImpl("1", "3", "d"));
		g.addEdge(new EdgeImpl("2", "1", "e"));
		g.addEdge(new EdgeImpl("3", "2", "f"));

		g.removeEdge("1", "3");
		g.removeEdge("2", "1");
		g.removeEdge("3", "2");

		System.err.println(g);

		System.err.println("--------------------------------------------------------------------------------");
		System.err.println("Test getVertex / getEdge");

		System.err.println(g.getVertex("1") + ";" + g.getVertex("2") + ";" + g.getVertex("3") + ";" + g.getVertex("4"));

		System.err.println(((EdgeImpl) g.getEdge("1", "2")).getDta());
		System.err.println(((EdgeImpl) g.getEdge("2", "3")).getDta());
		System.err.println(((EdgeImpl) g.getEdge("3", "1")).getDta());

		System.err.println(g.getEdge("1", "3"));
		System.err.println(g.getEdge("2", "1"));
		System.err.println(g.getEdge("3", "2"));

		System.err.println(g);

		System.err.println("--------------------------------------------------------------------------------");
		System.err.println("Test vertexIterator / toVertexArray");

		System.err.println("vertexIterator");

		itt = g.vertexIterator();

		while (itt.hasNext())
		{
			Object v = (Object) itt.next();
			System.err.print(v);

			if (itt.hasNext())
			{
				System.err.print("; ");
			}
		}

		System.err.println();

		System.err.println("toVertexArray");

		Object[] vo = g.toVertexArray();

		for (int i = 0; i < vo.length; i++)
		{
			System.err.print(vo[i]);

			if (i != vo.length - 1)
			{
				System.err.print("; ");
			}
		}

		System.err.println();

		String[] vs = (String[]) g.toVertexArray(new String[0]);

		for (int i = 0; i < vo.length; i++)
		{
			System.err.print(vo[i]);

			if (i != vs.length - 1)
			{
				System.err.print("; ");
			}
		}

		System.err.println();

		System.err.println("--------------------------------------------------------------------------------");
		System.err.println("Test edgeIterator / toEdgeArray");

		g.addEdge(new EdgeImpl("1", "3", "d"));
		g.addEdge(new EdgeImpl("2", "1", "e"));
		g.addEdge(new EdgeImpl("3", "2", "f"));

		System.err.println("edgeIterator");

		itt = g.edgeIterator();

		while (itt.hasNext())
		{
			EdgeImpl edge = (EdgeImpl) itt.next();

			System.err.println(edge.getSrc() + ";" + edge.getDst() + ";" + edge.getDta());
		}

		System.err.println("toEdgeArray");

		EdgeImpl[] ei = (EdgeImpl[]) g.toEdgeArray(new EdgeImpl[0]);

		for (int i = 0; i < ei.length; i++)
		{
			System.err.println(ei[i].getSrc() + ";" + ei[i].getDst() + ";" + ei[i].getDta());
		}

		System.err.println("--------------------------------------------------------------------------------");
		System.err.println("Test [src, dst]EdgeIterator / to[Src, Dst]EdgeArray");

		System.err.println("srcEdgeIterator");

		itt = g.srcEdgeIterator("1");

		while (itt.hasNext())
		{
			EdgeImpl edge = (EdgeImpl) itt.next();

			System.err.println(edge.getSrc() + ";" + edge.getDst() + ";" + edge.getDta());
		}

		System.err.println("toSrcEdgeArray");

		ei = (EdgeImpl[]) g.toSrcEdgeArray("1", new EdgeImpl[0]);

		for (int i = 0; i < ei.length; i++)
		{
			System.err.println(ei[i].getSrc() + ";" + ei[i].getDst() + ";" + ei[i].getDta());
		}

		System.err.println("dstEdgeIterator");

		itt = g.dstEdgeIterator("1");

		while (itt.hasNext())
		{
			EdgeImpl edge = (EdgeImpl) itt.next();

			System.err.println(edge.getSrc() + ";" + edge.getDst() + ";" + edge.getDta());
		}

		System.err.println("toDstEdgeArray");

		ei = (EdgeImpl[]) g.toDstEdgeArray("1", new EdgeImpl[0]);

		for (int i = 0; i < ei.length; i++)
		{
			System.err.println(ei[i].getSrc() + ";" + ei[i].getDst() + ";" + ei[i].getDta());
		}
	}
}
