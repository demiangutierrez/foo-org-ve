/*
 * Created on Mar 24, 2004
 */
package org.cyrano.graph.base;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class EdgeImpl implements Edge
{
	protected Object src;

	protected Object dst;

	protected Object dta;

	// --------------------------------------------------------------------------------

	/**
	 * 
	 */
	public EdgeImpl()
	{
		// Empty
	}

	/**
	 *
	 *
	 * @param src
	 * @param dst
	 * @param dta
	 */
	public EdgeImpl(Object src, Object dst, Object dta)
	{
		this.src = src;
		this.dst = dst;

		this.dta = dta;
	}

	// --------------------------------------------------------------------------------
	// Edge
	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public Object getSrc()
	{
		return src;
	}

	/**
	 *
	 */
	public void setSrc(Object src)
	{
		this.src = src;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public Object getDst()
	{
		return dst;
	}

	/**
	 *
	 */
	public void setDst(Object dst)
	{
		this.dst = dst;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Object getDta()
	{
		return dta;
	}

	/**
	 *
	 *
	 * @param
	 */
	public void setDta(Object dta)
	{
		this.dta = dta;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public String toString()
	{
		return dta.toString();
	}
}
