/*
 * Created on Mar 30, 2004
 */
package org.cyrano.graph.label;

import java.beans.PropertyVetoException;
import java.util.HashMap;
import java.util.Map;

import org.cyrano.graph.base.Edge;
import org.cyrano.graph.base.Graph;
import org.cyrano.graph.event.LabelChangeEvent;
import org.cyrano.graph.event.LabelChangeListener;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class LabelGraph extends Graph implements LabelChangeListener
{
	/*
	 * Key: Vertex's label.
	 *
	 * Value: Vertexes and Edges.
	 */
	protected Map lblMap = new HashMap();

	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public LabelGraph()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// Graph
	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public Object removeVertex(Object vertex)
	{
		LabelVertex labelVertex = (LabelVertex) vertex;
		labelVertex.removeLabelChangeListener(this);
		lblMap.remove(labelVertex.getLabel());

		return super.removeVertex(vertex);
	}

	/**
	 *
	 */
	public Edge removeEdge(Edge edge)
	{
		return removeEdge(edge.getSrc(), edge.getDst());
	}

	/**
	 *
	 */
	public Edge removeEdge(Object src, Object dst)
	{
		LabelEdge labelEdge = (LabelEdge) getEdge(src, dst);
		labelEdge.removeLabelChangeListener(this);
		lblMap.remove(labelEdge.getLabel());

		return super.removeEdge(src, dst);
	}

	// --------------------------------------------------------------------------------
	// LabelChangeListener
	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public void labelChange(LabelChangeEvent evt) throws PropertyVetoException
	{
		if (lblMap.get(evt.getNewLabel()) != null)
		{
			throw new PropertyVetoException("", null);
		}

		lblMap.put(evt.getNewLabel(), lblMap.remove(evt.getOldLabel()));
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param vertex
	 */
	public LabelVertex addLabelVertex(LabelVertex vertex) throws DuplicateLabelException
	{
		if (vertex.getLabel() == null)
		{
			throw new NullPointerException();
		}

		if (lblMap.get(vertex.getLabel()) != null)
		{
			throw new DuplicateLabelException();
		}

		vertex.addLabelChangeListener(this);

		lblMap.put(vertex.getLabel(), vertex);

		return (LabelVertex) super.addVertex(vertex);
	}

	/**
	 *
	 *
	 * @param vertexLabel
	 */
	public LabelVertex getLabelVertex(String vertexLabel)
	{
		LabelVertex ret = (LabelVertex) lblMap.get(vertexLabel);

		return ret instanceof LabelVertex ? ret : null;
	}

	/**
	 *
	 *
	 * @param edge
	 */
	public LabelEdge addLabelEdge(LabelEdge edge) throws DuplicateLabelException
	{
		if (edge.getLabel() == null)
		{
			throw new NullPointerException();
		}

		if (lblMap.get(edge.getLabel()) != null)
		{
			throw new DuplicateLabelException();
		}

		edge.addLabelChangeListener(this);

		lblMap.put(edge.getLabel(), edge);

		return (LabelEdge) super.addEdge(edge);
	}

	/**
	 *
	 *
	 * @param edgeLabel
	 */
	public LabelEdge getLabelEdge(String edgeLabel)
	{
		LabelEdge ret = (LabelEdge) lblMap.get(edgeLabel);

		return ret instanceof LabelEdge ? ret : null;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param prefix
	 */
	public int getNextLabelSuffix(String prefix)
	{
		// Empty
		// TODO: Write me

		return 0;
	}
}
