/*
 * Created on Apr 1, 2004
 */
package org.cyrano.graph.lock;

import org.cyrano.graph.base.Graph;

/**
 * @author DMI: Demian Gutierrez
 */
public class LockGraph extends Graph
{
	/*
	 * Edge from thId to rsId is a request
	 *
	 * Edge from rsId to thId is a grant 
	 */

	/**
	 *
	 */
	public LockGraph()
	{
		// Empty
	}

	/**
	 *
	 */
	public void requestRead(Object thId, Object rsId)
	{
	}

	/**
	 *
	 */
	public void requestWrite(Object thId, Object rsId)
	{
	}

	/**
	 *
	 */
	public void releaseLock(Object thId, Object rsId)
	{
	}

	/**
	 *
	 */
	public void releaseAll(Object thId)
	{
	}
}
