/*
 * Created on Jul 18, 2004
 */
package org.cyrano.graph.label;

import java.beans.PropertyVetoException;

import org.cyrano.graph.event.LabelChangeListener;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface LabelItem
{
	/**
	 *
	 *
	 * @param listener
	 */
	public void addLabelChangeListener(LabelChangeListener listener);

	/**
	 *
	 *
	 * @return
	 */
	public LabelChangeListener[] getLabelChangeListeners();

	/**
	 *
	 *
	 * @param listener
	 */
	public void removeLabelChangeListener(LabelChangeListener listener);

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public String getLabel();

	/**
	 *
	 *
	 * @param label
	 *
	 * @throws PropertyVetoException
	 */
	public void setLabel(String label) throws PropertyVetoException;
}
