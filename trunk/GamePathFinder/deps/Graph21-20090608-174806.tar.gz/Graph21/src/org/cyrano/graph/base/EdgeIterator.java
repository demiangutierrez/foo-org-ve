/*
 * Created on Mar 24, 2004
 */
package org.cyrano.graph.base;

import java.util.Iterator;
import java.util.Map;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class EdgeIterator implements Iterator
{
	private Iterator sItt;

	private Iterator eItt;

	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public EdgeIterator(Graph graph)
	{
		sItt = graph.srcMap.values().iterator();
	}

	// --------------------------------------------------------------------------------
	// Iterator
	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public boolean hasNext()
	{
		while ((eItt == null || !eItt.hasNext()) && sItt.hasNext())
		{
			Map edges = (Map) sItt.next();

			eItt = edges.values().iterator();
		}

		return eItt == null ? false : eItt.hasNext();
	}

	/**
	 *
	 */
	public Object next()
	{
		while ((eItt == null || !eItt.hasNext()) && sItt.hasNext())
		{
			Map edges = (Map) sItt.next();

			eItt = edges.values().iterator();
		}

		return eItt.next();
	}

	/**
	 *
	 */
	public void remove()
	{
		throw new UnsupportedOperationException();
	}
}
