/*
 * Created on Mar 30, 2004
 */
package org.cyrano.graph.test;

import java.beans.PropertyVetoException;

import org.cyrano.graph.label.DuplicateLabelException;
import org.cyrano.graph.label.LabelEdgeImpl;
import org.cyrano.graph.label.LabelGraph;
import org.cyrano.graph.label.LabelVertex;
import org.cyrano.graph.label.LabelVertexImpl;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class LabelGraphTest
{
	/**
	 * 
	 */
	public LabelGraphTest()
	{
		// Empty
	}

	/**
	 * 
	 */
	public static void main(String[] args)
	{
		LabelVertex v;

		LabelGraph g = new LabelGraph();

		System.err.println("--------------------------------------------------------------------------------");
		System.err.println("Test addVertex");

		try
		{
			g.addLabelVertex(new LabelVertexImpl("1"));
			g.addLabelVertex(new LabelVertexImpl("2"));
			g.addLabelVertex(new LabelVertexImpl("3"));
		}
		catch (DuplicateLabelException e)
		{
			e.printStackTrace();
		}

		System.err.println(g);

		System.err.println("--------------------------------------------------------------------------------");
		System.err.println("Test addVertex DuplicateLabelException");

		try
		{
			g.addLabelVertex(new LabelVertexImpl("1"));
		}
		catch (DuplicateLabelException e)
		{
			System.err.println("******************** This is ok");
			e.printStackTrace();
		}

		System.err.println(g);

		System.err.println("--------------------------------------------------------------------------------");
		System.err.println("Test addEdge");

		try
		{
			g.addLabelEdge(new LabelEdgeImpl(g.getVertex("1"), g.getVertex("2"), "a", "aa"));
			g.addLabelEdge(new LabelEdgeImpl(g.getVertex("2"), g.getVertex("3"), "b", "bb"));
			g.addLabelEdge(new LabelEdgeImpl(g.getVertex("3"), g.getVertex("1"), "c", "cc"));
		}
		catch (DuplicateLabelException e)
		{
			e.printStackTrace();
		}

		System.err.println(g);

		System.err.println("--------------------------------------------------------------------------------");
		System.err.println("Test addEdge DuplicateLabelException");

		try
		{
			g.addLabelEdge(new LabelEdgeImpl(g.getVertex("2"), g.getVertex("1"), "a", "aa"));
		}
		catch (DuplicateLabelException e)
		{
			System.err.println("******************** This is ok");
			e.printStackTrace();
		}

		System.err.println(g);

		System.err.println("--------------------------------------------------------------------------------");
		System.err.println("Test setLabel on a Vertex");

		v = g.getLabelVertex("1");

		try
		{
			v.setLabel("4");
		}
		catch (PropertyVetoException e)
		{
			e.printStackTrace();
		}

		System.err.println(g);

		System.err.println("--------------------------------------------------------------------------------");
		System.err.println("Test addVertex with old name");

		try
		{
			g.addLabelVertex(new LabelVertexImpl("1"));
		}
		catch (DuplicateLabelException e)
		{
			e.printStackTrace();
		}

		System.err.println(g);

		System.err.println("--------------------------------------------------------------------------------");
		System.err.println("Test setLabel on a Vertex PropertyVetoException");

		v = g.getLabelVertex("1");

		try
		{
			v.setLabel("4");
		}
		catch (PropertyVetoException e)
		{
			System.err.println("******************** This is ok");
			e.printStackTrace();
		}

		System.err.println(g);
	}

	// TODO: Test LabelEdge "label"
}
