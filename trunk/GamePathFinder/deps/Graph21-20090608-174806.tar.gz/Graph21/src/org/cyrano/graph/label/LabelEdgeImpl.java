/*
 * Created on Mar 30, 2004
 */
package org.cyrano.graph.label;

import java.beans.PropertyVetoException;

import javax.swing.event.EventListenerList;

import org.cyrano.graph.base.EdgeImpl;
import org.cyrano.graph.event.LabelChangeEvent;
import org.cyrano.graph.event.LabelChangeListener;

/**
 * @author DMI: Demian Gutierrez
 */
public class LabelEdgeImpl extends EdgeImpl implements LabelEdge
{
	private EventListenerList eventListenerList = new EventListenerList();

	private String label;

	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public LabelEdgeImpl()
	{
		// Empty
	}

	/**
	 *
	 *
	 * @param src
	 * @param dst
	 * @param dta
	 */
	public LabelEdgeImpl(Object src, Object dst, Object dta)
	{
		super(src, dst, dta);
	}

	/**
	 *
	 *
	 * @param src
	 * @param dst
	 * @param dta
	 * @param label
	 */
	public LabelEdgeImpl(Object src, Object dst, Object dta, String label)
	{
		super(src, dst, dta);

		this.label = label;
	}

	// --------------------------------------------------------------------------------
	// LabelEdge
	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public void addLabelChangeListener(LabelChangeListener listener)
	{
		eventListenerList.add(LabelChangeListener.class, listener);
	}

	/**
	 *
	 */
	public LabelChangeListener[] getLabelChangeListeners()
	{
		return (LabelChangeListener[]) eventListenerList.getListeners(LabelChangeListener.class);
	}

	/**
	 *
	 */
	public void removeLabelChangeListener(LabelChangeListener listener)
	{
		eventListenerList.remove(LabelChangeListener.class, listener);
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public String getLabel()
	{
		return label;
	}

	/**
	 *
	 */
	public void setLabel(String label) throws PropertyVetoException
	{
		fireLabelChangeEvent(this.label, label);

		this.label = label;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	private void fireLabelChangeEvent(String oldLabel, String newLabel) throws PropertyVetoException
	{
		if (!oldLabel.equals(newLabel))
		{
			LabelChangeEvent evt = new LabelChangeEvent(this, oldLabel, newLabel);

			LabelChangeListener[] labelChangeListeners = getLabelChangeListeners();

			for (int i = 0; i < labelChangeListeners.length; i++)
			{
				labelChangeListeners[i].labelChange(evt);
			}
		}
	}
}
