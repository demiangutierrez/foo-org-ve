/*
 * Created on Mar 30, 2004
 */
package org.cyrano.graph.label;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class DuplicateLabelException extends Exception
{
	/**
	 * 
	 */
	public DuplicateLabelException()
	{
		super();
	}

	/**
	 * @param message
	 */
	public DuplicateLabelException(String message)
	{
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public DuplicateLabelException(String message, Throwable cause)
	{
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public DuplicateLabelException(Throwable cause)
	{
		super(cause);
	}
}
