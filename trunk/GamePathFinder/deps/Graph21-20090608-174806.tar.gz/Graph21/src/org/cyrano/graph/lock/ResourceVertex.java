/*
 * Created on Apr 1, 2004
 */
package org.cyrano.graph.lock;

import java.util.LinkedList;

/**
 * @author DMI: Demian Gutierrez
 */
public class ResourceVertex
{
	private LinkedList requestQueue = new LinkedList();

	/**
	 * 
	 */
	public ResourceVertex()
	{
		// Empty
	}

	/**
	 * 
	 */
	public void addRequest(Object thId)
	{
	}

}
