/*
 * Created on Mar 13, 2004
 */
package org.cyrano.graph.event;

import java.beans.PropertyVetoException;
import java.util.EventListener;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface LabelChangeListener extends EventListener
{
	/**
	 *
	 *
	 * @param evt
	 */
	public void labelChange(LabelChangeEvent evt) throws PropertyVetoException;
}
