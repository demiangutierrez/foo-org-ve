/*
 * Created on Mar 24, 2004
 */
package org.cyrano.graph.base;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class NullIterator implements Iterator
{
	/**
	 *
	 */
	public NullIterator()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// Iterator
	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public boolean hasNext()
	{
		return false;
	}

	/**
	 *
	 */
	public Object next()
	{
		throw new NoSuchElementException();
	}

	/**
	 *
	 */
	public void remove()
	{
		throw new NoSuchElementException();
	}
}
