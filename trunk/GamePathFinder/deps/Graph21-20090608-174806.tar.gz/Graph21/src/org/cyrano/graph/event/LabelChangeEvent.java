/*
 * Created on Mar 30, 2004
 */
package org.cyrano.graph.event;

import java.util.EventObject;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class LabelChangeEvent extends EventObject
{
	private String oldLabel;

	private String newLabel;

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param source
	 * @param oldLabel
	 * @param newLabel
	 */
	public LabelChangeEvent(Object source, String oldLabel, String newLabel)
	{
		super(source);

		this.oldLabel = oldLabel;

		this.newLabel = newLabel;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public String getOldLabel()
	{
		return oldLabel;
	}

	/**
	 *
	 *
	 * @return
	 */
	public String getNewLabel()
	{
		return newLabel;
	}
}
