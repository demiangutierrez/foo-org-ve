/*
 * Created on Mar 24, 2004
 */
package org.cyrano.graph.base;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface Edge
{
	/**
	 *
	 *
	 * @return
	 */
	public Object getSrc();

	/**
	 *
	 *
	 * @param src
	 */
	public void setSrc(Object src);

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Object getDst();

	/**
	 *
	 *
	 * @param dst
	 */
	public void setDst(Object dst);
}
