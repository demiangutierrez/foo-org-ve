/*
 * Created on Mar 29, 2004
 */
package org.cyrano.graph.label;

import org.cyrano.graph.base.Edge;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface LabelEdge extends Edge, LabelItem
{
	// Empty
}
