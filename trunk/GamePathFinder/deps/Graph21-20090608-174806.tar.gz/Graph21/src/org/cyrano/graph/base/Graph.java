/*
 * Created on Mar 29, 2004
 */
package org.cyrano.graph.base;

import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class Graph
{
	/*
	 * Key: Vertex's id.
	 *
	 * Value: Vertex outgoing edges.
	 */
	protected Map srcMap = new HashMap();

	/*
	 * Key: Vertex's id.
	 *
	 * Value: Vertex incoming edges.
	 */
	protected Map dstMap = new HashMap();

	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public Graph()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// Vertex add / get / remove
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param vertex
	 *
	 * @return
	 */
	public Object addVertex(Object vertex)
	{
		if (srcMap.get(vertex) == null)
		{
			srcMap.put(vertex, new HashMap());
			dstMap.put(vertex, new HashMap());
		}

		return null;
	}

	/**
	 *
	 *
	 * @param vertex 
	 *
	 * @return
	 */
	public Object getVertex(Object vertex)
	{
		return srcMap.get(vertex) != null ? vertex : null;
	}

	/**
	 *
	 *
	 * @param vertex
	 *
	 * @return
	 */
	public Object removeVertex(Object vertex)
	{
		Edge[] edges;

		edges = (Edge[]) toSrcEdgeArray(vertex, new Edge[0]);

		for (int i = 0; i < edges.length; i++)
		{
			removeEdge(edges[i]);
		}

		edges = (Edge[]) toDstEdgeArray(vertex, new Edge[0]);

		for (int i = 0; i < edges.length; i++)
		{
			removeEdge(edges[i]);
		}

		srcMap.remove(vertex);

		return dstMap.remove(vertex) != null ? vertex : null;
	}

	// --------------------------------------------------------------------------------
	// Vertex iterator / array
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Iterator vertexIterator()
	{
		return srcMap.keySet().iterator();
	}

	/**
	 *
	 *
	 * @return
	 */
	public Object[] toVertexArray()
	{
		return toVertexArray(new Object[0]);
	}

	/**
	 *
	 *
	 * @param array
	 *
	 * @return
	 */
	public Object[] toVertexArray(Object[] array)
	{
		return srcMap.keySet().toArray(array);
	}

	// --------------------------------------------------------------------------------
	// Edge add / get / remove
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param edge
	 *
	 * @return
	 */
	public Edge addEdge(Edge edge)
	{
		Edge ret = getEdge(edge);

		addVertex(edge.getSrc());
		addVertex(edge.getDst());

		Map edges;

		edges = (Map) srcMap.get(edge.getSrc());
		edges.put(edge.getDst(), edge);

		edges = (Map) dstMap.get(edge.getDst());
		edges.put(edge.getSrc(), edge);

		return ret;
	}

	/**
	 *
	 *
	 * @param edge
	 *
	 * @return
	 */
	public Edge getEdge(Edge edge)
	{
		return getEdge(edge.getSrc(), edge.getDst());
	}

	/**
	 *
	 *
	 * @param src
	 * @param dst
	 *
	 * @return
	 */
	public Edge getEdge(Object src, Object dst)
	{
		Edge ret = null;

		Map edges = (Map) srcMap.get(src);

		if (edges != null)
		{
			ret = (Edge) edges.get(dst);
		}

		return ret;
	}

	/**
	 *
	 *
	 * @param edge
	 *
	 * @return
	 */
	public Edge removeEdge(Edge edge)
	{
		return removeEdge(edge.getSrc(), edge.getDst());
	}

	/**
	 *
	 *
	 * @param src
	 * @param dst
	 *
	 * @return
	 */
	public Edge removeEdge(Object src, Object dst)
	{
		Edge ret = null;

		Map edges = (Map) srcMap.get(src);

		if (edges != null)
		{
			edges.remove(dst);

			edges = (Map) dstMap.get(dst);

			ret = (Edge) edges.remove(src);
		}

		return ret;
	}

	// --------------------------------------------------------------------------------
	// Edge iterator / array
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Iterator edgeIterator()
	{
		return new EdgeIterator(this);
	}

	/**
	 *
	 *
	 * @param src
	 *
	 * @return
	 */
	public Iterator srcEdgeIterator(Object src)
	{
		Map edges = (Map) srcMap.get(src);

		if (edges == null)
		{
			return new NullIterator();
		}

		return edges.values().iterator();
	}

	/**
	 *
	 *
	 * @param dst
	 *
	 * @return
	 */
	public Iterator dstEdgeIterator(Object dst)
	{
		Map edges = (Map) dstMap.get(dst);

		if (edges == null)
		{
			return new NullIterator();
		}

		return edges.values().iterator();
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Object[] toEdgeArray()
	{
		return toEdgeArray(new Object[0]);
	}

	/**
	 *
	 * @param array
	 *
	 * @return
	 */
	public Object[] toEdgeArray(Object[] array)
	{
		Vector ret = new Vector();

		Iterator itt = edgeIterator();

		while (itt.hasNext())
		{
			ret.add(itt.next());
		}

		return ret.toArray(array);
	}

	/**
	 *
	 *
	 * @param src
	 *
	 * @return
	 */
	public Object[] toSrcEdgeArray(Object src)
	{
		return toSrcEdgeArray(src, new Object[0]);
	}

	/**
	 *
	 *
	 * @param src
	 * @param array
	 *
	 * @return
	 */
	public Object[] toSrcEdgeArray(Object src, Object[] array)
	{
		Map edges = (Map) srcMap.get(src);

		if (edges == null)
		{
			return (Object[]) Array.newInstance(array.getClass().getComponentType(), 0);
		}

		return edges.values().toArray(array);
	}

	/**
	 *
	 *
	 * @param dst
	 *
	 * @return
	 */
	public Object[] toDstEdgeArray(Object dst)
	{
		return toDstEdgeArray(dst, new Object[0]);
	}

	/**
	 *
	 *
	 * @param dst
	 * @param array
	 *
	 * @return
	 */
	public Object[] toDstEdgeArray(Object dst, Object[] array)
	{
		Map edges = (Map) dstMap.get(dst);

		if (edges == null)
		{
			return (Object[]) Array.newInstance(array.getClass().getComponentType(), 0);
		}

		return edges.values().toArray(array);
	}

	// --------------------------------------------------------------------------------
	// Misc
	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();

		ret.append(super.toString());
		ret.append("\n");

		Iterator sItt = vertexIterator();

		while (sItt.hasNext())
		{
			Object src = (Object) sItt.next();

			ret.append(src);
			ret.append(": ");

			Iterator dItt = srcEdgeIterator(src);

			while (dItt.hasNext())
			{
				Edge edge = (Edge) dItt.next();

				ret.append("[");
				ret.append(edge.getDst());
				ret.append(", ");
				ret.append(edge);
				ret.append("]");

				if (dItt.hasNext())
				{
					ret.append(", ");
				}
			}

			if (sItt.hasNext())
			{
				ret.append("\n");
			}
		}

		return ret.toString();
	}
}
