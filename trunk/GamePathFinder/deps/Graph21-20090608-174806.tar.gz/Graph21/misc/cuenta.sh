C=0

for i in `find $2 | grep [.]$1`; do
	T=`wc -l $i | awk '{print $1}' -`;
	C=`expr $C + $T`;
done

echo $2 $1 $C
