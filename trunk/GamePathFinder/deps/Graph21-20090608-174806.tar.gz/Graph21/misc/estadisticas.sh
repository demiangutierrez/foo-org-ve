XML=`sh cuenta.sh xml $1 | awk '{print $3}' -`
JAVA=`sh cuenta.sh java $1 | awk '{print $3}' -`
PROPERTIES=`sh cuenta.sh properties $1 | awk '{print $3}' -`
TEX=`sh cuenta.sh tex $1 | awk '{print $3}' -`


echo xml"  "= $XML
echo java = $JAVA
echo prop = $PROPERTIES
echo tex"  "= $TEX
echo -----------------------------------

TOTAL=`expr $XML + $JAVA + $PROPERTIES + $TEX`

echo tot"  "= $TOTAL
