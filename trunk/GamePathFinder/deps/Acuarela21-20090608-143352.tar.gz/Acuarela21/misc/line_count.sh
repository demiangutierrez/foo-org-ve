if [ "$1" = "--help" -o "$1" = "-h" -o "$1" = "" -o "$2" = "" ]; then
    echo USAGE: $0 "<EXTENSION> <PATH>"
    exit
fi

C=0

for i in `find $2 | grep [.]$1`; do
    T=`wc -l $i | awk '{print $1}' -`;
    C=`expr $C + $T`;
done

echo $2 $1 $C
