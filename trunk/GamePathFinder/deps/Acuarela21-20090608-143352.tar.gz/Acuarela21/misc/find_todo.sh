for i in `find . | grep java`
do
  if [ -n "`cat $i | grep TODO`" ]; then
      echo $i
      grep TODO $i -n
      echo ""
  fi
done
