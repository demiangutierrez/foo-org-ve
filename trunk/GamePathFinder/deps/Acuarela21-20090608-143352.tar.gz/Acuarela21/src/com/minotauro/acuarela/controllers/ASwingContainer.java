/*
 * Created on Dec 25, 2004
 */
package com.minotauro.acuarela.controllers;

import java.awt.Container;
import java.awt.event.MouseEvent;


import com.minotauro.acuarela.base.AController;
import com.minotauro.acuarela.base.ACtrlPoint;
import com.minotauro.acuarela.event.AControllerMouseEvent;
import com.minotauro.acuarela.event.AControllerMouseListener;
import com.minotauro.acuarela.event.AMotionEvent;
import com.minotauro.acuarela.event.AMotionException;
import com.minotauro.acuarela.event.AMotionListener;
import com.minotauro.acuarela.event.ARepaintEvent;
import com.minotauro.acuarela.util.ATracer;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class ASwingContainer extends ARectangle
{
	protected Container container;

	protected boolean valid;

	/**
	 *
	 */
	public ASwingContainer()
	{
		// Empty
	}

	/**
	 *
	 *
	 * @param ctrlBeg
	 * @param ctrlEnd
	 */
	public ASwingContainer(ACtrlPoint ctrlBeg, ACtrlPoint ctrlEnd)
	{
		super(ctrlBeg, ctrlEnd);

		AMotionListener aMotionListener = new AMotionListener()
		{
			public void controllerMoved(AMotionEvent evt) throws AMotionException
			{
				valid = false;

				container.setSize(getBounds().getW(), getBounds().getH());
			}
		};

		ctrlBeg.addMotionListener(aMotionListener);
		ctrlEnd.addMotionListener(aMotionListener);
		ctrlBegAux.addMotionListener(aMotionListener);
		ctrlEndAux.addMotionListener(aMotionListener);

		addControllerMouseListener(new AControllerMouseListener()
		{
			public void translateMouseEvent(AControllerMouseEvent evt)
			{
				AController aController = evt.getController();
				MouseEvent mouseEvent = evt.getMouseEvent();

				mouseEvent.translatePoint(-aController.getBounds().x, -aController.getBounds().y);
			}

			public void controllerMouseClicked(AControllerMouseEvent evt)
			{
				ATracer.trace("BEG");
				translateMouseEvent(evt);
				container.dispatchEvent(evt.getMouseEvent());
				fireRepaintEvent(new ARepaintEvent(evt.getController()));
			}

			public void controllerMouseEntered(AControllerMouseEvent evt)
			{
				ATracer.trace("BEG");
				translateMouseEvent(evt);
				container.dispatchEvent(evt.getMouseEvent());
				fireRepaintEvent(new ARepaintEvent(evt.getController()));
			}

			public void controllerMouseExited(AControllerMouseEvent evt)
			{
				ATracer.trace("BEG");
				translateMouseEvent(evt);
				container.dispatchEvent(evt.getMouseEvent());
				fireRepaintEvent(new ARepaintEvent(evt.getController()));
			}

			public void controllerMousePressed(AControllerMouseEvent evt)
			{
				ATracer.trace("BEG");
				translateMouseEvent(evt);
				container.dispatchEvent(evt.getMouseEvent());
				fireRepaintEvent(new ARepaintEvent(evt.getController()));
			}

			public void controllerMouseReleased(AControllerMouseEvent evt)
			{
				ATracer.trace("BEG");
				translateMouseEvent(evt);
				container.dispatchEvent(evt.getMouseEvent());
				fireRepaintEvent(new ARepaintEvent(evt.getController()));
			}

			public void controllerMouseDragged(AControllerMouseEvent evt)
			{
				ATracer.trace("BEG");
				translateMouseEvent(evt);
				container.dispatchEvent(evt.getMouseEvent());
				fireRepaintEvent(new ARepaintEvent(evt.getController()));
			}

			public void controllerMouseMoved(AControllerMouseEvent evt)
			{
				ATracer.trace("BEG");
				translateMouseEvent(evt);
				container.dispatchEvent(evt.getMouseEvent());
				fireRepaintEvent(new ARepaintEvent(evt.getController()));
			}
		});
	}

	/**
	 *
	 *
	 * @return
	 */
	public Container getContainer()
	{
		return container;
	}

	/**
	 *
	 *
	 * @param container
	 */
	public void setContainer(Container container)
	{
		this.container = container;

		container.setSize(getBounds().getW(), getBounds().getH());
	}

	/**
	 *
	 *
	 * @return
	 */
	public boolean isValid()
	{
		return valid;
	}

	/**
	 *
	 *
	 * @param valid
	 */
	public void setValid(boolean valid)
	{
		this.valid = valid;
	}
}