/*
 * Created on Jul 18, 2004
 */
package com.minotauro.acuarela.base;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public abstract class AEdgeImpl extends AControllerImpl implements AEdge
{
	/**
	 *
	 */
	public AEdgeImpl()
	{
		// Empty
	}
}
