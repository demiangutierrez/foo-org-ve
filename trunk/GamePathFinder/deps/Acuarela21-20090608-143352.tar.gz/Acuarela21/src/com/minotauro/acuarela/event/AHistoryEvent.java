/*
 * Created on Dec 18, 2004
 */
package com.minotauro.acuarela.event;

import java.util.EventObject;

import com.minotauro.acuarela.base.AHistoryEntry;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class AHistoryEvent extends EventObject
{
	public static final int ACTION_EXECUTE = 0;

	public static final int ACTION_REDO = 1;

	public static final int ACTION_UNDO = 2;

	private AHistoryEntry historyEntry;

	private int action;

	/**
	 *
	 *
	 * @param source
	 * @param historyEntry
	 */
	public AHistoryEvent(Object source, AHistoryEntry historyEntry, int action)
	{
		super(source);

		this.historyEntry = historyEntry;
		this.action = action;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public AHistoryEntry getHistoryEntry()
	{
		return historyEntry;
	}

	/**
	 *
	 *
	 * @param historyEntry
	 */
	public void setHistoryEntry(AHistoryEntry historyEntry)
	{
		this.historyEntry = historyEntry;
	}

	/**
	 *
	 *
	 * @return
	 */
	public int getAction()
	{
		return action;
	}

	/**
	 *
	 *
	 * @param action
	 */
	public void setAction(int action)
	{
		this.action = action;
	}
}