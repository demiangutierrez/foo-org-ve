package com.minotauro.acuarela.test.nogui.f;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.apache.commons.lang.ClassUtils;

public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite(ClassUtils.getPackageName(AllTests.class));

    //$JUnit-BEGIN$
    suite.addTestSuite(TestF0.class);
    suite.addTestSuite(TestF1.class);
    suite.addTestSuite(TestF2.class);
    suite.addTestSuite(TestF3.class);
    suite.addTestSuite(TestF4.class);
    suite.addTestSuite(TestF5.class);
    suite.addTestSuite(TestF6.class);
    suite.addTestSuite(TestF7.class);
    suite.addTestSuite(TestF8.class);
    suite.addTestSuite(TestF9.class);
    //$JUnit-END$

    return suite;
  }
}
