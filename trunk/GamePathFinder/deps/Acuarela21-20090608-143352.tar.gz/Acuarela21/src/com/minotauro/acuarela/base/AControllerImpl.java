/*
 * Created on Jul 17, 2004
 */
package com.minotauro.acuarela.base;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.beans.PropertyVetoException;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.event.EventListenerList;

import org.cyrano.graph.event.LabelChangeEvent;
import org.cyrano.graph.event.LabelChangeListener;
import org.cyrano.graph.label.LabelItem;

import com.minotauro.acuarela.event.AControllerMouseEvent;
import com.minotauro.acuarela.event.AControllerMouseListener;
import com.minotauro.acuarela.event.AMotionEvent;
import com.minotauro.acuarela.event.AMotionException;
import com.minotauro.acuarela.event.AMotionListener;
import com.minotauro.acuarela.event.ARepaintEvent;
import com.minotauro.acuarela.event.ARepaintListener;
import com.minotauro.acuarela.util.ADist;
import com.minotauro.acuarela.util.ARect;

/**
 * @author DMI: Demian Gutierrez
 */
public abstract class AControllerImpl implements AController, LabelItem {

  protected EventListenerList eventListenerList = new EventListenerList();

  // --------------------------------------------------------------------------------

  protected boolean completeMotionEventDisable;

  // --------------------------------------------------------------------------------

  protected LinkedList controllerList = new LinkedList();

  protected LinkedList ctrlPointList = new LinkedList();

  protected LinkedList dependentList = new LinkedList();

  protected LinkedList rendererList = new LinkedList();

  // --------------------------------------------------------------------------------

  protected String name;

  protected ACanvas canvas;

  protected AController parent;

  // --------------------------------------------------------------------------------

  protected boolean initialized;

  protected boolean visible;

  protected boolean disable;

  protected boolean selected;

  protected boolean dragging;

  protected boolean movable;

  protected boolean client;

  // --------------------------------------------------------------------------------

  /**
   *
   */
  public AControllerImpl() {
    // Empty
  }

  // --------------------------------------------------------------------------------
  // AMotionListener methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public void addMotionListener(AMotionListener listener) {
    eventListenerList.add(AMotionListener.class, listener);
  }

  /**
   *
   */
  public void delMotionListener(AMotionListener listener) {
    eventListenerList.remove(AMotionListener.class, listener);
  }

  /**
   *
   */
  public AMotionListener[] getMotionListeners() {
    return (AMotionListener[]) eventListenerList.getListeners(AMotionListener.class);
  }

  /**
   *
   */
  public void fireMotionEvent(AMotionEvent evt) throws AMotionException {
    if (completeMotionEventDisable) {
      return;
    }

    AMotionListener[] listeners = getMotionListeners();

    for (int i = 0; i < listeners.length; i++) {
      listeners[i].controllerMoved(evt);
    }
  }

  // --------------------------------------------------------------------------------
  // ARepaintListener methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public void addRepaintListener(ARepaintListener listener) {
    eventListenerList.add(ARepaintListener.class, listener);
  }

  /**
   *
   */
  public void delRepaintListener(ARepaintListener listener) {
    eventListenerList.remove(ARepaintListener.class, listener);
  }

  /**
   *
   */
  public ARepaintListener[] getRepaintListeners() {
    return (ARepaintListener[]) eventListenerList.getListeners(ARepaintListener.class);
  }

  /**
   *
   */
  public void fireRepaintEvent(ARepaintEvent evt) {
    ARepaintListener[] listeners = getRepaintListeners();

    for (int i = 0; i < listeners.length; i++) {
      listeners[i].repaintRequest(evt);
    }
  }

  // --------------------------------------------------------------------------------
  // AControllerMouseListener methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public void addControllerMouseListener(AControllerMouseListener listener) {
    eventListenerList.add(AControllerMouseListener.class, listener);
  }

  /**
   *
   */
  public void delControllerMouseListener(AControllerMouseListener listener) {
    eventListenerList.remove(AControllerMouseListener.class, listener);
  }

  /**
   *
   */
  public AControllerMouseListener[] getControllerMouseListeners() {
    return (AControllerMouseListener[]) eventListenerList.getListeners(AControllerMouseListener.class);
  }

  /**
   *
   */
  public void fireControllerMouseEvent(int method, AControllerMouseEvent evt) {
    // AControllerMouseEvent is used (not building the event here)
    // in order to share the same event between all the listeners
    AControllerMouseListener[] listener = getControllerMouseListeners();

    for (int i = 0; i < listener.length; i++) {
      switch (method) {
        case AControllerMouseListener.CONTROLLER_MOUSE_CLICKED :
          listener[i].controllerMouseClicked(evt);
          break;

        case AControllerMouseListener.CONTROLLER_MOUSE_ENTERED :
          listener[i].controllerMouseEntered(evt);
          break;

        case AControllerMouseListener.CONTROLLER_MOUSE_EXITED :
          listener[i].controllerMouseExited(evt);
          break;

        case AControllerMouseListener.CONTROLLER_MOUSE_PRESSED :
          listener[i].controllerMousePressed(evt);
          break;

        case AControllerMouseListener.CONTROLLER_MOUSE_RELEASED :
          listener[i].controllerMouseReleased(evt);
          break;

        case AControllerMouseListener.CONTROLLER_MOUSE_DRAGGED :
          listener[i].controllerMouseDragged(evt);
          break;

        case AControllerMouseListener.CONTROLLER_MOUSE_MOVED :
          listener[i].controllerMouseMoved(evt);
          break;
      }
    }

    // Forward the event to all the controllers
    AController[] aControllers = toControllerArray();

    for (int i = 0; i < aControllers.length; i++) {
      // Set controller in the event
      evt.setController(aControllers[i]);

      aControllers[i].fireControllerMouseEvent(method, evt);

      // Break if the event was consumed
      if (evt.isConsumed()) {
        break;
      }
    }
  }

  // --------------------------------------------------------------------------------
  // MotionEventDisable methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public void setCompleteMotionEventDisable(boolean motionEventDisable) {
    completeMotionEventDisable = motionEventDisable;

    setControllerMotionEventDisable(motionEventDisable);
    setCtrlPointMotionEventDisable(motionEventDisable);
  }

  /**
   *
   */
  public void setControllerMotionEventDisable(boolean motionEventDisable) {
    Iterator itt = controllerIterator();

    while (itt.hasNext()) {
      AController controller = (AController) itt.next();

      controller.setCompleteMotionEventDisable(motionEventDisable);
    }
  }

  /**
   *
   */
  public void setCtrlPointMotionEventDisable(boolean motionEventDisable) {
    Iterator itt = ctrlPointIterator();

    while (itt.hasNext()) {
      ACtrlPoint ctrlPoint = (ACtrlPoint) itt.next();

      ctrlPoint.setCompleteMotionEventDisable(motionEventDisable);
    }
  }

  // --------------------------------------------------------------------------------
  // Controller methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public void addController(AController controller) {
    if (controllerList.contains(controller)) {
      return;
    }

    AController prev = getController(controller.getName());

    if (prev != null) {
      delController(prev);
    }

    controllerList.add(controller);

    controller.setParent(this);
    controller.setCanvas(canvas);
  }

  /**
   *
   */
  public AController getController(String name) {
    Iterator itt = controllerIterator();

    while (itt.hasNext()) {
      AController controller = (AController) itt.next();

      if (name.equals(controller.getName())) {
        return controller;
      }
    }

    return null;
  }

  /**
   *
   */
  public AController getController(int x, int y) {
    Iterator itt = controllerIterator();

    while (itt.hasNext()) {
      AController controller = (AController) itt.next();

      Shape shape = controller.getShape();

      if (shape.contains(x, y)) {
        // Get the first not disable parent
        AController ret = controller;

        while (ret != null && ret.getDisable()) {
          ret = ret.getParent();
        }

        return ret;
      }
    }

    if (getShape().contains(x, y) && !disable) {
      return this;
    }

    return null;
  }

  /**
   *
   */
  public void delController(AController controller) {
    if (!controllerList.remove(controller)) {
      return;
    }

    controller.setCanvas(null);
    controller.setParent(null);
  }

  /**
   *
   */
  public Iterator controllerIterator() {
    return controllerList.iterator();
  }

  /**
   *
   */
  public AController[] toControllerArray() {
    return (AController[]) controllerList.toArray(new AController[0]);
  }

  // --------------------------------------------------------------------------------
  // CtrlPoint methods
  // --------------------------------------------------------------------------------

  public void addCtrlPoint(ACtrlPoint ctrlPoint) {
    if (ctrlPointList.contains(ctrlPoint)) {
      return;
    }

    ctrlPointList.add(ctrlPoint);

    addController(ctrlPoint);
  }

  public void addCtrlPoint(int index, ACtrlPoint ctrlPoint) {
    if (ctrlPointList.contains(ctrlPoint)) {
      return;
    }

    ctrlPointList.add(index, ctrlPoint);

    addController(ctrlPoint);
  }

  /**
   *
   */
  public ACtrlPoint getCtrlPoint(String name) {
    Iterator itt = dependentIterator();

    while (itt.hasNext()) {
      ACtrlPoint ctrlPoint = (ACtrlPoint) itt.next();

      if (name.equals(ctrlPoint.getName())) {
        return ctrlPoint;
      }
    }

    return null;
  }

  /**
   *
   */
  public ACtrlPoint getCtrlPoint(int x, int y) {
    Iterator itt = dependentIterator();

    while (itt.hasNext()) {
      ACtrlPoint ctrlPoint = (ACtrlPoint) itt.next();

      Shape shape = ctrlPoint.getShape();

      if (shape.contains(x, y) && !ctrlPoint.getDisable()) {
        return ctrlPoint;
      }
    }

    return null;
  }

  /**
   *
   */
  public void delCtrlPoint(ACtrlPoint ctrlPoint) {
    if (!ctrlPointList.remove(ctrlPoint)) {
      return;
    }

    delController(ctrlPoint);
  }

  /**
   *
   */
  public Iterator ctrlPointIterator() {
    return ctrlPointList.iterator();
  }

  /**
   *
   */
  public ACtrlPoint[] toCtrlPointArray() {
    return (ACtrlPoint[]) ctrlPointList.toArray(new ACtrlPoint[0]);
  }

  // --------------------------------------------------------------------------------
  // Dependent methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public void addDependent(AController controller) {
    if (dependentList.contains(controller)) {
      return;
    }

    dependentList.add(controller);
  }

  /**
   *
   */
  public AController getDependent(String name) {
    Iterator itt = dependentIterator();

    while (itt.hasNext()) {
      AController controller = (AController) itt.next();

      if (name.equals(controller.getName())) {
        return controller;
      }
    }

    return null;
  }

  /**
   *
   */
  public AController getDependent(int x, int y) {
    Iterator itt = dependentIterator();

    while (itt.hasNext()) {
      AController controller = (AController) itt.next();

      Shape shape = controller.getShape();

      if (shape.contains(x, y) && !controller.getDisable()) {
        return controller;
      }
    }

    return null;
  }

  /**
   *
   */
  public void delDependent(AController controller) {
    dependentList.remove(controller);
  }

  /**
   *
   */
  public Iterator dependentIterator() {
    return dependentList.iterator();
  }

  /**
   *
   */
  public AController[] toDependentArray() {
    return (AController[]) dependentList.toArray(new AController[0]);
  }

  // --------------------------------------------------------------------------------
  // Move methods
  // --------------------------------------------------------------------------------

  public void moveBeg() {
  }

  public void moveEnd() {
  }

  public void move(int dx, int dy) {
    AMotionEvent evt = new AMotionEvent(this);

    try {
      move(dx, dy, evt);
    } catch (AMotionException e) {
      Iterator itt = evt.controllerIterator();

      while (itt.hasNext()) {
        AController controller = (AController) itt.next();

        ADist dist = evt.getController(controller);

        controller.move(-dist.getDx(), -dist.getDy());
      }
    }
  }

  public void move(int dx, int dy, AMotionEvent evt) throws AMotionException {
    setControllerMotionEventDisable(true);

    if (evt.getController(this) != null) {
      return;
    }

    Iterator itt = controllerIterator();

    while (itt.hasNext()) {
      AController controller = (AController) itt.next();

      controller.move(dx, dy, evt);
    }

    fireMotionEvent(evt);

    setControllerMotionEventDisable(false);
  }

  // --------------------------------------------------------------------------------
  // Paint methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public void paint(Graphics2D g2d) {
    if (!visible) {
      return;
    }

    Iterator itt = rendererIterator();

    while (itt.hasNext()) {
      ARenderer renderer = (ARenderer) itt.next();

      renderer.paint(g2d, this);
    }

    itt = controllerIterator();

    while (itt.hasNext()) {
      AController controller = (AController) itt.next();

      // TODO: This limits a lot the possibilities of the control points
      if (controller instanceof ACtrlPoint && !selected) {
        continue;
      }

      controller.paint(g2d);
    }
  }

  // --------------------------------------------------------------------------------
  // Renderer methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public void addRenderer(ARenderer renderer) {
    if (rendererList.contains(renderer)) {
      return;
    }

    rendererList.add(renderer);
  }

  /**
   *
   */
  public ARenderer getRenderer(String name) {
    Iterator itt = rendererIterator();

    while (itt.hasNext()) {
      ARenderer renderer = (ARenderer) itt.next();

      if (name.equals(renderer.getName())) {
        return renderer;
      }
    }

    return null;
  }

  /**
   *
   */
  public void delRenderer(ARenderer renderer) {
    rendererList.remove(renderer);
  }

  /**
   *
   */
  public Iterator rendererIterator() {
    return rendererList.iterator();
  }

  /**
   *
   */
  public ARenderer[] toRendererArray() {
    return (ARenderer[]) rendererList.toArray(new ARenderer[0]);
  }

  // --------------------------------------------------------------------------------
  // Bounds methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public ARect getBounds() {
    return ARect.r(getShape().getBounds());
  }

  /**
   *
   */
  public ARect getFullBounds() {
    Rectangle ret = getBounds();

    Iterator itt = controllerIterator();

    while (itt.hasNext()) {
      AController controller = (AController) itt.next();

      if (controller instanceof ACtrlPoint) {
        continue;
      }

      ret = ret.union(controller.getFullBounds());
    }

    return ARect.r(ret);
  }

  // --------------------------------------------------------------------------------
  // Geometry methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public abstract Shape getShape();

  // --------------------------------------------------------------------------------
  // Name methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public String getFullName() {
    return parent.getFullName() + "." + getName();
  }

  // --------------------------------------------------------------------------------
  // Properties methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public String getName() {
    return name;
  }

  /**
   *
   */
  public void setName(String name) {
    this.name = name;
  }

  // --------------------------------------------------------------------------------

  /**
   *
   */
  public ACanvas getCanvas() {
    return canvas;
  }

  /**
   *
   */
  public void setCanvas(ACanvas canvas) {
    this.canvas = canvas;
  }

  // --------------------------------------------------------------------------------

  /**
   *
   */
  public AController getParent() {
    return parent;
  }

  /**
   *
   */
  public void setParent(AController parent) {
    this.parent = parent;
  }

  public AController getTopParent() {
    return parent == null ? this : parent.getTopParent();
  }

  // --------------------------------------------------------------------------------
  // Flags methods
  //
  // Flags are:
  //
  // initialized
  // visible
  // disable
  // selected
  // dragging
  // movable
  // client
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public boolean getInitialized() {
    return initialized;
  }

  /**
   *
   */
  public void setInitialized(boolean initialized) {
    this.initialized = initialized;
  }

  // --------------------------------------------------------------------------------

  /**
   *
   */
  public boolean getVisible() {
    return visible;
  }

  /**
   *
   */
  public void setVisible(boolean visible) {
    this.visible = visible;
  }

  // --------------------------------------------------------------------------------

  /**
   *
   */
  public boolean getDisable() {
    return disable;
  }

  /**
   *
   */
  public void setDisable(boolean disable) {
    this.disable = disable;
  }

  // --------------------------------------------------------------------------------

  /**
   *
   */
  public boolean getSelected() {
    return selected;
  }

  /**
   *
   */
  public void setSelected(boolean selected) {
    this.selected = selected;
  }

  // --------------------------------------------------------------------------------

  /**
   *
   */
  public boolean getDragging() {
    return dragging;
  }

  /**
   *
   */
  public void setDragging(boolean dragging) {
    this.dragging = dragging;
  }

  // --------------------------------------------------------------------------------

  /**
   *
   */
  public boolean getMovable() {
    return movable;
  }

  /**
   *
   */
  public void setMovable(boolean movable) {
    this.movable = movable;
  }

  // --------------------------------------------------------------------------------

  /**
   *
   */
  public boolean getClient() {
    return client;
  }

  /**
   *
   */
  public void setClient(boolean client) {
    this.client = client;
  }

  // --------------------------------------------------------------------------------
  // LabelItem
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public void addLabelChangeListener(LabelChangeListener listener) {
    eventListenerList.add(LabelChangeListener.class, listener);
  }

  /**
   *
   */
  public LabelChangeListener[] getLabelChangeListeners() {
    return (LabelChangeListener[]) eventListenerList.getListeners(LabelChangeListener.class);
  }

  /**
   *
   */
  public void removeLabelChangeListener(LabelChangeListener listener) {
    eventListenerList.remove(LabelChangeListener.class, listener);
  }

  // --------------------------------------------------------------------------------

  /**
   *
   */
  public String getLabel() {
    return getName();
  }

  /**
   *
   */
  public void setLabel(String label) throws PropertyVetoException {
    fireLabelChangeEvent(name, label);

    setName(label);
  }

  // --------------------------------------------------------------------------------

  /**
   *
   */
  private void fireLabelChangeEvent(String oldLabel, String newLabel) throws PropertyVetoException {
    if (!oldLabel.equals(newLabel)) {
      LabelChangeEvent evt = new LabelChangeEvent(this, oldLabel, newLabel);

      LabelChangeListener[] labelChangeListeners = getLabelChangeListeners();

      for (int i = 0; i < labelChangeListeners.length; i++) {
        labelChangeListeners[i].labelChange(evt);
      }
    }
  }
}