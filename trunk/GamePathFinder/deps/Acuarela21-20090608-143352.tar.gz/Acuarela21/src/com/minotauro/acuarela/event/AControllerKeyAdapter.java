/*
 * Created on Dec 18, 2004
 */
package com.minotauro.acuarela.event;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class AControllerKeyAdapter implements AControllerKeyListener
{
	/**
	 *
	 */
	public AControllerKeyAdapter()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// AControllerKeyListener
	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public void controllerKeyPressed(AControllerKeyEvent evt)
	{
		// Empty
	}

	/**
	 *
	 */
	public void controllerKeyReleased(AControllerKeyEvent evt)
	{
		// Empty
	}

	/**
	 *
	 */
	public void controllerKeyTyped(AControllerKeyEvent evt)
	{
		// Empty
	}
}