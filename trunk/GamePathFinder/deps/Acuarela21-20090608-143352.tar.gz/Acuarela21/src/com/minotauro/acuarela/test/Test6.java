/*
 * Created on Aug 14, 2004
 */
package com.minotauro.acuarela.test;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JToolBar;

import com.minotauro.acuarela.base.ACanvas;
import com.minotauro.acuarela.base.ACanvasFactory;
import com.minotauro.acuarela.base.ACtrlPoint;
import com.minotauro.acuarela.beans.ASwingPanel;
import com.minotauro.acuarela.controllers.ASwingContainer;
import com.minotauro.acuarela.render.ASwingContainerRenderer;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class Test6 extends JFrame {
  private ASwingPanel swingPanel;

  /**
   *
   */
  public Test6() {
    initGUI();

    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(640, 480);
    setVisible(true);
  }

  /**
   *
   */
  private void initGUI() {
    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(initToolBar(), BorderLayout.NORTH);
    getContentPane().add(initAcuarela(), BorderLayout.CENTER);
  }

  /**
   *
   *
   * @return
   */
  private JToolBar initToolBar() {
    JToolBar ret = new JToolBar();
    ret.setFloatable(false);

    JButton btnZoomIn = new JButton("+");
    btnZoomIn.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        double zoom = swingPanel.getZoom();

        double delta;

        if (zoom >= 1) {
          delta = 1;
        } else if (zoom >= 0.25) {
          delta = 0.25;
        } else {
          delta = 0.10;
        }

        if (zoom + delta <= 4) {
          swingPanel.setZoom(zoom + delta);
        }
      }
    });
    ret.add(btnZoomIn);

    JButton btnZoomOut = new JButton("-");
    btnZoomOut.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        double zoom = swingPanel.getZoom();

        double delta;

        if (zoom > 1) {
          delta = 1;
        } else if (zoom > 0.25) {
          delta = 0.25;
        } else {
          delta = 0.10;
        }

        if (zoom - delta >= 0.01) {
          swingPanel.setZoom(zoom - delta);
        }
      }
    });
    ret.add(btnZoomOut);

    return ret;
  }

  /**
   *
   *
   * @return
   */
  private JScrollPane initAcuarela() {
    ACanvas canvas = new ACanvas(new ACanvasFactory());
    //    canvas.setW(5000);
    //    canvas.setH(5000);
    canvas.setMinX(0);
    canvas.setMinY(0);
    canvas.setMaxX(5000);
    canvas.setMaxY(5000);

    swingPanel = new ASwingPanel(canvas);
    swingPanel.addPanelMouseInteractor(new MoveInteractor());
    swingPanel.addPanelMouseInteractor(new SelectionInteractor());

    //		for (int i = 0; i < canvas.getW() / 110; i++)
    //		{
    //			for (int j = 0; j < canvas.getH() / 110; j++)
    //			{
    ACtrlPoint ctrlBeg = new ACtrlPoint(10, 10);
    ACtrlPoint ctrlEnd = new ACtrlPoint(310, 310);
    ASwingContainer rectangle = new ASwingContainer(ctrlBeg, ctrlEnd);
    JPanel jPanel = initPanel();
    jPanel.setDoubleBuffered(false);
    rectangle.setContainer(jPanel);
    rectangle.setName("foo");
    rectangle.addRenderer(new ASwingContainerRenderer());
    rectangle.setVisible(true);
    canvas.addController(rectangle);
    //			}
    //		}

    return new JScrollPane(swingPanel);
  }

  /**
   * @return
   */
  private JPanel initPanel() {
    JPanel ret = new JPanel();
    //		ret.setBackground(Color.WHITE);
    ret.setDoubleBuffered(false);

    ret.setLayout(new GridBagLayout());

    GridBagConstraints gbc = new GridBagConstraints();

    JLabel lblHola = new JLabel("Hola");
    lblHola.setOpaque(true);
    lblHola.setBackground(Color.RED);
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 1;
    gbc.gridheight = 1;
    gbc.weightx = 0;
    gbc.weighty = 0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.CENTER;
    gbc.insets = new Insets(0, 0, 0, 0);
    ret.add(lblHola, gbc);

    JLabel lblMundo = new JLabel("Mundo");
    lblMundo.setOpaque(true);
    lblMundo.setBackground(Color.BLUE);
    gbc.gridx = 1;
    gbc.gridy = 0;
    gbc.gridwidth = 1;
    gbc.gridheight = 1;
    gbc.weightx = 0;
    gbc.weighty = 0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.EAST;
    gbc.insets = new Insets(0, 0, 0, 0);
    ret.add(lblMundo, gbc);

    JButton btnEstoEsUnBoton = new JButton("Esto Es Un Boton");
    btnEstoEsUnBoton.setBackground(Color.YELLOW);
    gbc.gridx = 0;
    gbc.gridy = 1;
    gbc.gridwidth = 2;
    gbc.gridheight = 1;
    gbc.weightx = 1;
    gbc.weighty = 0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.CENTER;
    gbc.insets = new Insets(0, 0, 0, 0);
    ret.add(btnEstoEsUnBoton, gbc);

    JTextField txtEjemplo = new JTextField("Hola Mundo");
    gbc.gridx = 2;
    gbc.gridy = 0;
    gbc.gridwidth = 1;
    gbc.gridheight = 3;
    gbc.weightx = 0;
    gbc.weighty = 1;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.CENTER;
    gbc.insets = new Insets(15, 15, 15, 15);
    ret.add(txtEjemplo, gbc);

    JPanel pnl1 = new JPanel(new FlowLayout());
    pnl1.setDoubleBuffered(false);

    JCheckBox chkEjemplo = new JCheckBox("Un Check Box");
    chkEjemplo.setOpaque(true);
    chkEjemplo.setBackground(Color.GREEN);
    //		gbc.gridx = 0;
    //		gbc.gridy = 2;
    //		gbc.gridwidth = 1;
    //		gbc.gridheight = 1;
    //		gbc.weightx = 1;
    //		gbc.weighty = 0;
    //		gbc.fill = GridBagConstraints.NONE;
    //		gbc.anchor = GridBagConstraints.CENTER;
    //		gbc.insets = new Insets(0, 0, 0, 0);
    //		ret.add(chkEjemplo, gbc);
    pnl1.add(chkEjemplo);

    JComboBox cboCombo = new JComboBox(new Object[]{"Uno", "Dos", "Tres", "etc..."});
    gbc.gridx = 1;
    gbc.gridy = 2;
    gbc.gridwidth = 1;
    gbc.gridheight = 1;
    gbc.weightx = 0;
    gbc.weighty = 0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.NORTH;
    gbc.insets = new Insets(0, 0, 0, 0);
    ret.add(cboCombo, gbc);
    pnl1.add(cboCombo);

    gbc.gridx = 1;
    gbc.gridy = 2;
    gbc.gridwidth = 1;
    gbc.gridheight = 1;
    gbc.weightx = 0;
    gbc.weighty = 0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.NORTH;
    gbc.insets = new Insets(0, 0, 0, 0);
    ret.add(pnl1, gbc);

    //		ret.add(cboCombo);

    return ret;
  }

  /**
   *
   *
   * @param args
   */
  public static void main(String[] args) {
    new Test6();
  }
}