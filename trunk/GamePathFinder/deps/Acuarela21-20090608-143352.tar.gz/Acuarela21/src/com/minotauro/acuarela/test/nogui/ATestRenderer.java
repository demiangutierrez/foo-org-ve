/*
 * Created on May 31, 2007
 */
package com.minotauro.acuarela.test.nogui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;

import com.minotauro.acuarela.base.AController;
import com.minotauro.acuarela.base.ARenderer;
import com.minotauro.acuarela.util.ARect;

/**
 * @author DMI: Demian Gutierrez
 */
public class ATestRenderer extends ARenderer {

  private Color color;

  public ATestRenderer(Color color) {
    this.color = color;
  }

  public void paint(Graphics2D g2d, AController object) {
    ARect rct = object.getBounds();

    g2d.setColor(color);
    g2d.setStroke(new BasicStroke(1));
    g2d.drawOval((int) rct.getX(), (int) rct.getY(), rct.getW(), rct.getH());
  }
}