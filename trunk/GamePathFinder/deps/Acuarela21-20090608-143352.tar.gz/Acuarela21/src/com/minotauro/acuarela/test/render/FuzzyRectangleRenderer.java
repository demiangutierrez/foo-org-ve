/*
 * Created on Dec 31, 2004
 */
package com.minotauro.acuarela.test.render;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;


import com.minotauro.acuarela.base.AController;
import com.minotauro.acuarela.base.ARenderer;
import com.minotauro.acuarela.test.controllers.FuzzyRectangleController;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class FuzzyRectangleRenderer extends ARenderer
{
	/**
	 *
	 */
	public FuzzyRectangleRenderer()
	{
		// Empty
	}

	/**
	 *
	 */
	public void paint(Graphics2D g2d, AController controller)
	{
		FuzzyRectangleController fuzzyRectangleController = (FuzzyRectangleController) controller;

		if (fuzzyRectangleController.isResizing())
		{
			g2d.setColor(Color.GRAY);
			g2d.setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1, new float[]{10, 5}, 1));
			g2d.draw(fuzzyRectangleController.getBounds());
		}
		else
		{
			g2d.setColor(Color.GREEN);
			g2d.fill(fuzzyRectangleController.getBounds());

			g2d.setColor(Color.BLACK);
			g2d.setStroke(new BasicStroke(1));
			g2d.draw(fuzzyRectangleController.getBounds());
		}
	}
}