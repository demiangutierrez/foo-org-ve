/*
 * Created on Aug 28, 2004
 */
package com.minotauro.acuarela.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class ATracer
{
	private static boolean trace = false;

	private static Map timeMap = new HashMap();

	private static Properties classFilterProperties;

	/**
	 *
	 */
	static
	{
		init();
	}

	/**
	 *
	 */
	private ATracer()
	{
		// Empty
	}

	private static void init()
	{
		// Properties def = new Properties();

		try
		{
			// No defaults (if empty, then trace all)
			// def.load(ATracer.class.getResourceAsStream("ATracer.properties"));

			classFilterProperties = new Properties();

			InputStream is = ClassLoader.getSystemResourceAsStream("ATracer.properties");

			if (is != null)
			{
				classFilterProperties.load(is);
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 *
	 *
	 * @param s
	 */
	public static void trace(String s)
	{
		if (!classFilterProperties.getProperty("trace", "false").equals("true"))
		{
			return;
		}

		//		if (!trace)
		//		{
		//			return;
		//		}

		Throwable throwable = new Throwable();
		StackTraceElement[] stackTraceElements = throwable.getStackTrace();

		String trace = stackTraceElements[1].getClassName();

		// RULES:
		//
		// 1.- If empty, then trace all.
		// 2.- If null, then trace it.
		// 3.- If found and true, then trace it
		// 4.- If found and false, then don't trace it.

		// 1.-
		//		if (!classFilterProperties.isEmpty())
		//		{
		//			System.err.println(1);
		//			return;
		//		}

		// 2.-, 3.-, 4.-
		if (classFilterProperties.getProperty(trace, "true").equals("false"))
		{
			//			System.err.println(2 + ";" + 3 + ";" + 4);
			return;
		}

		trace = trace.substring(trace.lastIndexOf('.') + 1);
		trace = "(" + trace + "::" + stackTraceElements[1].getMethodName() + ")";

		if (s != null)
		{
			trace = trace + " " + s;
		}

		System.err.println(trace);
	}

	/**
	 *
	 *
	 * @param s
	 */
	public static void time(String s)
	{
		if (!trace)
		{
			return;
		}

		Throwable throwable = new Throwable();
		StackTraceElement[] stackTraceElements = throwable.getStackTrace();

		String trace = stackTraceElements[1].getClassName();
		trace = trace.substring(trace.lastIndexOf('.') + 1);

		Long tb = (Long) timeMap.remove(trace + ":" + s);

		if (tb == null)
		{
			timeMap.put(trace + ":" + s, new Long(System.currentTimeMillis()));

			trace = "(" + trace + "::" + stackTraceElements[1].getMethodName() + ") BEG";
		}
		else
		{
			long te = System.currentTimeMillis();

			float dt = (te - tb.longValue()) / 1000f;

			trace = "(" + trace + "::" + stackTraceElements[1].getMethodName() + ")(" + dt + " sec)";
			trace = trace + " " + s;
		}

		System.err.println(trace);
	}
}