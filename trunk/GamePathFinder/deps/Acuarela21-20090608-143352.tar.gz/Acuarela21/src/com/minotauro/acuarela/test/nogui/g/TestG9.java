/**
 * @author DMI: Demian Gutierrez
 */
package com.minotauro.acuarela.test.nogui.g;

import com.minotauro.acuarela.test.nogui.BaseSimpleTest;

/*
 * Created on Aug 25, 2007
 */
public class TestG9 extends BaseSimpleTest {

  // Canvas W < paint W (cH > pH) (y + 5)
  public void test() throws Exception {
    pX = 5;
    pY = 5;
    cW = 600;
    cH = 600;
    despX = cW / 2;
    despY = cH / 2;
    pW = 295;
    pH = 295;
    zoom = 0.5;

    tpX1 = 100; // View/Red
    tpY1 = 100; // View/Red

    execute();
    assertTrue(compare());
  }
}
