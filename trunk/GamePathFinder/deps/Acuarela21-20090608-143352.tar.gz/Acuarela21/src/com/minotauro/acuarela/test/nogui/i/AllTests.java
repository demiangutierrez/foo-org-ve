package com.minotauro.acuarela.test.nogui.i;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.apache.commons.lang.ClassUtils;

public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite(ClassUtils.getPackageName(AllTests.class));

    //$JUnit-BEGIN$
    suite.addTestSuite(TestI0.class);
    suite.addTestSuite(TestI1.class);
    suite.addTestSuite(TestI2.class);
    suite.addTestSuite(TestI3.class);
    suite.addTestSuite(TestI4.class);
    suite.addTestSuite(TestI5.class);
    suite.addTestSuite(TestI6.class);
    suite.addTestSuite(TestI7.class);
    suite.addTestSuite(TestI8.class);
    suite.addTestSuite(TestI9.class);
    //$JUnit-END$

    return suite;
  }
}
