/*
 * Created on Dec 30, 2004
 */
package com.minotauro.acuarela.test;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.minotauro.acuarela.base.ACanvas;
import com.minotauro.acuarela.base.ACanvasFactory;
import com.minotauro.acuarela.base.ACtrlPoint;
import com.minotauro.acuarela.beans.ASwingPanel;
import com.minotauro.acuarela.controllers.ASwingContainer;
import com.minotauro.acuarela.render.ASwingContainerRenderer;

/**
 * @author DMI: Demian Gutierrez
 */
public class TestSwingContainer extends TestFrame {
  /**
   *
   */
  public TestSwingContainer() {
    // Empty
  }

  /**
   *
   */
  protected ASwingPanel initSwingPanel() {
    ACanvas canvas = new ACanvas(new ACanvasFactory());
    //    canvas.setW(5000);
    //    canvas.setH(5000);

    ASwingPanel ret = new ASwingPanel(canvas);
    ret.addPanelMouseInteractor(new MoveInteractor());
    ret.addPanelMouseInteractor(new SelectionInteractor());

    ACtrlPoint ctrlBeg = new ACtrlPoint(10, 10);
    ACtrlPoint ctrlEnd = new ACtrlPoint(310, 310);
    ASwingContainer aSwingContainer = new ASwingContainer(ctrlBeg, ctrlEnd);

    JPanel jPanel = initPanel();
    jPanel.setDoubleBuffered(false);

    aSwingContainer.setContainer(jPanel);
    aSwingContainer.setName("aSwingContainer");
    aSwingContainer.addRenderer(new ASwingContainerRenderer());
    aSwingContainer.setVisible(true);

    canvas.addController(aSwingContainer);

    return ret;
  }

  /**
   *
   *
   * @return
   */
  private JPanel initPanel() {
    // XXX: All containers must have double buffered set to false
    JPanel ret = new JPanel(new GridBagLayout());
    ret.setDoubleBuffered(false);

    GridBagConstraints gbc = new GridBagConstraints();

    JLabel lblHola = new JLabel("Hola");
    lblHola.setOpaque(true);
    lblHola.setBackground(Color.RED);
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 1;
    gbc.gridheight = 1;
    gbc.weightx = 0;
    gbc.weighty = 0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.CENTER;
    gbc.insets = new Insets(0, 0, 0, 0);
    ret.add(lblHola, gbc);

    JLabel lblMundo = new JLabel("Mundo");
    lblMundo.setOpaque(true);
    lblMundo.setBackground(Color.BLUE);
    gbc.gridx = 1;
    gbc.gridy = 0;
    gbc.gridwidth = 1;
    gbc.gridheight = 1;
    gbc.weightx = 0;
    gbc.weighty = 0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.EAST;
    gbc.insets = new Insets(0, 0, 0, 0);
    ret.add(lblMundo, gbc);

    JButton btnEstoEsUnBoton = new JButton("Esto Es Un Boton");
    btnEstoEsUnBoton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
      }
    });

    btnEstoEsUnBoton.setBackground(Color.YELLOW);
    gbc.gridx = 0;
    gbc.gridy = 1;
    gbc.gridwidth = 2;
    gbc.gridheight = 1;
    gbc.weightx = 1;
    gbc.weighty = 0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.CENTER;
    gbc.insets = new Insets(0, 0, 0, 0);
    ret.add(btnEstoEsUnBoton, gbc);

    JTextField txtEjemplo = new JTextField("Hola Mundo");
    gbc.gridx = 2;
    gbc.gridy = 0;
    gbc.gridwidth = 1;
    gbc.gridheight = 3;
    gbc.weightx = 0;
    gbc.weighty = 1;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.CENTER;
    gbc.insets = new Insets(15, 15, 15, 15);
    ret.add(txtEjemplo, gbc);

    JPanel pnlSouth = new JPanel(new FlowLayout());
    pnlSouth.setDoubleBuffered(false);
    gbc.gridx = 1;
    gbc.gridy = 2;
    gbc.gridwidth = 1;
    gbc.gridheight = 1;
    gbc.weightx = 0;
    gbc.weighty = 0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.NORTH;
    gbc.insets = new Insets(0, 0, 0, 0);
    ret.add(pnlSouth, gbc);

    JCheckBox chkEjemplo = new JCheckBox("Un Check Box");
    chkEjemplo.setOpaque(true);
    chkEjemplo.setBackground(Color.GREEN);
    pnlSouth.add(chkEjemplo);

    JComboBox cboCombo = new JComboBox(new Object[]{"Uno", "Dos", "Tres", "etc..."});
    pnlSouth.add(cboCombo);

    return ret;
  }

  /**
   *
   *
   * @param args
   */
  public static void main(String[] args) {
    new TestSwingContainer();
  }
}