/**
 * @author DMI: Demian Gutierrez
 */
package com.minotauro.acuarela.test.nogui.e;

import com.minotauro.acuarela.test.nogui.BaseSimpleTest;

/*
 * Created on Aug 25, 2007
 */
public class TestE4 extends BaseSimpleTest {

  // W/H Test
  // Canvas W < to paint W (cH > pH)
  public void test() throws Exception {
    cW = 600;
    cH = 600;
    despX = cW / 2;
    despY = cH / 2;
    pW = 800;
    pH = 590;
    execute();
    assertTrue(compare());
  }
}
