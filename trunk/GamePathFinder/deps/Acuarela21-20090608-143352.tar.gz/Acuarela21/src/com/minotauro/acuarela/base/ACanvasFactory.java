/*
 * Created on Jul 18, 2004
 */
package com.minotauro.acuarela.base;

import java.awt.image.BufferedImage;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class ACanvasFactory
{
	private BufferedImage sharedBufferedImage;

	/**
	 * 
	 */
	public ACanvasFactory()
	{
		// Empty
	}

	/**
	 *
	 *
	 * @param w
	 * @param h
	 *
	 * @return
	 */
	public BufferedImage createBufferedImage(int w, int h)
	{
		return new BufferedImage(w, h, BufferedImage.TYPE_3BYTE_BGR);
	}

	/**
	 *
	 *
	 * @param w
	 * @param h
	 *
	 * @return
	 */
	public BufferedImage getBufferedImage(int w, int h)
	{
		if (sharedBufferedImage == null || w > sharedBufferedImage.getWidth() || h > sharedBufferedImage.getHeight())
		{
			sharedBufferedImage = createBufferedImage(w, h);
		}

		return sharedBufferedImage;
	}
}