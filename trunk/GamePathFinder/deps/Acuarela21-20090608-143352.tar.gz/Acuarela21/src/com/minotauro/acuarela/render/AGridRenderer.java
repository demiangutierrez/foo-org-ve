/*
 * Created on Dec 19, 2004
 */
package com.minotauro.acuarela.render;

import java.awt.Color;
import java.awt.Graphics2D;

import com.minotauro.acuarela.base.ACanvas;
import com.minotauro.acuarela.event.APaintAdapter;
import com.minotauro.acuarela.event.APaintEvent;
import com.minotauro.acuarela.util.ARect;

/**
 * @author Demian Gutierrez
 */
public class AGridRenderer extends APaintAdapter {

  public AGridRenderer() {
    // Empty
  }

  @Override
  public void prePaint(APaintEvent evt) {
    ACanvas canvas = (ACanvas) evt.getSource();

    Graphics2D g2d = evt.getGraphics2D();
    ARect viewRect = evt.getViewRect();

    int gridWDiff = viewRect.x % canvas.getGridW();
    int gridHDiff = viewRect.y % canvas.getGridH();

    for (int x = viewRect.x + gridWDiff; x < viewRect.getW(); x += canvas.getGridW()) {
      for (int y = viewRect.y + gridHDiff; y < viewRect.getH(); y += canvas.getGridH()) {
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.drawLine(x - 1, y, x + 1, y);
        g2d.drawLine(x, y - 1, x, y + 1);
      }
    }
  }
}