/**
 * @author DMI: Demian Gutierrez
 */
package com.minotauro.acuarela.test.nogui.a;

import com.minotauro.acuarela.test.nogui.BaseSimpleTest;

/*
 * Created on Aug 25, 2007
 */
public class TestA9 extends BaseSimpleTest {

  // W/H Test
  // Canvas W/H > to paint W/H (x/y + 10)
  public void test() throws Exception {
    pX = 10;
    pY = 10;
    cW = 600;
    cH = 600;
    pW = 590;
    pH = 590;
    execute();
    assertTrue(compare());
  }
}
