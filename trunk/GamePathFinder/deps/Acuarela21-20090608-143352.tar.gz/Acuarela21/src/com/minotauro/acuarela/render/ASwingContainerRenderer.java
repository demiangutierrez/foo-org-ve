/*
 * Created on Dec 25, 2004
 */
package com.minotauro.acuarela.render;

import java.awt.Container;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.AffineTransform;


import com.minotauro.acuarela.base.AController;
import com.minotauro.acuarela.base.ARenderer;
import com.minotauro.acuarela.controllers.ASwingContainer;
import com.minotauro.acuarela.util.AContainerPainter;
import com.minotauro.acuarela.util.ARect;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class ASwingContainerRenderer extends ARenderer
{
	/**
	 *
	 */
	public ASwingContainerRenderer()
	{
		// Empty
	}

	/**
	 *
	 */
	public void paint(Graphics2D g2d, AController controller)
	{
		ASwingContainer aSwingContainer = (ASwingContainer) controller;
		Container container = aSwingContainer.getContainer();

		ARect r = controller.getBounds();

		AffineTransform prevTransform = g2d.getTransform();

		AffineTransform currTransform = g2d.getTransform();
		currTransform.translate(r.x, r.y);
		g2d.setTransform(currTransform);

		Shape prevClip = g2d.getClip();

		g2d.clipRect(0, 0, r.getW(), r.getH());

		AContainerPainter aContainerPainter = new AContainerPainter();

		if (!aSwingContainer.isValid())
		{
			aContainerPainter.doLayout(container);
			aSwingContainer.setValid(true);
		}

		aContainerPainter.paintContainer(g2d, container);

		g2d.setClip(prevClip);

		g2d.setTransform(prevTransform);
	}
}