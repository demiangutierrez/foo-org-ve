/*
 * Created on Jun 6, 2004
 */
package com.minotauro.acuarela.event;

import java.util.EventListener;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface ARepaintListener extends EventListener
{
	/**
	 *
	 *
	 * @param evt
	 */
	public void repaintRequest(ARepaintEvent evt);
}
