/*
 * Created on Sep 26, 2003
 */
package com.minotauro.acuarela.base;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.util.Iterator;

import com.minotauro.acuarela.event.AControllerMouseEvent;
import com.minotauro.acuarela.event.AControllerMouseListener;
import com.minotauro.acuarela.event.AMotionEvent;
import com.minotauro.acuarela.event.AMotionException;
import com.minotauro.acuarela.event.AMotionListener;
import com.minotauro.acuarela.event.ARepaintEvent;
import com.minotauro.acuarela.event.ARepaintListener;
import com.minotauro.acuarela.util.ARect;

/**
 * @author DMI: Demian Gutierrez
 */
public interface AController {

  // --------------------------------------------------------------------------------
  // AMotionListener methods
  // --------------------------------------------------------------------------------

  /**
   * @param listener
   */
  public void addMotionListener(AMotionListener listener);

  /**
   * @param listener
   */
  public void delMotionListener(AMotionListener listener);

  /**
   * @return
   */
  public AMotionListener[] getMotionListeners();

  /**
   * @param evt
   *
   * @throws AMotionException
   */
  public void fireMotionEvent(AMotionEvent evt) throws AMotionException;

  // --------------------------------------------------------------------------------
  // ARepaintListener methods
  // --------------------------------------------------------------------------------

  /**
   * @param listener
   */
  public void addRepaintListener(ARepaintListener listener);

  /**
   * @param listener
   */
  public void delRepaintListener(ARepaintListener listener);

  /**
   * @return
   */
  public ARepaintListener[] getRepaintListeners();

  /**
   * @param evt
   */
  public void fireRepaintEvent(ARepaintEvent evt);

  // --------------------------------------------------------------------------------
  // MotionEventDisable methods
  // --------------------------------------------------------------------------------

  /**
   * @param motionEventDisable
   */
  public void setCompleteMotionEventDisable(boolean motionEventDisable);

  /**
   * @param motionEventDisable
   */
  public void setControllerMotionEventDisable(boolean motionEventDisable);

  /**
   * @param motionEventDisable
   */
  public void setCtrlPointMotionEventDisable(boolean motionEventDisable);

  // --------------------------------------------------------------------------------
  // AControllerMouseListener methods
  // --------------------------------------------------------------------------------

  /**
   * @param listener
   */
  public void addControllerMouseListener(AControllerMouseListener listener);

  /**
   * @param listener
   */
  public void delControllerMouseListener(AControllerMouseListener listener);

  /**
   * @return
   */
  public AControllerMouseListener[] getControllerMouseListeners();

  /**
   * @param method
   * @param mouseEvent
   */
  public void fireControllerMouseEvent(int method, AControllerMouseEvent evt);

  // --------------------------------------------------------------------------------
  // Controller methods
  // --------------------------------------------------------------------------------

  /**
   * @param controller
   */
  public void addController(AController controller);

  /**
   * @param name
   *
   * @return
   */
  public AController getController(String name);

  /**
   * @param x
   * @param y
   *
   * @return
   */
  public AController getController(int x, int y);

  /**
   * @param controller
   */
  public void delController(AController controller);

  /**
   * @return
   */
  public Iterator controllerIterator();

  /**
   * @return
   */
  public AController[] toControllerArray();

  // --------------------------------------------------------------------------------
  // CtrlPoint methods
  // --------------------------------------------------------------------------------

  /**
   * @param ctrlPoint
   */
  public void addCtrlPoint(ACtrlPoint ctrlPoint);

  /**
   * @param name
   *
   * @return
   */
  public ACtrlPoint getCtrlPoint(String name);

  /**
   * @param x
   * @param y
   *
   * @return
   */
  public ACtrlPoint getCtrlPoint(int x, int y);

  /**
   * @param ctrlPoint
   */
  public void delCtrlPoint(ACtrlPoint ctrlPoint);

  /**
   * @return
   */
  public Iterator ctrlPointIterator();

  /**
   * @return
   */
  public ACtrlPoint[] toCtrlPointArray();

  // --------------------------------------------------------------------------------
  // Dependent methods
  // --------------------------------------------------------------------------------

  /**
   * @param object
   */
  public void addDependent(AController object);

  /**
   * @param name
   *
   * @return
   */
  public AController getDependent(String name);

  /**
   * @param x
   * @param y
   *
   * @return
   */
  public AController getDependent(int x, int y);

  /**
   * @param object
   */
  public void delDependent(AController object);

  /**
   * @return
   */
  public Iterator dependentIterator();

  /**
   * @return
   */
  public AController[] toDependentArray();

  // --------------------------------------------------------------------------------
  // Life cycle methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public void initController();

  /**
   *
   */
  public void attachController();

  /**
   *
   */
  public void detachController();

  // --------------------------------------------------------------------------------
  // Move methods
  // --------------------------------------------------------------------------------

  /**
   * @param dx
   * @param dy
   */
  public void move(int dx, int dy);

  /**
   * @param dx
   * @param dy
   * @param evt
   *
   * @throws AMotionException
   */
  public void move(int dx, int dy, AMotionEvent evt) throws AMotionException;

  // --------------------------------------------------------------------------------
  // Paint methods
  // --------------------------------------------------------------------------------

  /**
   * @param g2d
   */
  public void paint(Graphics2D g2d);

  // --------------------------------------------------------------------------------
  // Renderer methods
  // --------------------------------------------------------------------------------

  /**
   * @param renderer
   */
  public void addRenderer(ARenderer renderer);

  /**
   * @param name
   *
   * @return
   */
  public ARenderer getRenderer(String name);

  /**
   * @param renderer
   */
  public void delRenderer(ARenderer renderer);

  /**
   * @return
   */
  public Iterator rendererIterator();

  /**
   * @return
   */
  public ARenderer[] toRendererArray();

  // --------------------------------------------------------------------------------
  // Bounds methods
  // --------------------------------------------------------------------------------

  /**
   * @return
   */
  public ARect getBounds();

  /**
   * @return
   */
  public ARect getFullBounds();

  // --------------------------------------------------------------------------------
  // Geometry methods
  // --------------------------------------------------------------------------------

  /**
   * @return
   */
  public Shape getShape();

  // --------------------------------------------------------------------------------
  // Name methods
  // --------------------------------------------------------------------------------

  /**
   * @return
   */
  public String getFullName();

  // --------------------------------------------------------------------------------
  // Properties methods
  // --------------------------------------------------------------------------------

  /**
   * @return
   */
  public String getName();

  /**
   * @param name
   */
  public void setName(String name);

  // --------------------------------------------------------------------------------

  /**
   * @return
   */
  public ACanvas getCanvas();

  /**
   * @param canvas
   */
  public void setCanvas(ACanvas canvas);

  // --------------------------------------------------------------------------------

  /**
   * @return
   */
  public AController getParent();

  /**
   * @param parent
   */
  public void setParent(AController parent);

  /**
   * @return
   */
  public AController getTopParent();

  // --------------------------------------------------------------------------------
  // Flags methods
  //
  // Flags are:
  //
  // initialized
  // visible
  // disable
  // selected
  // dragging
  // movable
  // client
  // --------------------------------------------------------------------------------

  /**
   * @return
   */
  public boolean getInitialized();

  /**
   * @param initialized
   */
  public void setInitialized(boolean initialized);

  // --------------------------------------------------------------------------------

  /**
   * @return
   */
  public boolean getVisible();

  /**
   * @param visible
   */
  public void setVisible(boolean visible);

  // --------------------------------------------------------------------------------

  /**
   * @return
   */
  public boolean getDisable();

  /**
   * @param disable
   */
  public void setDisable(boolean disable);

  // --------------------------------------------------------------------------------

  /**
   * @return
   */
  public boolean getSelected();

  /**
   * @param selected
   */
  public void setSelected(boolean selected);

  // --------------------------------------------------------------------------------

  /**
   * @return
   */
  public boolean getDragging();

  /**
   * @param dragging
   */
  public void setDragging(boolean dragging);

  // --------------------------------------------------------------------------------

  /**
   * @return
   */
  public boolean getMovable();

  /**
   * @param movable
   */
  public void setMovable(boolean movable);

  // --------------------------------------------------------------------------------

  /**
   * @return
   */
  public boolean getClient();

  /**
   * @param client
   */
  public void setClient(boolean client);
}