/*
 * Created on Jul 18, 2004
 */
package com.minotauro.acuarela.base;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.Vector;

import javax.swing.event.EventListenerList;

import org.cyrano.graph.label.LabelGraph;

import com.minotauro.acuarela.event.ACanvasEvent;
import com.minotauro.acuarela.event.ACanvasListener;
import com.minotauro.acuarela.event.AControllerMouseEvent;
import com.minotauro.acuarela.event.AControllerMouseListener;
import com.minotauro.acuarela.event.AMotionListener;
import com.minotauro.acuarela.event.APaintEvent;
import com.minotauro.acuarela.event.APaintListener;
import com.minotauro.acuarela.event.ARepaintEvent;
import com.minotauro.acuarela.event.ARepaintListener;
import com.minotauro.acuarela.event.ASelectionEvent;
import com.minotauro.acuarela.event.ASelectionListener;
import com.minotauro.acuarela.event.ASizeEvent;
import com.minotauro.acuarela.event.ASizeListener;
import com.minotauro.acuarela.util.ADist;
import com.minotauro.acuarela.util.ARect;

/**
 * @author DMI: Demian Gutierrez
 */
public class ACanvas implements ARepaintListener {

  protected static final int OBJ_ADD = 0;

  protected static final int OBJ_REM = 1;

  // --------------------------------------------------------------------------------

  protected static final int SEL_GAI = 0;

  protected static final int SEL_LOS = 1;

  // --------------------------------------------------------------------------------

  protected static final int PNT_PRE = 0;

  protected static final int PNT_POS = 1;

  // --------------------------------------------------------------------------------

  protected EventListenerList eventListenerList = new EventListenerList();

  protected LabelGraph labelGraph = new LabelGraph();

  protected LinkedList cntList = new LinkedList();
  protected LinkedList selList = new LinkedList();

  protected AMotionListener motionListener;

  protected Map minXValueObjectBeanByController = new HashMap();
  protected Map maxXValueObjectBeanByController = new HashMap();
  protected Map minYValueObjectBeanByController = new HashMap();
  protected Map maxYValueObjectBeanByController = new HashMap();

  protected SortedSet xSortedSet;
  protected SortedSet ySortedSet;

  protected Color background = Color.WHITE;

  protected ACanvasFactory canvasFactory;

  protected int gridW = 1;
  protected int gridH = 1;

  protected int minX;
  protected int minY;

  protected int maxX;
  protected int maxY;

  protected double zoom = 1;

  private class ValueObjectBean {

    public Object obj;
    public int val;

    public ValueObjectBean() {
      // Empty
    }
  }

  // --------------------------------------------------------------------------------

  public ACanvas(ACanvasFactory canvasFactory) {
    this.canvasFactory = canvasFactory;

    Comparator comparator = new Comparator() {
      public int compare(Object obj1, Object obj2) {
        int val1 = ((ValueObjectBean) obj1).val;
        int val2 = ((ValueObjectBean) obj2).val;

        if (obj1.equals(obj2)) {
          return 0;
        }

        return val1 < val2 ? -1 : 1;
      }
    };

    xSortedSet = new TreeSet(comparator);
    ySortedSet = new TreeSet(comparator);
  }

  // --------------------------------------------------------------------------------
  // Updates X and Y SortedSets. Call it after an objects is moved
  // --------------------------------------------------------------------------------

  public void updateXYSortedSet(AController controller) {
    controller = controller.getTopParent();

    // ----------------------------------------
    // X
    // ----------------------------------------

    ValueObjectBean minXValueObjectBean = (ValueObjectBean) minXValueObjectBeanByController.get(controller);

    if (minXValueObjectBean == null) {
      minXValueObjectBean = new ValueObjectBean();
      minXValueObjectBean.obj = controller;
      minXValueObjectBeanByController.put(controller, minXValueObjectBean);
    }

    xSortedSet.remove(minXValueObjectBean);
    minXValueObjectBean.val = controller.getBounds().x;
    xSortedSet.add(minXValueObjectBean);

    ValueObjectBean maxXValueObjectBean = (ValueObjectBean) maxXValueObjectBeanByController.get(controller);

    if (maxXValueObjectBean == null) {
      maxXValueObjectBean = new ValueObjectBean();
      maxXValueObjectBean.obj = controller;
      maxXValueObjectBeanByController.put(controller, maxXValueObjectBean);
    }

    xSortedSet.remove(maxXValueObjectBean);
    maxXValueObjectBean.val = controller.getBounds().maxX();
    xSortedSet.add(maxXValueObjectBean);

    // ----------------------------------------
    // Y
    // ----------------------------------------

    ValueObjectBean minYValueObjectBean = (ValueObjectBean) minYValueObjectBeanByController.get(controller);

    if (minYValueObjectBean == null) {
      minYValueObjectBean = new ValueObjectBean();
      minYValueObjectBean.obj = controller;
      minYValueObjectBeanByController.put(controller, minYValueObjectBean);
    }

    ySortedSet.remove(minYValueObjectBean);
    minYValueObjectBean.val = controller.getBounds().y;
    ySortedSet.add(minYValueObjectBean);

    ValueObjectBean maxYValueObjectBean = (ValueObjectBean) maxYValueObjectBeanByController.get(controller);

    if (maxYValueObjectBean == null) {
      maxYValueObjectBean = new ValueObjectBean();
      maxYValueObjectBean.obj = controller;
      maxYValueObjectBeanByController.put(controller, maxYValueObjectBean);
    }

    ySortedSet.remove(maxYValueObjectBean);
    maxYValueObjectBean.val = controller.getBounds().maxY();
    ySortedSet.add(maxYValueObjectBean);

  }

  // --------------------------------------------------------------------------------

  public AController getMinXController() {
    return (AController) ((ValueObjectBean) xSortedSet.first()).obj;
  }

  public AController getMaxXController() {
    return (AController) ((ValueObjectBean) xSortedSet.last()).obj;
  }

  public AController getMinYController() {
    return (AController) ((ValueObjectBean) ySortedSet.first()).obj;
  }

  public AController getMaxYController() {
    return (AController) ((ValueObjectBean) ySortedSet.last()).obj;
  }

  // --------------------------------------------------------------------------------
  // PropertyChangeListener methods
  // --------------------------------------------------------------------------------

  public void addPropertyChangeListener(PropertyChangeListener listener) {
    eventListenerList.add(PropertyChangeListener.class, listener);
  }

  public void delPropertyChangeListener(PropertyChangeListener listener) {
    eventListenerList.remove(PropertyChangeListener.class, listener);
  }

  public PropertyChangeListener[] getPropertyChangeListeners() {
    return (PropertyChangeListener[]) eventListenerList.getListeners(PropertyChangeListener.class);
  }

  protected void firePropertyChange(PropertyChangeEvent evt) {
    PropertyChangeListener[] listenerArray = getPropertyChangeListeners();

    for (int i = 0; i < listenerArray.length; i++) {
      listenerArray[i].propertyChange(evt);
    }
  }

  // --------------------------------------------------------------------------------
  // ACanvasListener methods
  // --------------------------------------------------------------------------------

  public void addCanvasListener(ACanvasListener listener) {
    eventListenerList.add(ACanvasListener.class, listener);
  }

  public void delCanvasListener(ACanvasListener listener) {
    eventListenerList.remove(ACanvasListener.class, listener);
  }

  public ACanvasListener[] getCanvasListeners() {
    return (ACanvasListener[]) eventListenerList.getListeners(ACanvasListener.class);
  }

  protected void fireCanvasEvent(int method, AController controller) {
    ACanvasEvent evt = new ACanvasEvent(this, controller);

    ACanvasListener[] listener = getCanvasListeners();

    for (int i = 0; i < listener.length; i++) {
      switch (method) {
        case OBJ_ADD :
          listener[i].objectAdded(evt);
          break;

        case OBJ_REM :
          listener[i].objectRemoved(evt);
          break;
      }
    }
  }

  // --------------------------------------------------------------------------------
  // ASelectionListener methods
  // --------------------------------------------------------------------------------

  public void addSelectionListener(ASelectionListener listener) {
    eventListenerList.add(ASelectionListener.class, listener);
  }

  public void delSelectionListener(ASelectionListener listener) {
    eventListenerList.remove(ASelectionListener.class, listener);
  }

  public ASelectionListener[] getSelectionListeners() {
    return (ASelectionListener[]) eventListenerList.getListeners(ASelectionListener.class);
  }

  protected void fireSelectionEvent(int method, AController controller, AController[] context) {
    ASelectionEvent evt = new ASelectionEvent(this, controller, context);

    ASelectionListener[] listener = getSelectionListeners();

    for (int i = 0; i < listener.length; i++) {
      switch (method) {
        case SEL_GAI :
          listener[i].selectionGained(evt);
          break;

        case SEL_LOS :
          listener[i].selectionLost(evt);
          break;
      }
    }
  }

  // --------------------------------------------------------------------------------
  // APaintListener methods
  // --------------------------------------------------------------------------------

  public void addPaintListener(APaintListener listener) {
    eventListenerList.add(APaintListener.class, listener);
  }

  public void delPaintListener(APaintListener listener) {
    eventListenerList.remove(APaintListener.class, listener);
  }

  public APaintListener[] getPaintListeners() {
    return (APaintListener[]) eventListenerList.getListeners(APaintListener.class);
  }

  public void firePaintEvent(int method, Graphics2D graphics2D, ARect viewRect) {
    APaintEvent evt = new APaintEvent(this, graphics2D, viewRect);

    APaintListener[] listener = getPaintListeners();

    for (int i = 0; i < listener.length; i++) {
      switch (method) {
        case PNT_PRE :
          listener[i].prePaint(evt);
          break;

        case PNT_POS :
          listener[i].posPaint(evt);
          break;
      }
    }
  }

  // --------------------------------------------------------------------------------
  // ASizeListener methods
  // --------------------------------------------------------------------------------

  public void addSizeListener(ASizeListener listener) {
    eventListenerList.add(ASizeListener.class, listener);
  }

  public void delSizeListener(ASizeListener listener) {
    eventListenerList.remove(ASizeListener.class, listener);
  }

  public ASizeListener[] getSizeListeners() {
    return (ASizeListener[]) eventListenerList.getListeners(ASizeListener.class);
  }

  public void fireSizeEvent(ADist size) {
    ASizeEvent evt = new ASizeEvent(this, size);

    ASizeListener[] listener = getSizeListeners();

    for (int i = 0; i < listener.length; i++) {
      listener[i].sizeChanged(evt);
    }
  }

  // --------------------------------------------------------------------------------
  // AControllerMouseListener methods
  // --------------------------------------------------------------------------------

  public void addControllerMouseListener(AControllerMouseListener listener) {
    eventListenerList.add(AControllerMouseListener.class, listener);
  }

  public void delControllerMouseListener(AControllerMouseListener listener) {
    eventListenerList.remove(AControllerMouseListener.class, listener);
  }

  public AControllerMouseListener[] getControllerMouseListeners() {
    return (AControllerMouseListener[]) eventListenerList.getListeners(AControllerMouseListener.class);
  }

  public void fireControllerMouseEvent(int method, AControllerMouseEvent evt) {
    AControllerMouseListener[] listener = getControllerMouseListeners();

    // Send the event to all registered listeners
    for (int i = 0; i < listener.length; i++) {
      switch (method) {
        case AControllerMouseListener.CONTROLLER_MOUSE_CLICKED :
          listener[i].controllerMouseClicked(evt);
          break;

        case AControllerMouseListener.CONTROLLER_MOUSE_ENTERED :
          listener[i].controllerMouseEntered(evt);
          break;

        case AControllerMouseListener.CONTROLLER_MOUSE_EXITED :
          listener[i].controllerMouseExited(evt);
          break;

        case AControllerMouseListener.CONTROLLER_MOUSE_PRESSED :
          listener[i].controllerMousePressed(evt);
          break;

        case AControllerMouseListener.CONTROLLER_MOUSE_RELEASED :
          listener[i].controllerMouseReleased(evt);
          break;

        case AControllerMouseListener.CONTROLLER_MOUSE_DRAGGED :
          listener[i].controllerMouseDragged(evt);
          break;

        case AControllerMouseListener.CONTROLLER_MOUSE_MOVED :
          listener[i].controllerMouseMoved(evt);
          break;
      }
    }

    // ----------------------------------------
    // Forward the event to all the controllers
    // ----------------------------------------

    AController[] aControllers = toControllerArray();

    for (int i = 0; i < aControllers.length; i++) {

      // ----------------------------------------
      // Set controller in the event
      // ----------------------------------------

      evt.setController(aControllers[i]);
      aControllers[i].fireControllerMouseEvent(method, evt);

      // ----------------------------------------
      // Break if the event was consumed
      // ----------------------------------------

      if (evt.isConsumed()) {
        break;
      }
    }
  }

  // --------------------------------------------------------------------------------
  // ARepaintListener methods
  // --------------------------------------------------------------------------------

  public void addRepaintListener(ARepaintListener listener) {
    eventListenerList.add(ARepaintListener.class, listener);
  }

  public void delRepaintListener(ARepaintListener listener) {
    eventListenerList.remove(ARepaintListener.class, listener);
  }

  public ARepaintListener[] getRepaintListeners() {
    return (ARepaintListener[]) eventListenerList.getListeners(ARepaintListener.class);
  }

  public void fireRepaintEvent(ARepaintEvent evt) {
    ARepaintListener[] listeners = getRepaintListeners();

    for (int i = 0; i < listeners.length; i++) {
      listeners[i].repaintRequest(evt);
    }
  }

  public void repaintRequest(ARepaintEvent evt) {
    fireRepaintEvent(evt);
  }

  // --------------------------------------------------------------------------------
  // Controller methods
  // --------------------------------------------------------------------------------

  public void addController(AController controller) {
    if (cntList.contains(controller)) {
      return;
    }

    cntList.addFirst(controller);

    if (controller instanceof AVertex) {
      labelGraph.addVertex((AVertex) controller);
    } else {
      labelGraph.addEdge((AEdge) controller);
    }

    controller.setCanvas(this);

    controller.addMotionListener(motionListener);

    if (!controller.getInitialized()) {
      controller.initController();
    }

    controller.attachController();

    if (controller.getClient()) {
      fireCanvasEvent(OBJ_ADD, controller);
    }

    controller.addRepaintListener(this);

    updateXYSortedSet(controller);
  }

  /**
   *
   *
   * @param name
   *
   * @return
   */
  public AController getController(String name) {
    Iterator itt = controllerIterator();

    while (itt.hasNext()) {
      AController controller = (AController) itt.next();

      if (name.equals(controller.getName())) {
        return controller;
      }
    }

    return null;
  }

  /**
   *
   *
   * @param x
   * @param y
   *
   * @return
   */
  public AController getController(int x, int y) {
    Iterator itt = controllerIterator();

    while (itt.hasNext()) {
      AController controller = (AController) itt.next();

      AController ret = controller.getController(x, y);

      if (ret != null) {
        return ret;
      }
    }

    return null;
  }

  /**
   *
   *
   * @param controller
   */
  public void delController(AController controller) {
    if (!cntList.remove(controller)) {
      return;
    }

    if (controller.getClient()) {
      fireCanvasEvent(OBJ_REM, controller);
    }

    controller.delMotionListener(motionListener);

    delSelectedController(controller);

    controller.setCanvas(null);

    AController[] controllerArray = controller.toDependentArray();

    for (int i = 0; i < controllerArray.length; i++) {
      delController(controllerArray[i]);

      controller.delDependent(controllerArray[i]);
    }

    controller.delRepaintListener(this);
  }

  /**
   *
   *
   * @return
   */
  public Iterator controllerIterator() {
    return cntList.iterator();
  }

  /**
   *
   *
   * @return
   */
  public AController[] toControllerArray() {
    return (AController[]) cntList.toArray(new AController[0]);
  }

  /**
   *
   *
   * @param rectangle
   * @param intersects
   *
   * @return
   */
  public AController[] toControllerArray(Rectangle rectangle, boolean intersects) {
    Vector ret = new Vector();

    Iterator itt = controllerIterator();

    while (itt.hasNext()) {
      AController controller = (AController) itt.next();

      Rectangle oR = controller.getBounds();

      if (intersects) {
        if (rectangle.intersects(oR)) {
          ret.add(controller);
        }
      } else {
        if (rectangle.contains(oR)) {
          ret.add(controller);
        }
      }
    }

    return (AController[]) ret.toArray(new AController[0]);
  }

  /**
   *
   *
   * @param controller
   */
  public void bringToFront(AController controller) {
    if (cntList.remove(controller)) {
      cntList.addFirst(controller);
    }
  }

  /**
   *
   *
   * @param controller
   */
  public void sendToBack(AController controller) {
    if (cntList.remove(controller)) {
      cntList.addLast(controller);
    }
  }

  // --------------------------------------------------------------------------------
  // Selected Controller methods
  // --------------------------------------------------------------------------------

  public void addSelectedController(AController controller) {
    controller = controller.getTopParent();

    if (!cntList.contains(controller) || selList.contains(controller)) {
      return;
    }

    selList.add(controller);

    controller.setSelected(true);

    if (controller.getClient()) {
      fireSelectionEvent(SEL_GAI, controller, new AController[]{controller});
    }
  }

  /**
   *
   *
   * @param rectangle
   * @param intersects
   */
  public void addSelectedRectangle(Rectangle rectangle, boolean intersects) {
    AController[] controllerArray = toControllerArray(rectangle, intersects);

    for (int i = 0; i < controllerArray.length; i++) {
      if (cntList.contains(controllerArray[i]) && !selList.contains(controllerArray[i])) {
        selList.add(controllerArray[i]);

        controllerArray[i].setSelected(true);

        if (controllerArray[i].getClient()) {
          fireSelectionEvent(SEL_GAI, controllerArray[i], controllerArray);
        }
      }
    }
  }

  /**
   *
   *
   * @param name
   *
   * @return
   */
  public AController getSelectedController(String name) {
    Iterator itt = selectedIterator();

    while (itt.hasNext()) {
      AController controller = (AController) itt.next();

      if (name.equals(controller.getName())) {
        return controller;
      }
    }

    return null;
  }

  public boolean isSelected(AController controller) {
    return selList.contains(controller);
  }

  /**
   *
   *
   * @param controller
   */
  public void delSelectedController(AController controller) {
    if (!selList.remove(controller)) {
      return;
    }

    controller.setSelected(false);

    if (controller.getClient()) {
      fireSelectionEvent(SEL_LOS, controller, new AController[]{controller});
    }
  }

  /**
   *
   */
  public void clearSelectedControllers() {
    AController[] context = (AController[]) toSelectedArray();

    for (int i = 0; i < context.length; i++) {
      context[i].setSelected(false);

      if (context[i].getClient()) {
        fireSelectionEvent(SEL_LOS, context[i], context);
      }
    }

    selList.clear();
  }

  /**
   *
   *
   * @return
   */
  public Iterator selectedIterator() {
    return selList.iterator();
  }

  /**
   *
   *
   * @return
   */
  public AController[] toSelectedArray() {
    return (AController[]) selList.toArray(new AController[0]);
  }

  // --------------------------------------------------------------------------------
  // Paint methods
  // --------------------------------------------------------------------------------

  public void paint(Graphics2D g2d) {
    paint(g2d, new ARect(0, 0, getW(), getH()));
  }

  public void paint(Graphics2D g2d, ARect r) {
    AffineTransform preTransform = g2d.getTransform();
    AffineTransform oldTransform = (AffineTransform) preTransform.clone();

    // ----------------------------------------
    // Transform back, we need to paint at 0,0
    // ----------------------------------------

    double paintW = getW() * zoom;
    double paintH = getH() * zoom;

    AffineTransform curTransform = null;

    if (paintW < r.getW()) {
      curTransform = AffineTransform.getTranslateInstance((r.getW() - paintW) / 2, 0);
    } else {
      curTransform = AffineTransform.getTranslateInstance(-r.x, 0);
    }

    preTransform.concatenate(curTransform);

    if (paintH < r.getH()) {
      curTransform = AffineTransform.getTranslateInstance(0, (r.getH() - paintH) / 2);
    } else {
      curTransform = AffineTransform.getTranslateInstance(0, -r.y);
    }

    preTransform.concatenate(curTransform);

    // ----------------------------------------
    // Zoom after translation
    // ----------------------------------------

    curTransform = AffineTransform.getScaleInstance(zoom, zoom);
    preTransform.concatenate(curTransform);

    // ----------------------------------------
    // Empty background untransformed
    // ----------------------------------------

    g2d.setBackground(Color.LIGHT_GRAY);
    g2d.clearRect(0, 0, r.getW(), r.getH()); // Fine

    // ----------------------------------------
    // Set Transform
    // ----------------------------------------

    curTransform = AffineTransform.getTranslateInstance(-minX, -minY);
    preTransform.concatenate(curTransform);

    g2d.setTransform(preTransform);

    // ----------------------------------------
    // Canvas background
    // ----------------------------------------

    g2d.setBackground(background);
    g2d.clearRect(minX, minY, getW(), getH());

    // ----------------------------------------
    // The bount rect in canvas coordinates
    // ----------------------------------------

    Point ptSrc = new Point();
    Point ptDst = new Point();

    if (paintW < r.getW()) {
      ptSrc.x = getMinX();
      ptDst.x = getMaxX();
    } else {
      ptSrc.x = transViewToCanv(r, new Point(0, 0)).x;
      ptDst.x = transViewToCanv(r, new Point(r.getW(), r.getH())).x;
    }

    if (paintH < r.getH()) {
      ptSrc.y = getMinY();
      ptDst.y = getMaxY();
    } else {
      ptSrc.y = transViewToCanv(r, new Point(0, 0)).y;
      ptDst.y = transViewToCanv(r, new Point(r.getW(), r.getH())).y;
    }

    ARect rcBnd = new ARect(ptSrc.x, ptSrc.y, ptDst.x - ptSrc.x, ptDst.y - ptSrc.y);

    // ----------------------------------------
    // Set clip
    // ----------------------------------------

    Shape oldClip = g2d.getClip();
    g2d.setClip(rcBnd);

    // ----------------------------------------
    // The rest
    // ----------------------------------------

    firePaintEvent(PNT_PRE, g2d, rcBnd);

    // ----------------------------------------
    // Do paint
    // ----------------------------------------

    ListIterator itt = cntList.listIterator(cntList.size());

    while (itt.hasPrevious()) {
      AController controller = (AController) itt.previous();

      if (rcBnd.intersects(controller.getFullBounds())) {
        controller.paint(g2d);
      }
    }

    firePaintEvent(PNT_POS, g2d, r);

    // ----------------------------------------
    // Restore clip / transform
    // ----------------------------------------

    g2d.setClip(oldClip);
    g2d.setTransform(oldTransform);
  }

  // --------------------------------------------------------------------------------
  // Trans methods
  // --------------------------------------------------------------------------------

  public Point transViewToCanv(ARect rct, Point point) {
    Point ret = new Point();

    double paintW = getW() * zoom;
    double paintH = getH() * zoom;

    // ----------------------------------------
    // Calculate X
    // ----------------------------------------

    if (paintW < rct.getW()) {
      ret.x = (int) (point.x - (rct.getW() - paintW) / 2);
    } else {
      ret.x = (int) (point.x + rct.x);
    }

    ret.x /= zoom;
    ret.x += getMinX();

    // ----------------------------------------
    // Calculate Y
    // ----------------------------------------

    if (paintH < rct.getH()) {
      ret.y = (int) (point.y - (rct.getH() - paintH) / 2);
    } else {
      ret.y = (int) (point.y + rct.y);
    }

    ret.y /= zoom;
    ret.y += getMinY();

    return ret;
  }

  public Point transCanvToView(ARect rct, Point point) {
    Point ret = new Point();

    double paintW = getW() * zoom;
    double paintH = getH() * zoom;

    // ----------------------------------------
    // Calculate X
    // ----------------------------------------

    if (paintW < rct.getW()) {
      ret.x = (int) (point.x * zoom + (rct.getW() - paintW) / 2);
    } else {
      ret.x = (int) (point.x * zoom - rct.x);
    }

    ret.x -= getMinX() * zoom;

    // ----------------------------------------
    // Calculate Y
    // ----------------------------------------

    if (paintH < rct.getH()) {
      ret.y = (int) (point.y * zoom + (rct.getH() - paintH) / 2);
    } else {
      ret.y = (int) (point.y * zoom - rct.y);
    }

    ret.y -= getMinY() * zoom;

    return ret;
  }

  // --------------------------------------------------------------------------------
  // Properties methods
  // --------------------------------------------------------------------------------

  public Color getBackground() {
    return background;
  }

  public void setBackground(Color background) {
    firePropertyChange(new PropertyChangeEvent(this, "background", this.background, background));
    this.background = background;
  }

  // --------------------------------------------------------------------------------

  public ACanvasFactory getCanvasFactory() {
    return canvasFactory;
  }

  public void setCanvasFactory(ACanvasFactory canvasFactory) {
    firePropertyChange(new PropertyChangeEvent(this, "canvasFactory", this.canvasFactory, canvasFactory));
    this.canvasFactory = canvasFactory;
  }

  // --------------------------------------------------------------------------------

  public int getGridW() {
    return gridW;
  }

  public void setGridW(int gridW) {
    firePropertyChange(new PropertyChangeEvent(this, "gridW", this.gridW, gridW));
    this.gridW = gridW;
  }

  // --------------------------------------------------------------------------------

  public int getGridH() {
    return gridH;
  }

  public void setGridH(int gridH) {
    firePropertyChange(new PropertyChangeEvent(this, "gridH", this.gridH, gridH));
    this.gridH = gridH;
  }

  // --------------------------------------------------------------------------------

  public int getMinX() {
    return minX;
  }

  public void setMinX(int minX) {
    firePropertyChange(new PropertyChangeEvent(this, "minX", this.minX, minX));
    this.minX = minX;
  }

  // --------------------------------------------------------------------------------

  public int getMinY() {
    return minY;
  }

  public void setMinY(int minY) {
    firePropertyChange(new PropertyChangeEvent(this, "minY", this.minY, minY));
    this.minY = minY;
  }

  // --------------------------------------------------------------------------------

  public int getMaxX() {
    return maxX;
  }

  public void setMaxX(int maxX) {
    firePropertyChange(new PropertyChangeEvent(this, "maxX", this.maxX, maxX));
    this.maxX = maxX;
  }

  // --------------------------------------------------------------------------------

  public int getMaxY() {
    return maxY;
  }

  public void setMaxY(int maxY) {
    firePropertyChange(new PropertyChangeEvent(this, "maxY", this.maxY, maxY));
    this.maxY = maxY;
  }

  // --------------------------------------------------------------------------------

  public double getZoom() {
    return zoom;
  }

  public void setZoom(double zoom) {
    firePropertyChange(new PropertyChangeEvent(this, "zoom", this.zoom, zoom));
    this.zoom = zoom;
  }

  // --------------------------------------------------------------------------------

  public int getW() {
    return maxX - minX;
  }

  public int getH() {
    return maxY - minY;
  }
}