/**
 * @author DMI: Demian Gutierrez
 */
package com.minotauro.acuarela.test.nogui.b;

import com.minotauro.acuarela.test.nogui.BaseSimpleTest;

/*
 * Created on Aug 25, 2007
 */
public class TestB1 extends BaseSimpleTest {

  // Canvas W/H < paint W/H
  public void test() throws Exception {
    cW = 600;
    cH = 600;
    pW = 800;
    pH = 800;
    zoom = 0.5;
    execute();
    assertTrue(compare());
  }
}
