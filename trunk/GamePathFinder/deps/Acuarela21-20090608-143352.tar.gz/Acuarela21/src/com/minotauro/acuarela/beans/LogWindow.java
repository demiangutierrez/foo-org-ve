package com.minotauro.acuarela.beans;

import java.awt.BorderLayout;
import java.util.Comparator;
import java.util.Iterator;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.Map.Entry;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;

public class LogWindow extends JFrame {

  private static LogWindow instance;

  public static LogWindow getInstance() {
    if (instance == null) {
      instance = new LogWindow();
      instance.setVisible(true);
    }

    return instance;
  }

  private LogWindowTableModel logWindowTableModel;

  private LogWindow() {
    initGUI();
    setSize(1000, 250);
    setLocation(1280 - 1000, 960 - 250);
  }

  public void updateLog(String key, String val) {
    logWindowTableModel.updateLog(key, val);
    System.err.println(key + ": " + val);
  }

  private void initGUI() {
    setLayout(new BorderLayout());

    logWindowTableModel = new LogWindowTableModel();

    JTable tblProp = new JTable(logWindowTableModel);
    add(new JScrollPane(tblProp), BorderLayout.CENTER);
  }

  private static class LogWindowTableModel extends AbstractTableModel {

    private SortedMap<String, String> valByKeyMap;

    public LogWindowTableModel() {
      valByKeyMap = new TreeMap<String, String>(new Comparator<String>() {
        public int compare(String s1, String s2) {
          return s1.compareToIgnoreCase(s2);
        }
      });
    }

    public void updateLog(String key, String val) {
      valByKeyMap.put(key, val);
      fireTableDataChanged();
    }

    public int getColumnCount() {
      return 2;
    }

    public int getRowCount() {
      return valByKeyMap.size();
    }

    @Override
    public String getColumnName(int column) {
      switch (column) {
        case 0 :
          return "Key";
        case 1 :
          return "Val";
      }

      return null;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
      Entry<String, String> entry = null;

      Iterator<Entry<String, String>> itt = valByKeyMap.entrySet().iterator();

      for (int i = 0; itt.hasNext(); i++) {
        entry = itt.next();

        if (i == rowIndex) {
          break;
        }
      }

      if (entry == null) {
        return null;
      }

      switch (columnIndex) {
        case 0 :
          return entry.getKey();
        case 1 :
          return entry.getValue();
      }

      return null;
    }
  }
}
