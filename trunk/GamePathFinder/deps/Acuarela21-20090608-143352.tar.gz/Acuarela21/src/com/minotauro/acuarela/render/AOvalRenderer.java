/*
 * Created on Sep 28, 2003
 */
package com.minotauro.acuarela.render;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Stroke;


import com.minotauro.acuarela.base.AController;
import com.minotauro.acuarela.base.ARenderer;
import com.minotauro.acuarela.util.ARect;

/**
 * @author DMI: Demian Gutierrez
 */
public class AOvalRenderer extends ARenderer {
  /**
   *
   */
  public AOvalRenderer() {
    //		setProperty("clrPen", Color.black);
    //		setProperty("clrFll", Color.white);
    //		setProperty("strPen", new BasicStroke(1));
    //
    //		setProperty("clrPenDis", Color.gray);
    //		setProperty("clrFllDis", Color.white);
    //		setProperty("strPenDis", new BasicStroke(1));
  }

  /**
   *
   */
  public void paint(Graphics2D g2d, AController object) {
    //		String disable = object.getDisable() ? "Dis" : "";

    //		Color clrPen = (Color) getProperty("clrPen" + disable);
    //		Color clrFll = (Color) getProperty("clrFll" + disable);
    //		Stroke strPen = (Stroke) getProperty("strPen" + disable);

    Color clrPen = Color.BLACK;
    Color clrFll = null;
    Stroke strPen = new BasicStroke(1);
    ARect rct = object.getBounds();

    if (clrFll != null) {
      g2d.setColor(clrFll);
      g2d.fillOval((int) rct.getX(), (int) rct.getY(), rct.getW(), rct.getH());
    }

    if (clrPen != null) {
      g2d.setColor(clrPen);
      g2d.setStroke(strPen);
      g2d.drawOval((int) rct.getX(), (int) rct.getY(), rct.getW(), rct.getH());
    }
  }
}