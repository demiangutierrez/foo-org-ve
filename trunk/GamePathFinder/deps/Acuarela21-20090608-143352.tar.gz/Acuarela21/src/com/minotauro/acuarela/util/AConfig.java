/*
 * Created on Oct 12, 2003
 */
package com.minotauro.acuarela.util;

import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.StringTokenizer;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class AConfig
{
	private static Properties prp;

	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	static {

		Properties def = new Properties();

		try
		{
			def.load(AConfig.class.getResourceAsStream("AConfig.properties"));

			prp = new Properties(def);

			InputStream is = ClassLoader.getSystemResourceAsStream("AConfig.properties");

			if (is != null)
			{
				prp.load(is);
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	private AConfig()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param key
	 *
	 * @return
	 */
	public static String getStringProperty(String key)
	{
		return prp.getProperty(key);
	}

	/**
	 *
	 *
	 * @param key
	 *
	 * @return
	 */
	public static boolean getBooleanProperty(String key)
	{
		Boolean ret = new Boolean(prp.getProperty(key));

		return ret.booleanValue();
	}

	/**
	 *
	 *
	 * @param key
	 *
	 * @return
	 */
	public static int getIntegerProperty(String key)
	{
		return Integer.parseInt(prp.getProperty(key));
	}

	/**
	 *
	 *
	 * @param key
	 *
	 * @return
	 */
	public static double getDoubleProperty(String key)
	{
		return Double.parseDouble(prp.getProperty(key));
	}

	// --------------------------------------------------------------------------------
	// TODO: Pack colors in hex rgb format

	/**
	 *
	 *
	 * @param key
	 *
	 * @return
	 */
	public static Color getColorProperty(String key)
	{
		Color ret = null;

		String strCol = prp.getProperty(key);

		// TODO: Complain at "Complain" comments
		if (strCol == null)
		{
			// Complain
		}

		StringTokenizer strTok = new StringTokenizer(strCol, ",");

		if (strTok.countTokens() == 3)
		{
			try
			{
				int r = Integer.parseInt(strTok.nextToken());
				int g = Integer.parseInt(strTok.nextToken());
				int b = Integer.parseInt(strTok.nextToken());

				if (r < 0 || r > 255 || g < 0 || g > 255 || b < 0 || b > 255)
				{
					// Complain
				}

				ret = new Color(r, g, b);
			}
			catch (NumberFormatException e)
			{
				// Complain
			}
		}
		else
		{
			// Complain
		}

		return ret;
	}

	// --------------------------------------------------------------------------------
	// TODO: This can be improved using knowledge from
	// FrmAnalysisTextEditor from Aquis

	/**
	 *
	 */
	public static Font getFontProperty(String key)
	{
		Font ret = null;

		String strFnt = prp.getProperty(key);

		// TODO: Complain at "Complain" comments
		if (strFnt == null)
		{
			// Complain
		}

		StringTokenizer strTok = new StringTokenizer(strFnt, ",");

		if (strTok.countTokens() == 3)
		{
			String name = strTok.nextToken();

			if (!name.equals("Dialog")
				&& !name.equals("DialogInput")
				&& !name.equals("Monospaced")
				&& !name.equals("Serif")
				&& !name.equals("SansSerif")
				&& !name.equals("Default"))
			{
				// Complain
			}

			try
			{
				int style = Integer.parseInt(strTok.nextToken());

				int size = Integer.parseInt(strTok.nextToken());

				if (size < 1)
				{
					// Complain
				}

				ret = new Font(name, style, size);
			}
			catch (NumberFormatException e)
			{
				// Complain
			}
		}

		return ret;
	}
}
