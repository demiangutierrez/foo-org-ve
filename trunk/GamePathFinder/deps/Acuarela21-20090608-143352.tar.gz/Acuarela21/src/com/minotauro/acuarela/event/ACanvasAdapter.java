/*
 * Created on Nov 20, 2003
 */
package com.minotauro.acuarela.event;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class ACanvasAdapter implements ACanvasListener
{
	/**
	 *
	 */
	public ACanvasAdapter()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// ACanvasListener
	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public void objectAdded(ACanvasEvent evt)
	{
		// Empty
	}

	/**
	 *
	 */
	public void objectRemoved(ACanvasEvent evt)
	{
		// Empty
	}
}
