/*
 * Created on Jul 09, 2007
 */
package com.minotauro.acuarela.util;

import java.awt.Dimension;

/**
 * @author Demian Gutierrez
 */
public class ADimension extends Dimension {

  public ADimension() {
    // Empty
  }

  public ADimension(Dimension d) {
    super(d);
  }

  public ADimension(int w, int h) {
    super(w, h);
  }

  /**
   *
   *
   * @return
   */
  public int getW() {
    return width;
  }

  /**
   *
   *
   * @param w
   */
  public void setW(int w) {
    width = w;
  }

  /*
   * Get / set methods for height
   */

  /**
   *
   *
   * @return
   */
  public int getH() {
    return height;
  }

  /**
   *
   *
   * @param h
   */
  public void setH(int h) {
    height = h;
  }

  /*
   * Static factory
   */

  public static ADimension d(Dimension d) {
    ADimension ret;

    if (d instanceof ADimension) {
      ret = (ADimension) d;
    } else {
      ret = d != null ? new ADimension(d) : null;
    }

    return ret;
  }
}
