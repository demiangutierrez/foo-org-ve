/*
 * Created on Sep 26, 2003
 */
package com.minotauro.acuarela.util;

import java.awt.Dimension;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class ADist extends Dimension
{
	/**
	 *
	 */
	public ADist()
	{
		// Empty
	}

	/**
	 *
	 *
	 * @param d
	 */
	public ADist(Dimension d)
	{
		super(d);
	}

	/**
	 *
	 *
	 * @param dx
	 * @param dy
	 */
	public ADist(int dx, int dy)
	{
		super(dx, dy);
	}

	/*
	 * Get / set methods for dx
	 */

	/**
	 *
	 *
	 * @return
	 */
	public int getDx()
	{
		return width;
	}

	/**
	 *
	 *
	 * @param dx
	 */
	public void setDx(int dx)
	{
		width = dx;
	}

	/*
	 * Get / set methods for dy
	 */

	/**
	 *
	 *
	 * @return
	 */
	public int getDy()
	{
		return height;
	}

	/**
	 *
	 *
	 * @param dy
	 */
	public void setDy(int dy)
	{
		height = dy;
	}
}
