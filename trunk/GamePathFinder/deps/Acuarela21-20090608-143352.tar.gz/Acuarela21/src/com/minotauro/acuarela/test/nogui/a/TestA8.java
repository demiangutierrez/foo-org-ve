/**
 * @author DMI: Demian Gutierrez
 */
package com.minotauro.acuarela.test.nogui.a;

import com.minotauro.acuarela.test.nogui.BaseSimpleTest;

/*
 * Created on Aug 25, 2007
 */
public class TestA8 extends BaseSimpleTest {

  // W/H Test
  // Canvas H < to paint H (cW > pW) (x + 10)
  public void test() throws Exception {
    pX = 10;
    cW = 600;
    cH = 600;
    pW = 590;
    pH = 800;
    execute();
    assertTrue(compare());
  }
}
