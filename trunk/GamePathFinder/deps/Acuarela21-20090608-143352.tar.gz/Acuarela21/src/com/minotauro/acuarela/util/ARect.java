/*
 * Created on Sep 25, 2003
 */
package com.minotauro.acuarela.util;

import java.awt.Rectangle;

/**
 * @author Demian Gutierrez
 */
public class ARect extends Rectangle {
  
  /**
   *
   */
  public ARect() {
    // Empty
  }

  /**
   *
   *
   * @param r
   */
  public ARect(Rectangle r) {
    super(r);
  }

  /**
   *
   *
   * @param x
   * @param y
   * @param w
   * @param h
   */
  public ARect(int x, int y, int w, int h) {
    super(x, y, w, h);
  }

  /*
   * Get / set methods for width
   */

  /**
   *
   *
   * @return
   */
  public int getW() {
    return width;
  }

  /**
   *
   *
   * @param w
   */
  public void setW(int w) {
    width = w;
  }

  /*
   * Get / set methods for height
   */

  /**
   *
   *
   * @return
   */
  public int getH() {
    return height;
  }

  /**
   *
   *
   * @param h
   */
  public void setH(int h) {
    height = h;
  }

  /*
   * Get / set methods for width / 2
   */

  /**
   *
   *
   * @return
   */
  public int getW2() {
    return width / 2;
  }

  /**
   *
   *
   * @param w2
   */
  public void setW2(int w2) {
    width = 2 * w2;
  }

  /*
   * Get / set methods for height / 2
   */

  /**
   *
   *
   * @return
   */
  public int getH2() {
    return height / 2;
  }

  /**
   *
   *
   * @param h2
   */
  public void setH2(int h2) {
    height = 2 * h2;
  }

  /*
   * Min / Max methods
   */

  /**
   *
   *
   * @return
   */
  public int maxX() {
    return (int) super.getMaxX();
  }

  /**
   *
   *
   * @return
   */
  public int minX() {
    return (int) super.getMinX();
  }

  /**
   *
   *
   * @return
   */
  public int maxY() {
    return (int) super.getMaxY();
  }

  /**
   *
   *
   * @return
   */
  public int minY() {
    return (int) super.getMinY();
  }

  /*
   * Center methods
   */

  /**
   *
   *
   * @return
   */
  public int centerX() {
    return (int) super.getCenterX();
  }

  /**
   *
   *
   * @return
   */
  public int centerY() {
    return (int) super.getCenterY();
  }

  /*
   * Static factory
   */

  /**
   *
   *
   * @param r
   *
   * @return
   */
  public static ARect r(Rectangle r) {
    ARect ret;

    if (r instanceof ARect) {
      ret = (ARect) r;
    } else {
      ret = r != null ? new ARect(r) : null;
    }

    return ret;
  }
}
