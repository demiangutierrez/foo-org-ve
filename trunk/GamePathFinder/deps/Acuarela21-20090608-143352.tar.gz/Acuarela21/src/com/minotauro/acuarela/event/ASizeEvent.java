/*
 * Created on Dec 18, 2004
 */
package com.minotauro.acuarela.event;

import java.util.EventObject;

import com.minotauro.acuarela.util.ADist;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class ASizeEvent extends EventObject
{
	private ADist size;

	/**
	 *
	 *
	 * @param source
	 * @param size
	 */
	public ASizeEvent(Object source, ADist size)
	{
		super(source);

		this.size = size;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public ADist getSize()
	{
		return size;
	}

	/**
	 *
	 *
	 * @param size
	 */
	public void setSize(ADist size)
	{
		this.size = size;
	}
}