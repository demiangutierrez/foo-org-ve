/*
 * Created on Nov 20, 2003
 */
package com.minotauro.acuarela.event;

import java.util.EventObject;

import com.minotauro.acuarela.base.AController;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class ACanvasEvent extends EventObject
{
	private AController controller;

	/**
	 *
	 *
	 * @param source
	 * @param controller
	 */
	public ACanvasEvent(Object source, AController controller)
	{
		super(source);

		this.controller = controller;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public AController getController()
	{
		return controller;
	}

	/**
	 *
	 *
	 * @param controller
	 */
	public void setController(AController controller)
	{
		this.controller = controller;
	}
}