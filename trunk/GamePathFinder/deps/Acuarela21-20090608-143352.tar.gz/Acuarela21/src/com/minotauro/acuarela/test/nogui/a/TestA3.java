/**
 * @author DMI: Demian Gutierrez
 */
package com.minotauro.acuarela.test.nogui.a;

import com.minotauro.acuarela.test.nogui.BaseSimpleTest;

/*
 * Created on Aug 25, 2007
 */
public class TestA3 extends BaseSimpleTest {

  // Canvas H < paint H (cW = pW)
  public void test() throws Exception {
    cW = 600;
    cH = 600;
    pW = 600;
    pH = 800;
    execute();
    assertTrue(compare());
  }
}
