/**
 * @author DMI: Demian Gutierrez
 */
package com.minotauro.acuarela.test.nogui.a;

import com.minotauro.acuarela.test.nogui.BaseSimpleTest;

/*
 * Created on Aug 25, 2007
 */
public class TestA6 extends BaseSimpleTest {

  // Canvas W/H > to paint W/H
  public void test() throws Exception {
    cW = 600;
    cH = 600;
    pW = 590;
    pH = 590;
    execute();
    assertTrue(compare());
  }
}
