/*
 * Created on May 28, 2007
 */
package com.minotauro.acuarela.test.nogui;

import java.awt.Color;
import java.awt.Point;
import java.awt.Shape;

import com.minotauro.acuarela.base.AConnPoint;
import com.minotauro.acuarela.base.AConnSource;
import com.minotauro.acuarela.base.ACtrlPoint;
import com.minotauro.acuarela.base.AVertexImpl;
import com.minotauro.acuarela.render.AShapeRenderer;
import com.minotauro.acuarela.util.ARect;

/**
 * @author DMI: Demian Gutierrez
 */
public class ATest extends AVertexImpl implements AConnSource, AConnPoint {

  protected ACtrlPoint ctrlBeg;
  protected ACtrlPoint ctrlEnd;

  // --------------------------------------------------------------------------------

  public ATest(int x1, int y1, int x2, int y2, Color color) {
    init(new ACtrlPoint(x1, y1), new ACtrlPoint(x2, y2), color);
  }

  // --------------------------------------------------------------------------------

  public void init(ACtrlPoint ctrlBeg, ACtrlPoint ctrlEnd, Color color) {
    movable/* */= true;
    visible/* */= true;
    selected/**/= true;

    addRenderer(new ATestRenderer(color));

    this.ctrlBeg = ctrlBeg;
    ctrlBeg.setName("ctrlBeg");
    ctrlBeg.addRenderer(new AShapeRenderer());
    ctrlBeg.setVisible(true);

    this.ctrlEnd = ctrlEnd;
    ctrlEnd.setName("ctrlEnd");
    ctrlEnd.addRenderer(new AShapeRenderer());
    ctrlEnd.setVisible(true);
  }

  // --------------------------------------------------------------------------------
  // AController methods
  // --------------------------------------------------------------------------------

  public void initController() {
    addCtrlPoint(ctrlBeg);
    addCtrlPoint(ctrlEnd);
  }

  public void attachController() {
    // Empty
  }

  public void detachController() {
    // Empty
  }

  public Shape getShape() {
    ARect ret = new ARect();

    ret.x = Math.min(ctrlBeg.getX(), ctrlEnd.getX());
    ret.y = Math.min(ctrlBeg.getY(), ctrlEnd.getY());

    ret.setW(Math.abs(ctrlEnd.getX() - ctrlBeg.getX()));
    ret.setH(Math.abs(ctrlEnd.getY() - ctrlBeg.getY()));

    return ret;
  }

  // --------------------------------------------------------------------------------
  // AConnSource
  // --------------------------------------------------------------------------------

  public AConnPoint getConnPoint(Point dst) {
    return this;
  }

  // --------------------------------------------------------------------------------
  // AConnPoint
  // --------------------------------------------------------------------------------

  public Point getPoint(Point dst) {
    return new Point(ctrlBeg.getX(), ctrlEnd.getY());
  }

  @Override
  public String toString() {
    return "(" + ctrlBeg.getX() + ", " + ctrlBeg.getY() + //
        "), (" + ctrlEnd.getX() + ", " + ctrlEnd.getY() + ")";
  }
}