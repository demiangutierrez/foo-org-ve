/*
 * Created on Sep 28, 2003
 */
package com.minotauro.acuarela.controllers;

import java.awt.Point;
import java.awt.Shape;


import com.minotauro.acuarela.base.AController;
import com.minotauro.acuarela.base.ACtrlPoint;
import com.minotauro.acuarela.base.AVertexImpl;
import com.minotauro.acuarela.event.AMotionEvent;
import com.minotauro.acuarela.event.AMotionException;
import com.minotauro.acuarela.event.AMotionListener;
import com.minotauro.acuarela.render.AShapeRenderer;
import com.minotauro.acuarela.util.ARect;

/**
 * @author DMI: Demian Gutierrez
 */
public class ARectangle extends AVertexImpl
{
	protected ACtrlPoint ctrlBeg;
	protected ACtrlPoint ctrlEnd;
	protected ACtrlPoint ctrlBegAux;
	protected ACtrlPoint ctrlEndAux;

	/**
	 *
	 */
	public ARectangle()
	{
		ctrlBeg = new ACtrlPoint(ctrlBeg.getX(), ctrlEnd.getY());
		ctrlBeg.setName("ctrlBeg");

		ctrlEnd = new ACtrlPoint(ctrlEnd.getX(), ctrlBeg.getY());
		ctrlEnd.setName("ctrlEnd");

		ctrlBegAux = new ACtrlPoint(ctrlBeg.getX(), ctrlEnd.getY());
		ctrlBegAux.setName("ctrlBegAux");

		ctrlEndAux = new ACtrlPoint(ctrlEnd.getX(), ctrlBeg.getY());
		ctrlEndAux.setName("ctrlEndAux");
	}

	/**
	 *
	 *
	 * @param ctrlBeg
	 * @param ctrlEnd
	 */
	public ARectangle(ACtrlPoint ctrlBeg, ACtrlPoint ctrlEnd)
	{
		this.ctrlBeg = ctrlBeg;
		ctrlBeg.setName("ctrlBeg");
		ctrlBeg.addRenderer(new AShapeRenderer());
		ctrlBeg.setVisible(true);

		this.ctrlEnd = ctrlEnd;
		ctrlEnd.setName("ctrlEnd");
		ctrlEnd.addRenderer(new AShapeRenderer());
		ctrlEnd.setVisible(true);

		ctrlBegAux = new ACtrlPoint(ctrlBeg.getX(), ctrlEnd.getY());
		ctrlBegAux.setName("ctrlBegAux");
		ctrlBegAux.addRenderer(new AShapeRenderer());
		ctrlBegAux.setVisible(true);

		ctrlEndAux = new ACtrlPoint(ctrlEnd.getX(), ctrlBeg.getY());
		ctrlEndAux.setName("ctrlEndAux");
		ctrlEndAux.addRenderer(new AShapeRenderer());
		ctrlEndAux.setVisible(true);
	}

	// --------------------------------------------------------------------------------
	// AController methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public void initController()
	{
		addCtrlPoint(ctrlBeg);
		addCtrlPoint(ctrlEnd);

		addCtrlPoint(ctrlBegAux);
		addCtrlPoint(ctrlEndAux);

		ctrlBeg.addMotionListener(new AMotionListener()
		{
			public void controllerMoved(AMotionEvent evt) throws AMotionException
			{
				ctrlBegAux.setX(ctrlBeg.getX());
				ctrlEndAux.setY(ctrlBeg.getY());
			}
		});

		ctrlEnd.addMotionListener(new AMotionListener()
		{
			public void controllerMoved(AMotionEvent evt) throws AMotionException
			{
				ctrlBegAux.setY(ctrlEnd.getY());
				ctrlEndAux.setX(ctrlEnd.getX());
			}
		});

		ctrlBegAux.addMotionListener(new AMotionListener()
		{
			public void controllerMoved(AMotionEvent evt) throws AMotionException
			{
				ctrlBeg.setX(ctrlBegAux.getX());
				ctrlEnd.setY(ctrlBegAux.getY());
			}
		});

		ctrlEndAux.addMotionListener(new AMotionListener()
		{
			public void controllerMoved(AMotionEvent evt) throws AMotionException
			{
				ctrlBeg.setY(ctrlEndAux.getY());
				ctrlEnd.setX(ctrlEndAux.getX());
			}
		});
	}

	/**
	 *
	 */
	public void attachController()
	{
		// Empty
	}

	/**
	 *
	 */
	public void detachController()
	{
		// Empty
	}

	/**
	 *
	 */
	public Shape getShape()
	{
		ARect ret = new ARect();

		ret.x = (ctrlBeg.getX() < ctrlEnd.getX()) ? ctrlBeg.getX() : ctrlEnd.getX();
		ret.y = (ctrlBeg.getY() < ctrlEnd.getY()) ? ctrlBeg.getY() : ctrlEnd.getY();

		ret.setW(Math.abs(ctrlEnd.getX() - ctrlBeg.getX()));
		ret.setH(Math.abs(ctrlEnd.getY() - ctrlBeg.getY()));

		return ret;
	}

	/**
	 *
	 */
	public Point getJoint(AController controller)
	{
		return null;
	}
}