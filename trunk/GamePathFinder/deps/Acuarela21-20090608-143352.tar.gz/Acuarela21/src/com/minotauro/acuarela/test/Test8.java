/*
 * Created on Dec 30, 2004
 */
package com.minotauro.acuarela.test;

import com.minotauro.acuarela.base.ACanvas;
import com.minotauro.acuarela.base.ACanvasFactory;
import com.minotauro.acuarela.base.ACtrlPoint;
import com.minotauro.acuarela.beans.ASwingPanel;
import com.minotauro.acuarela.test.controllers.FuzzyRectangleController;
import com.minotauro.acuarela.test.render.FuzzyRectangleRenderer;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class Test8 extends TestFrame {
  protected boolean single = false;

  /**
   *
   */
  public Test8() {
    // Empty
  }

  /**
   *
   */
  protected ASwingPanel initSwingPanel() {
    ACanvas canvas = new ACanvas(new ACanvasFactory());
    //    canvas.setW(5000);
    //    canvas.setH(5000);
    canvas.setMinX(0);
    canvas.setMinY(0);
    canvas.setMaxX(5000);
    canvas.setMaxY(5000);

    ASwingPanel ret = new ASwingPanel(canvas);
    ret.addPanelMouseInteractor(new MoveInteractor());
    ret.addPanelMouseInteractor(new SelectionInteractor());

    f1 : for (int i = 0; i < canvas.getW() / 110; i++) {
      for (int j = 0; j < canvas.getH() / 110; j++) {
        ACtrlPoint ctrlBeg = new ACtrlPoint(i * 110, j * 110);
        ACtrlPoint ctrlEnd = new ACtrlPoint(i * 110 + 100, j * 110 + 100);

        FuzzyRectangleController fuzzyRectangleController = new FuzzyRectangleController(ctrlBeg, ctrlEnd);

        fuzzyRectangleController.setName(i + ";" + j);
        fuzzyRectangleController.addRenderer(new FuzzyRectangleRenderer());
        fuzzyRectangleController.setVisible(true);

        canvas.addController(fuzzyRectangleController);

        if (single) {
          break f1;
        }
      }
    }

    return ret;
  }

  /**
   *
   *
   * @param args
   */
  public static void main(String[] args) {
    new Test8();
  }
}