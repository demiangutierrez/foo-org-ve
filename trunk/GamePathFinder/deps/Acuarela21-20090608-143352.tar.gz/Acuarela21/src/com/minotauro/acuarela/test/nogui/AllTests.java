package com.minotauro.acuarela.test.nogui;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.apache.commons.lang.ClassUtils;

public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite(ClassUtils.getPackageName(AllTests.class));

    //$JUnit-BEGIN$
    suite.addTest(com.minotauro.acuarela.test.nogui.a.AllTests.suite());
    suite.addTest(com.minotauro.acuarela.test.nogui.b.AllTests.suite());
    suite.addTest(com.minotauro.acuarela.test.nogui.c.AllTests.suite());
    suite.addTest(com.minotauro.acuarela.test.nogui.d.AllTests.suite());
    suite.addTest(com.minotauro.acuarela.test.nogui.e.AllTests.suite());
    suite.addTest(com.minotauro.acuarela.test.nogui.f.AllTests.suite());
    suite.addTest(com.minotauro.acuarela.test.nogui.g.AllTests.suite());
    suite.addTest(com.minotauro.acuarela.test.nogui.h.AllTests.suite());
    suite.addTest(com.minotauro.acuarela.test.nogui.i.AllTests.suite());
    //$JUnit-END$

    return suite;
  }
}
