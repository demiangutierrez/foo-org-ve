/*
 * Created on Dec 30, 2004
 */
package com.minotauro.acuarela.test.controllers;

import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;


import com.minotauro.acuarela.base.ACtrlPoint;
import com.minotauro.acuarela.beans.ASwingPanel;
import com.minotauro.acuarela.controllers.ARectangle;
import com.minotauro.acuarela.event.AControllerMouseAdapter;
import com.minotauro.acuarela.event.AControllerMouseEvent;
import com.minotauro.acuarela.event.ARepaintEvent;
import com.minotauro.acuarela.util.ARect;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class MouseDemoController extends ARectangle {
  private boolean insideCanvas;

  private boolean insideController;

  /**
   *
   *
   * @param ctrlBeg
   * @param ctrlEnd
   */
  public MouseDemoController(ACtrlPoint ctrlBeg, ACtrlPoint ctrlEnd) {
    super(ctrlBeg, ctrlEnd);

    addControllerMouseListener(new AControllerMouseAdapter() {
      public void controllerMouseEntered(AControllerMouseEvent evt) {
        insideCanvas = true;
        fireRepaintEvent(new ARepaintEvent(this));
      }

      public void controllerMouseExited(AControllerMouseEvent evt) {
        insideCanvas = false;
        insideController = false;
        fireRepaintEvent(new ARepaintEvent(this));
      }

      public void controllerMouseMoved(AControllerMouseEvent evt) {
        MouseEvent mouseEvent = evt.getMouseEvent();

        ASwingPanel aSwingPanel = (ASwingPanel) mouseEvent.getSource();
        //ACanvas aCanvas = aSwingPanel.getCanvas();

        Point2D pt = aSwingPanel.viewToCanvas(mouseEvent.getPoint());

        ARect r = getBounds();

        if (r.contains(pt)) {
          insideController = true;
        } else {
          insideController = false;
        }

        fireRepaintEvent(new ARepaintEvent(this));
      }
    });
  }

  /**
   *
   *
   * @return
   */
  public boolean isInsideCanvas() {
    return insideCanvas;
  }

  /**
   *
   *
   * @return
   */
  public boolean isInsideController() {
    return insideController;
  }
}