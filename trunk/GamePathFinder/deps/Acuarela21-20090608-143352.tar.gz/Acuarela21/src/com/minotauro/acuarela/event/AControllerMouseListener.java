/*
 * Created on Dec 18, 2004
 */
package com.minotauro.acuarela.event;

import java.util.EventListener;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface AControllerMouseListener extends EventListener {
  public static final int CONTROLLER_MOUSE_CLICKED = 0;

  public static final int CONTROLLER_MOUSE_ENTERED = 1;

  public static final int CONTROLLER_MOUSE_EXITED = 2;

  public static final int CONTROLLER_MOUSE_PRESSED = 3;

  public static final int CONTROLLER_MOUSE_RELEASED = 4;

  public static final int CONTROLLER_MOUSE_DRAGGED = 5;

  public static final int CONTROLLER_MOUSE_MOVED = 6;

  /**
   *
   *
   * @param evt
   */
  public void controllerMouseClicked(AControllerMouseEvent evt);

  /**
   *
   *
   * @param evt
   */
  public void controllerMouseEntered(AControllerMouseEvent evt);

  /**
   *
   *
   * @param evt
   */
  public void controllerMouseExited(AControllerMouseEvent evt);

  /**
   *
   *
   * @param evt
   */
  public void controllerMousePressed(AControllerMouseEvent evt);

  /**
   *
   *
   * @param evt
   */
  public void controllerMouseReleased(AControllerMouseEvent evt);

  /**
   *
   *
   * @param evt
   */
  public void controllerMouseDragged(AControllerMouseEvent evt);

  /**
   *
   *
   * @param evt
   */
  public void controllerMouseMoved(AControllerMouseEvent evt);
}