/*
 * Created on Sep 13, 2004
 */
package com.minotauro.acuarela.base;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface AHistoryEntry
{
	/**
	 *
	 */
	public boolean canExecute();

	/**
	 *
	 */
	public boolean canRedo();

	/**
	 *
	 */
	public boolean canUndo();

	/**
	 *
	 */
	public void dispose();

	/**
	 *
	 */
	public void execute();

	/**
	 *
	 */
	public void redo();

	/**
	 *
	 */
	public void undo();
}