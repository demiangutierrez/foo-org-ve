/*
 * Created on Nov 20, 2003
 */
package com.minotauro.acuarela.event;

import java.util.EventListener;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface ACanvasListener extends EventListener
{
	/**
	 *
	 *
	 * @param evt
	 */
	public void objectAdded(ACanvasEvent evt);

	/**
	 *
	 *
	 * @param evt
	 */
	public void objectRemoved(ACanvasEvent evt);
}
