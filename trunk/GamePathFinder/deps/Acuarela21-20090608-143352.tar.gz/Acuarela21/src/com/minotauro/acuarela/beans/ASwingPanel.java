/*
 * Created on Aug 13, 2004
 */
package com.minotauro.acuarela.beans;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.util.LinkedHashMap;

import javax.swing.JPanel;
import javax.swing.JViewport;

import com.minotauro.acuarela.base.ACanvas;
import com.minotauro.acuarela.base.ACanvasFactory;
import com.minotauro.acuarela.event.AControllerMouseEvent;
import com.minotauro.acuarela.event.AControllerMouseListener;
import com.minotauro.acuarela.event.ARepaintEvent;
import com.minotauro.acuarela.event.ARepaintListener;
import com.minotauro.acuarela.util.ARect;
import com.minotauro.acuarela.util.ATracer;

/**
 * @author Demian Gutierrez
 */
public class ASwingPanel extends JPanel implements ARepaintListener, KeyListener, MouseListener, MouseMotionListener {

  private LinkedHashMap panelMouseInteractorMap = new LinkedHashMap();

  private ACanvasFactory canvasFactory = new ACanvasFactory();
  private ACanvas canvas;

  // --------------------------------------------------------------------------------

  public ASwingPanel(ACanvas canvas) {
    setCanvas(canvas);

    setFocusable(true);

    addMouseMotionListener(this);
    addMouseListener(this);
    addKeyListener(this);
  }

  // --------------------------------------------------------------------------------
  // JPanel methods
  // --------------------------------------------------------------------------------

  public void paint(Graphics g) {
    update(g);
  }

  public void update(Graphics g) {
    JViewport viewport = (JViewport) getParent();
    ARect rct = ARect.r(viewport.getViewRect());

    rct.setW((int) (rct.getW() + canvas.getZoom()));
    rct.setH((int) (rct.getH() + canvas.getZoom()));

    BufferedImage bimg = canvasFactory.getBufferedImage(rct.getW(), rct.getH());

    Graphics2D g2d = (Graphics2D) bimg.getGraphics();
    canvas.paint(g2d, rct);
    g2d.dispose();

    g2d = (Graphics2D) g;

    g2d.setBackground(Color.BLACK); // DEBUG
    g2d.clearRect(0, 0, getWidth(), getHeight()); // DEBUG

    g2d.drawImage(bimg, rct.x, rct.y, null);
  }

  public void repaintRequest(ARepaintEvent evt) {
    repaint();
  }

  // --------------------------------------------------------------------------------
  // KeyListener methods
  // --------------------------------------------------------------------------------

  public void keyPressed(KeyEvent evt) {
    ATracer.trace(KeyEvent.getModifiersExText(evt.getModifiersEx()) + ";" + evt.getKeyChar());
    System.out.println("ASwingPanel.keyPressed()");
  }

  public void keyReleased(KeyEvent evt) {
    ATracer.trace(KeyEvent.getModifiersExText(evt.getModifiersEx()) + ";" + evt.getKeyChar());
    System.out.println("ASwingPanel.keyReleased()");
  }

  public void keyTyped(KeyEvent evt) {
    ATracer.trace(KeyEvent.getModifiersExText(evt.getModifiersEx()) + ";" + evt.getKeyChar());
    System.out.println("ASwingPanel.keyTyped()");
  }

  // --------------------------------------------------------------------------------
  // MouseListener methods
  // --------------------------------------------------------------------------------

  public void mouseClicked(MouseEvent evt) {
    ATracer.trace(evt.getX() + ";" + evt.getY());

    AControllerMouseEvent aControllerMouseEvent = new AControllerMouseEvent(this, evt);
    canvas.fireControllerMouseEvent(AControllerMouseListener.CONTROLLER_MOUSE_CLICKED, aControllerMouseEvent);
    firePanelMouseEvent(APanelMouseInteractor.PANEL_MOUSE_CLICKED, evt);
  }

  public void mouseEntered(MouseEvent evt) {
    ATracer.trace(evt.getX() + ";" + evt.getY());

    AControllerMouseEvent aControllerMouseEvent = new AControllerMouseEvent(this, evt);
    canvas.fireControllerMouseEvent(AControllerMouseListener.CONTROLLER_MOUSE_ENTERED, aControllerMouseEvent);
    firePanelMouseEvent(APanelMouseInteractor.PANEL_MOUSE_ENTERED, evt);
  }

  public void mouseExited(MouseEvent evt) {
    ATracer.trace(evt.getX() + ";" + evt.getY());

    AControllerMouseEvent aControllerMouseEvent = new AControllerMouseEvent(this, evt);
    canvas.fireControllerMouseEvent(AControllerMouseListener.CONTROLLER_MOUSE_EXITED, aControllerMouseEvent);
    firePanelMouseEvent(APanelMouseInteractor.PANEL_MOUSE_EXITED, evt);
  }

  public void mousePressed(MouseEvent evt) {
    ATracer.trace(evt.getX() + ";" + evt.getY());

    // Get the focus
    requestFocus();

    AControllerMouseEvent aControllerMouseEvent = new AControllerMouseEvent(this, evt);
    canvas.fireControllerMouseEvent(AControllerMouseListener.CONTROLLER_MOUSE_PRESSED, aControllerMouseEvent);
    firePanelMouseEvent(APanelMouseInteractor.PANEL_MOUSE_PRESSED, evt);
  }

  public void mouseReleased(MouseEvent evt) {
    ATracer.trace(evt.getX() + ";" + evt.getY());

    AControllerMouseEvent aControllerMouseEvent = new AControllerMouseEvent(this, evt);
    canvas.fireControllerMouseEvent(AControllerMouseListener.CONTROLLER_MOUSE_RELEASED, aControllerMouseEvent);
    firePanelMouseEvent(APanelMouseInteractor.PANEL_MOUSE_RELEASED, evt);
  }

  // --------------------------------------------------------------------------------
  // MouseMotionListener methods
  // --------------------------------------------------------------------------------

  public void mouseDragged(MouseEvent evt) {
    ATracer.trace(evt.getX() + ";" + evt.getY());

    AControllerMouseEvent aControllerMouseEvent = new AControllerMouseEvent(this, evt);
    canvas.fireControllerMouseEvent(AControllerMouseListener.CONTROLLER_MOUSE_DRAGGED, aControllerMouseEvent);
    firePanelMouseEvent(APanelMouseInteractor.PANEL_MOUSE_DRAGGED, evt);
  }

  public void mouseMoved(MouseEvent evt) {
    ATracer.trace(evt.getX() + ";" + evt.getY());

    AControllerMouseEvent aControllerMouseEvent = new AControllerMouseEvent(this, evt);
    canvas.fireControllerMouseEvent(AControllerMouseListener.CONTROLLER_MOUSE_MOVED, aControllerMouseEvent);
    firePanelMouseEvent(APanelMouseInteractor.PANEL_MOUSE_MOVED, evt);
  }

  // --------------------------------------------------------------------------------
  // APanelMouseInteractor methods
  // --------------------------------------------------------------------------------

  public void addPanelMouseInteractor(APanelMouseInteractor interactor) {
    interactor.attachPanelMouseInteractor(this);
    panelMouseInteractorMap.put(interactor.getName(), interactor);
    repaint();
  }

  public void delPanelMouseInteractor(APanelMouseInteractor interactor) {
    interactor.detachPanelMouseInteractor(this);
    panelMouseInteractorMap.remove(interactor.getName());
    repaint();
  }

  public APanelMouseInteractor[] getPanelMouseInteractors() {
    return (APanelMouseInteractor[]) panelMouseInteractorMap.values().toArray(new APanelMouseInteractor[0]);
  }

  public void firePanelMouseEvent(int method, MouseEvent mouseEvent) {
    APanelMouseEvent evt = new APanelMouseEvent(this, mouseEvent, panelMouseInteractorMap);

    APanelMouseInteractor[] interactors = getPanelMouseInteractors();

    for (int i = 0; i < interactors.length; i++) {
      if (evt.isExcludedInteractor(interactors[i].getName())) {
        continue;
      }

      switch (method) {
        case APanelMouseInteractor.PANEL_MOUSE_CLICKED :
          interactors[i].panelMouseClicked(evt);
          break;

        case APanelMouseInteractor.PANEL_MOUSE_ENTERED :
          interactors[i].panelMouseEntered(evt);
          break;

        case APanelMouseInteractor.PANEL_MOUSE_EXITED :
          interactors[i].panelMouseExited(evt);
          break;

        case APanelMouseInteractor.PANEL_MOUSE_PRESSED :
          interactors[i].panelMousePressed(evt);
          break;

        case APanelMouseInteractor.PANEL_MOUSE_RELEASED :
          interactors[i].panelMouseReleased(evt);
          break;

        case APanelMouseInteractor.PANEL_MOUSE_DRAGGED :
          interactors[i].panelMouseDragged(evt);
          break;

        case APanelMouseInteractor.PANEL_MOUSE_MOVED :
          interactors[i].panelMouseMoved(evt);
          break;
      }

      evt.addExecutedInteractor(interactors[i]);
    }
  }

  // --------------------------------------------------------------------------------
  // ASwingPanel methods
  // --------------------------------------------------------------------------------

  // TODO: Make private, handle with property change events
  public void updatePanelSize() {
    int w = (int) (canvas.getW() * canvas.getZoom());
    int h = (int) (canvas.getH() * canvas.getZoom());

    setPreferredSize(new Dimension(w, h));

    setMinimumSize(new Dimension(w, h));
    setMaximumSize(new Dimension(w, h));

    Container parent = getParent();

    if (parent != null) {
      parent.doLayout();
    }
  }

  public Point canvasToView(Point point) {
    return null;
  }

  public Point viewToCanvas(Point point) {
    ARect rct = ARect.r(getBounds());
    rct.x = 0;
    rct.y = 0;

    return canvas.transViewToCanv(rct, point);
  }

  // --------------------------------------------------------------------------------

  public ACanvas getCanvas() {
    return canvas;
  }

  public void setCanvas(ACanvas canvas) {
    if (this.canvas != null) {
      this.canvas.delRepaintListener(this);
    }

    this.canvas = canvas;

    canvas.addRepaintListener(this);

    updatePanelSize();
  }

  // --------------------------------------------------------------------------------

  public double getZoom() {
    return canvas.getZoom();
  }

  public void setZoom(double zoom) {
    canvas.setZoom(zoom);
    updatePanelSize();
  }

  //  @Override
  //  public void setSize(int width, int height) {
  //    // TODO Auto-generated method stub
  //    super.setSize(width, height);
  //  }
  //  
  //  @Override
  //  public void setSize(Dimension d) {
  //    // TODO Auto-generated method stub
  //    super.setSize(d);
  //  }

}