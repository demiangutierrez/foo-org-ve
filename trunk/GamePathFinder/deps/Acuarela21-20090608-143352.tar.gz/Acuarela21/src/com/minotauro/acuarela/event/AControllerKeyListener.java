/*
 * Created on Dec 18, 2004
 */
package com.minotauro.acuarela.event;

import java.util.EventListener;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface AControllerKeyListener extends EventListener
{
	/**
	 *
	 *
	 * @param evt
	 */
	public void controllerKeyPressed(AControllerKeyEvent evt);

	/**
	 *
	 *
	 * @param evt
	 */
	public void controllerKeyReleased(AControllerKeyEvent evt);

	/**
	 *
	 *
	 * @param evt
	 */
	public void controllerKeyTyped(AControllerKeyEvent evt);
}