/*
 * Created on Sep 29, 2003
 */
package com.minotauro.acuarela.event;

import java.util.EventObject;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


import com.minotauro.acuarela.base.AController;
import com.minotauro.acuarela.util.ADist;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class AMotionEvent extends EventObject
{
	protected Map controllerMap = new HashMap();

	/**
	 *
	 *
	 * @param source
	 */
	public AMotionEvent(Object source)
	{
		super(source);
	}

	// --------------------------------------------------------------------------------
	// Object methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param controller
	 * @param dist
	 */
	public void addController(AController controller, ADist dist)
	{
		controllerMap.put(controller, dist);
	}

	/**
	 *
	 *
	 * @param controller
	 *
	 * @return
	 */
	public ADist getController(AController controller)
	{
		return (ADist) controllerMap.get(controller);
	}

	/**
	 *
	 *
	 * @param controller
	 */
	public void delController(AController controller)
	{
		controllerMap.remove(controller);
	}

	/**
	 *
	 *
	 * @return
	 */
	public Iterator controllerIterator()
	{
		return controllerMap.entrySet().iterator();
	}

	/**
	 *
	 *
	 * @return
	 */
	public AController[] toControllerArray()
	{
		return (AController[]) controllerMap.entrySet().toArray(new AController[0]);
	}
}
