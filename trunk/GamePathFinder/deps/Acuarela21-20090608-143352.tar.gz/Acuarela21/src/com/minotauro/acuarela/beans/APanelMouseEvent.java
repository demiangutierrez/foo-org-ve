/*
 * Created on Dec 19, 2004
 */
package com.minotauro.acuarela.beans;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.util.EventObject;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class APanelMouseEvent extends EventObject
{
	private MouseEvent mouseEvent;

	private Point canvasPoint;

	private LinkedHashMap panelMouseInteractorMap;

	private Map executedMap = new HashMap();

	private Map excludedMap = new HashMap();

	/**
	 *
	 *
	 * @param source
	 * @param mouseEvent
	 * @param panelMouseInteractorMap
	 */
	public APanelMouseEvent(Object source, MouseEvent mouseEvent, LinkedHashMap panelMouseInteractorMap)
	{
		super(source);

		this.mouseEvent = mouseEvent;
		this.panelMouseInteractorMap = panelMouseInteractorMap;

		ASwingPanel aSwingPanel = (ASwingPanel) source;
		canvasPoint = aSwingPanel.viewToCanvas(mouseEvent.getPoint());
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param interactor
	 */
	public void addExecutedInteractor(APanelMouseInteractor interactor)
	{
		executedMap.put(interactor.getName(), interactor);
	}

	/**
	 *
	 *
	 * @param name
	 * @return
	 */
	public boolean isExecutedInteractor(String name)
	{
		return executedMap.keySet().contains(name);
	}

	/**
	 *
	 *
	 * @param interactor
	 */
	public void addExcludedInteractor(APanelMouseInteractor interactor) throws IllegalArgumentException
	{
		if (isExecutedInteractor(interactor.getName()))
		{
			// If interactor was already executed
			throw new IllegalArgumentException();
		}

		excludedMap.put(interactor.getName(), interactor);
	}

	/**
	 *
	 *
	 * @param name
	 * @return
	 */
	public boolean isExcludedInteractor(String name)
	{
		return excludedMap.keySet().contains(name);
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public MouseEvent getMouseEvent()
	{
		return mouseEvent;
	}

	/**
	 *
	 *
	 * @param mouseEvent
	 */
	public void setMouseEvent(MouseEvent mouseEvent)
	{
		this.mouseEvent = mouseEvent;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Point getCanvasPoint()
	{
		return canvasPoint;
	}

	/**
	 *
	 *
	 * @param canvasPoint
	 */
	public void setCanvasPoint(Point canvasPoint)
	{
		this.canvasPoint = canvasPoint;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public LinkedHashMap getPanelMouseInteractorMap()
	{
		return panelMouseInteractorMap;
	}

	/**
	 *
	 *
	 * @param panelMouseInteractorMap
	 */
	public void setPanelMouseInteractorMap(LinkedHashMap panelMouseInteractorMap)
	{
		this.panelMouseInteractorMap = panelMouseInteractorMap;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Map getExecutedMap()
	{
		return executedMap;
	}

	/**
	 *
	 *
	 * @param executedMap
	 */
	public void setExecutedMap(Map executedMap)
	{
		this.executedMap = executedMap;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Map getExcludedMap()
	{
		return excludedMap;
	}

	/**
	 *
	 *
	 * @param excludedMap
	 */
	public void setExcludedMap(Map excludedMap)
	{
		this.excludedMap = excludedMap;
	}
}