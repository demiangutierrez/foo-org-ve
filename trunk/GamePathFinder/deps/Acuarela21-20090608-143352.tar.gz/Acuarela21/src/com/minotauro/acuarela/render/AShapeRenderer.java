/*
 * Created on Sep 28, 2003
 */
package com.minotauro.acuarela.render;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.beans.PropertyVetoException;

import com.minotauro.acuarela.base.AController;
import com.minotauro.acuarela.base.ARenderer;

/**
 * @author DMI: Demian Gutierrez
 */
public class AShapeRenderer extends ARenderer {

  public AShapeRenderer() {
    name = AShapeRenderer.class.getName();

    try {
      setObject(CLR_PEN_ENA, Color.BLACK);
      setObject(CLR_FLL_ENA, Color.WHITE);
      setObject(STR_PEN_ENA, new BasicStroke(1));

      setObject(CLR_PEN_DIS, Color.GRAY);
      setObject(CLR_FLL_DIS, Color.WHITE);
      setObject(STR_PEN_DIS, new BasicStroke(1));
    } catch (PropertyVetoException e) {
      e.printStackTrace(); // NEVER
    }
  }

  public void paint(Graphics2D g2d, AController object) {
    String disable = object.getDisable() ? "Dis" : "Ena";

    Color clrPen = (Color) getObject(CLR_PEN + disable);
    Color clrFll = (Color) getObject(CLR_FLL + disable);
    Stroke strPen = (Stroke) getObject(STR_PEN + disable);

    if (clrFll != null) {
      g2d.setColor(clrFll);
      g2d.fill(object.getShape());
    }

    if (clrPen != null) {
      g2d.setColor(clrPen);
      g2d.setStroke(strPen);
      g2d.draw(object.getShape());
    }

    //    g2d.setFont(new Font("Dialog", Font.PLAIN, 10));
    //    g2d.drawString(object.getBounds().x + ";" + object.getBounds().y + ";" + object.getName(),
    //        object.getBounds().x + 5, object.getBounds().y + 15);
  }
}