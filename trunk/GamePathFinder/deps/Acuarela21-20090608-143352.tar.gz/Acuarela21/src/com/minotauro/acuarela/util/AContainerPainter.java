/*
 * Created on Dec 29, 2004
 */
package com.minotauro.acuarela.util;

import java.awt.Component;
import java.awt.Container;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class AContainerPainter
{
	/**
	 *
	 */
	public AContainerPainter()
	{
		// Empty
	}

	/**
	 *
	 *
	 * @param container
	 */
	public void doLayout(Container container)
	{
		// Layout this
		container.doLayout();

		// Layout children
		for (int i = container.getComponentCount() - 1; i >= 0; i--)
		{
			Component component = container.getComponent(i);

			if (component instanceof Container)
			{
				doLayout((Container) component);
			}
		}
	}

	/**
	 *
	 *
	 * @param g2d
	 * @param container
	 */
	public void paintContainer(Graphics2D g2d, Container container)
	{
		AffineTransform prevTransform = g2d.getTransform();

		// Translate relative to the parent
		AffineTransform currTransform = g2d.getTransform();
		currTransform.translate(container.getX(), container.getY());
		g2d.setTransform(currTransform);

		// Paint the container first
		container.paint(g2d);

		// For each child
		for (int i = container.getComponentCount() - 1; i >= 0; i--)
		{
			Component component = container.getComponent(i);

			if (component instanceof Container)
			{
				paintContainer(g2d, (Container) component);
			}
		}

		g2d.setTransform(prevTransform);
	}
}