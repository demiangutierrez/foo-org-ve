/**
 * @author DMI: Demian Gutierrez
 */
package com.minotauro.acuarela.test.nogui.d;

import com.minotauro.acuarela.test.nogui.BaseSimpleTest;

/*
 * Created on Aug 25, 2007
 */
public class TestD7 extends BaseSimpleTest {

  // Canvas W < paint W (cH > pH) (y + 10)
  public void test() throws Exception {
    pY = 10;
    cW = 600;
    cH = 600;
    despX = -cW / 2;
    despY = -cH / 2;
    pW = 800;
    pH = 590;
    execute();
    assertTrue(compare());
  }
}
