/**
 * @author DMI: Demian Gutierrez
 */
package com.minotauro.acuarela.test.nogui.e;

import com.minotauro.acuarela.test.nogui.BaseSimpleTest;

/*
 * Created on Aug 25, 2007
 */
public class TestE6 extends BaseSimpleTest {

  // Canvas W/H > to paint W/H
  public void test() throws Exception {
    cW = 600;
    cH = 600;
    despX = cW / 2;
    despY = cH / 2;
    pW = 590;
    pH = 590;
    execute();
    assertTrue(compare());
  }
}
