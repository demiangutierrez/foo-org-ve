/*
 * Created on Jul 18, 2004
 */
package com.minotauro.acuarela.beans;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class ASwtPanel {//extends Composite {
  //	private ACanvas canvas;
  //
  //	/**
  //	 *
  //	 *
  //	 * @param canvas
  //	 * @param parent
  //	 * @param style
  //	 */
  //	public ASwtPanel(ACanvas canvas, Composite parent, int style)
  //	{
  //		super(parent, style);
  //
  //		this.canvas = canvas;
  //
  //		addPaintListener(new PaintListener()
  //		{
  //			public void paintControl(PaintEvent evt)
  //			{
  //				paint(evt.gc);
  //			}
  //		});
  //	}
  //
  //	/**
  //	 *
  //	 *
  //	 * @param gc
  //	 */
  //	protected void paint(GC gc)
  //	{
  //		ARect r = new ARect();
  //		BufferedImage bimg;
  //
  //
  ////		if (parent instanceof JViewport)
  ////		{
  ////			JViewport viewport = (JViewport) parent;
  ////
  ////			ARect rvw = ARect.r(viewport.getViewRect());
  ////			ARect rvs = ARect.r(viewport.getVisibleRect());
  ////			r.x = rvw.x;
  ////			r.y = rvw.y;
  ////			r.setW(rvs.width);
  ////			r.setH(rvs.height);
  ////
  ////			bimg = canvas.paint(r);
  ////		}
  ////		else
  ////		{
  //			r.x = 0;
  //			r.y = 0;
  //			r.setW(getSize().x);
  //			r.setH(getSize().y);
  //
  ////			bimg = canvas.paint(r);
  ////		}
  //			
  //
  //
  ////			gc.drawImage(bimg, 0, 0);
  //			
  ////		Graphics2D g2d = (Graphics2D) g;
  //
  ////		g2d.drawImage(bimg, r.x, r.y, null);
  //	}
}