package com.minotauro.acuarela.test.nogui.g;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.apache.commons.lang.ClassUtils;

public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite(ClassUtils.getPackageName(AllTests.class));

    //$JUnit-BEGIN$
    suite.addTestSuite(TestG0.class);
    suite.addTestSuite(TestG1.class);
    suite.addTestSuite(TestG2.class);
    suite.addTestSuite(TestG3.class);
    suite.addTestSuite(TestG4.class);
    suite.addTestSuite(TestG5.class);
    suite.addTestSuite(TestG6.class);
    suite.addTestSuite(TestG7.class);
    suite.addTestSuite(TestG8.class);
    suite.addTestSuite(TestG9.class);
    //$JUnit-END$

    return suite;
  }
}
