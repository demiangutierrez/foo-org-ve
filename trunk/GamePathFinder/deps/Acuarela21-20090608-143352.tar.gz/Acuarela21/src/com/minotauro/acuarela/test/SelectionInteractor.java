/*
 * Created on Dec 19, 2004
 */
package com.minotauro.acuarela.test;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseEvent;


import com.minotauro.acuarela.base.ACanvas;
import com.minotauro.acuarela.base.AController;
import com.minotauro.acuarela.beans.APanelMouseEvent;
import com.minotauro.acuarela.beans.APanelMouseInteractor;
import com.minotauro.acuarela.beans.ASwingPanel;
import com.minotauro.acuarela.event.APaintEvent;
import com.minotauro.acuarela.event.APaintListener;
import com.minotauro.acuarela.util.ARect;
import com.minotauro.acuarela.util.ATracer;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class SelectionInteractor extends APanelMouseInteractor implements APaintListener {
  protected Point prevPt;

  protected Point begPt;

  protected Point endPt;

  protected boolean dragging;
  protected boolean voidDrag;

  /**
   *
   */
  public SelectionInteractor() {
    super(SelectionInteractor.class.getName());
  }

  // --------------------------------------------------------------------------------
  // APanelMouseInteractor methods
  // --------------------------------------------------------------------------------

  @Override
  public void attachPanelMouseInteractor(ASwingPanel swingPanel) {
    // Empty
  }

  @Override
  public void detachPanelMouseInteractor(ASwingPanel swingPanel) {
    // Empty
  }

  /**
   *
   */
  public void panelMouseClicked(APanelMouseEvent evt) {
    //    ATracer.trace("BEG");
    //
    //    ASwingPanel swingPanel = (ASwingPanel) evt.getSource();
    //    ACanvas canvas = swingPanel.getCanvas();
    //
    //    MouseEvent mouseEvent = evt.getMouseEvent();
    //    prevPt = swingPanel.viewToCanvas(mouseEvent.getPoint());
    //
    //    AController controller = canvas.getController(prevPt.x, prevPt.y);
    //
    //    if (controller == null) {
    //      return;
    //    }
    //
    //    if ((mouseEvent.getModifiersEx() & MouseEvent.CTRL_DOWN_MASK) != MouseEvent.CTRL_DOWN_MASK) {
    //      System.err.println("3");
    //      canvas.clearSelectedControllers();
    //    }
    //
    //    canvas.bringToFront(controller);
    //
    //    if (canvas.isSelected(controller)) {
    //      System.err.println("Del 3");
    //      canvas.delSelectedController(controller);
    //    } else {
    //      System.err.println("Added 3");
    //      canvas.addSelectedController(controller);
    //    }
    //
    //    swingPanel.repaint();
  }

  /**
   *
   */
  public void panelMouseEntered(APanelMouseEvent evt) {
    // Empty
  }

  /**
   *
   */
  public void panelMouseExited(APanelMouseEvent evt) {
    // Empty
  }

  /**
   *
   */
  public void panelMousePressed(APanelMouseEvent evt) {
    voidDrag = false;

    ASwingPanel aSwingPanel = (ASwingPanel) evt.getSource();
    ACanvas aCanvas = aSwingPanel.getCanvas();

    MouseEvent mouseEvent = evt.getMouseEvent();
    begPt = aSwingPanel.viewToCanvas(mouseEvent.getPoint());

    AController controller = aCanvas.getController(begPt.x, begPt.y);

    if (controller == null) {
      if ((mouseEvent.getModifiersEx() & MouseEvent.CTRL_DOWN_MASK) != MouseEvent.CTRL_DOWN_MASK) {
        aCanvas.clearSelectedControllers();
      }

      dragging = true;

      aCanvas.addPaintListener(this);

      endPt = begPt;

      aSwingPanel.repaint();
    } else {

      if (!aCanvas.isSelected(controller)) {
        if ((mouseEvent.getModifiersEx() & MouseEvent.CTRL_DOWN_MASK) != MouseEvent.CTRL_DOWN_MASK) {
          aCanvas.clearSelectedControllers();
        }
      }

      if (aCanvas.isSelected(controller)) {
        if ((mouseEvent.getModifiersEx() & MouseEvent.CTRL_DOWN_MASK) == MouseEvent.CTRL_DOWN_MASK) {
          aCanvas.delSelectedController(controller);

          voidDrag = true;
          // TODO: Ugly hack
          MoveInteractor moveInteractor = (MoveInteractor) evt.getPanelMouseInteractorMap().get(
              MoveInteractor.class.getName());
          moveInteractor.draggedController = null;
        }
      } else {
        aCanvas.addSelectedController(controller);
      }
      aCanvas.bringToFront(controller);
      aSwingPanel.repaint();
    }
  }

  /**
   *
   */
  public void panelMouseReleased(APanelMouseEvent evt) {
    if (voidDrag) {
      return;
    }

    if (endPt == null) {
      return; // Do nothing, not draged
    }

    ATracer.trace("BEG");

    ASwingPanel aSwingPanel = (ASwingPanel) evt.getSource();
    ACanvas aCanvas = aSwingPanel.getCanvas();

    dragging = false;

    aCanvas.delPaintListener(this);

    int x = Math.min(begPt.x, endPt.x);
    int y = Math.min(begPt.y, endPt.y);
    int w = Math.abs(begPt.x - endPt.x);
    int h = Math.abs(begPt.y - endPt.y);

    aCanvas.addSelectedRectangle(new ARect(x, y, w, h), true);
    aSwingPanel.repaint();
  }

  /**
   *
   */
  public void panelMouseDragged(APanelMouseEvent evt) {
    ATracer.trace("BEG");

    ASwingPanel aSwingPanel = (ASwingPanel) evt.getSource();
    //ACanvas aCanvas = aSwingPanel.getCanvas();

    MouseEvent mouseEvent = evt.getMouseEvent();
    endPt = aSwingPanel.viewToCanvas(mouseEvent.getPoint());

    aSwingPanel.repaint();
  }

  /**
   *
   */
  public void panelMouseMoved(APanelMouseEvent evt) {
    // Empty
  }

  // --------------------------------------------------------------------------------
  // APanelMouseInteractor methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public void prePaint(APaintEvent evt) {
    // Empty
  }

  /**
   *
   */
  public void posPaint(APaintEvent evt) {
    Graphics2D g2d = evt.getGraphics2D();

    int x = Math.min(begPt.x, endPt.x);
    int y = Math.min(begPt.y, endPt.y);
    int w = Math.abs(begPt.x - endPt.x);
    int h = Math.abs(begPt.y - endPt.y);

    g2d.setColor(Color.DARK_GRAY);
    g2d.setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1, new float[]{10, 5}, 1));
    g2d.drawRect(x, y, w, h);
  }
}