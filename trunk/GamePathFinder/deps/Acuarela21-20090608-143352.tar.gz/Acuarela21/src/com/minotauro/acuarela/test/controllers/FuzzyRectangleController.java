/*
 * Created on Dec 31, 2004
 */
package com.minotauro.acuarela.test.controllers;


import com.minotauro.acuarela.base.AController;
import com.minotauro.acuarela.base.ACtrlPoint;
import com.minotauro.acuarela.controllers.ARectangle;
import com.minotauro.acuarela.event.AControllerMouseAdapter;
import com.minotauro.acuarela.event.AControllerMouseEvent;
import com.minotauro.acuarela.event.ARepaintEvent;
import com.minotauro.acuarela.util.ATracer;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class FuzzyRectangleController extends ARectangle
{
	private AController pressed;
	private boolean resizing;

	/**
	 *
	 *
	 * @param ctrlBeg
	 * @param ctrlEnd
	 */
	public FuzzyRectangleController(ACtrlPoint ctrlBeg, ACtrlPoint ctrlEnd)
	{
		super(ctrlBeg, ctrlEnd);

		AControllerMouseAdapter aControllerMouseAdapter = new AControllerMouseAdapter()
		{
			public void controllerMousePressed(AControllerMouseEvent evt)
			{
				if (evt.getController().getBounds().contains(evt.getCanvasPoint()))
				{
					ATracer.trace("pressed = evt.getController()");
					pressed = evt.getController();
					evt.setConsumed(true);
				}
			}

			public void controllerMouseReleased(AControllerMouseEvent evt)
			{
				if (evt.getController().getBounds().contains(evt.getCanvasPoint()))
				{
					ATracer.trace("pressed = null");
					pressed = null;
					resizing = false;
					evt.setConsumed(true);

					fireRepaintEvent(new ARepaintEvent(this));
				}
			}

			public void controllerMouseDragged(AControllerMouseEvent evt)
			{
				// The order of the statements was carefully selected to improve performance
				if (pressed == evt.getController())
				{
					ATracer.trace("resizing = true");
					evt.setConsumed(true);

					if (!resizing)
					{
						resizing = true;

						fireRepaintEvent(new ARepaintEvent(this));
					}
				}
			}
		};

		addControllerMouseListener(aControllerMouseAdapter);

		ctrlBeg.addControllerMouseListener(aControllerMouseAdapter);
		ctrlEnd.addControllerMouseListener(aControllerMouseAdapter);

		ctrlBegAux.addControllerMouseListener(aControllerMouseAdapter);
		ctrlEndAux.addControllerMouseListener(aControllerMouseAdapter);
	}

	/**
	 *
	 *
	 * @return
	 */
	public boolean isResizing()
	{
		return resizing;
	}
}