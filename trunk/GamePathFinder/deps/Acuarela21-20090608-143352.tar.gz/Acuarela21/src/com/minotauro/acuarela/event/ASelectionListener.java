/*
 * Created on Nov 23, 2003
 */
package com.minotauro.acuarela.event;

import java.util.EventListener;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface ASelectionListener extends EventListener
{
	/**
	 *
	 *
	 * @param evt
	 */
	public void selectionGained(ASelectionEvent evt);

	/**
	 *
	 *
	 * @param evt
	 */
	public void selectionLost(ASelectionEvent evt);
}
