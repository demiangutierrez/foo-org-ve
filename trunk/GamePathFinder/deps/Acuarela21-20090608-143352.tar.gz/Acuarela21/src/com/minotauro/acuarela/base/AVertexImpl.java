/*
 * Created on Jul 18, 2004
 */
package com.minotauro.acuarela.base;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public abstract class AVertexImpl extends AControllerImpl implements AVertex
{
	/**
	 *
	 */
	public AVertexImpl()
	{
		// Empty
	}
}
