/*
 * Created on Dec 19, 2004
 */
package com.minotauro.acuarela.test;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.util.Iterator;

import javax.swing.JViewport;

import com.minotauro.acuarela.base.ACanvas;
import com.minotauro.acuarela.base.AController;
import com.minotauro.acuarela.beans.APanelMouseEvent;
import com.minotauro.acuarela.beans.APanelMouseInteractor;
import com.minotauro.acuarela.beans.ASwingPanel;
import com.minotauro.acuarela.util.ARect;

/**
 * @author DMI: Demian Gutierrez
 */
public class MoveInteractor extends APanelMouseInteractor {

  protected AController draggedController;

  protected Point prevPt;
  protected Point currPt;

  // --------------------------------------------------------------------------------

  public MoveInteractor() {
    super(MoveInteractor.class.getName());
  }

  // --------------------------------------------------------------------------------
  // APanelMouseInteractor methods
  // --------------------------------------------------------------------------------

  @Override
  public void attachPanelMouseInteractor(ASwingPanel swingPanel) {
    // Empty
  }

  @Override
  public void detachPanelMouseInteractor(ASwingPanel swingPanel) {
    // Empty
  }

  @Override
  public void panelMouseClicked(APanelMouseEvent evt) {
    // Empty
  }

  @Override
  public void panelMouseEntered(APanelMouseEvent evt) {
    // Empty
  }

  @Override
  public void panelMouseExited(APanelMouseEvent evt) {
    // Empty
  }

  @Override
  public void panelMousePressed(APanelMouseEvent evt) {
    ASwingPanel swingPanel = (ASwingPanel) evt.getSource();
    ACanvas canvas = swingPanel.getCanvas();

    MouseEvent mouseEvent = evt.getMouseEvent();
    prevPt = swingPanel.viewToCanvas(mouseEvent.getPoint());

    AController controller = canvas.getController(prevPt.x, prevPt.y);

    if (controller != null && controller.getMovable()) {
      draggedController = controller;
    }

    // ----------------------------------------
    // TODO: Create move command here
    // ----------------------------------------
  }

  @Override
  public void panelMouseReleased(APanelMouseEvent evt) {
    if (draggedController != null && currPt != null) {
      doPanelMouseReleased(evt);
    }

    draggedController = null;
    currPt = null;
  }

  @Override
  public void panelMouseDragged(APanelMouseEvent evt) {
    if (draggedController == null) {
      return;
    }

    ASwingPanel swingPanel = (ASwingPanel) evt.getSource();
    ACanvas canvas = swingPanel.getCanvas();

    MouseEvent mouseEvent = evt.getMouseEvent();
    currPt = swingPanel.viewToCanvas(mouseEvent.getPoint());

    int dx = currPt.x - prevPt.x;
    int dy = currPt.y - prevPt.y;

    if (canvas.isSelected(draggedController)) {
      Iterator<AController> itt = canvas.selectedIterator();

      while (itt.hasNext()) {
        AController controller = (AController) itt.next();

        if (!controller.getMovable()) {
          continue;
        }

        controller.move(dx, dy);
      }
    } else {
      draggedController.move(dx, dy);
    }

    swingPanel.repaint();

    prevPt = currPt;
  }

  @Override
  public void panelMouseMoved(APanelMouseEvent evt) {
    // Empty
  }

  // --------------------------------------------------------------------------------
  // Misc
  // --------------------------------------------------------------------------------

  protected Point calculateGridSnap(ACanvas canvas, ARect rbn) {
    Point ret = new Point();

    // ----------------------------------------
    // Calculate X Snap
    // ----------------------------------------

    int gridW = canvas.getGridW();
    int gridWDiff = rbn.x % gridW;

    if (gridWDiff != 0) {
      if (gridWDiff < (gridW - gridWDiff)) {
        ret.x = -gridWDiff; // <--
      } else {
        ret.x = gridW - gridWDiff; // -->
      }
    }

    // ----------------------------------------
    // Calculate Y Snap
    // ----------------------------------------

    int gridH = canvas.getGridH();
    int gridHDiff = rbn.y % gridH;

    if (gridHDiff != 0) {
      if (gridHDiff < (gridH - gridHDiff)) {
        ret.y = -gridHDiff; // <--
      } else {
        ret.y = gridH - gridHDiff; // -->
      }
    }

    // ----------------------------------------

    return ret;
  }

  protected void snapToGrid(ACanvas canvas) {
    if (canvas.toSelectedArray().length > 1) {

      // ----------------------------------------
      // Snap multiple selection
      // ----------------------------------------

      ARect rbn = null;

      Iterator<AController> itt = canvas.selectedIterator();

      while (itt.hasNext()) {
        AController controller = (AController) itt.next();

        if (rbn == null) {
          rbn = controller.getBounds();
        } else {
          rbn.add(controller.getBounds());
        }
      }

      Point gridSnap = calculateGridSnap(canvas, rbn);

      itt = canvas.selectedIterator();

      while (itt.hasNext()) {
        AController controller = (AController) itt.next();
        controller.move(gridSnap.x, gridSnap.y);
      }
    } else {

      // ----------------------------------------
      // Snap single selection
      // ----------------------------------------

      ARect rbn = ARect.r(draggedController.getBounds());
      Point gridSnap = calculateGridSnap(canvas, rbn);
      draggedController.move(gridSnap.x, gridSnap.y);
    }
  }

  public void doPanelMouseReleased(APanelMouseEvent evt) {

    // ----------------------------------------
    // TODO: Drop move command here
    // ----------------------------------------

    ASwingPanel swingPanel = (ASwingPanel) evt.getSource();
    ACanvas canvas = swingPanel.getCanvas();

    // ----------------------------------------
    // Snap to grid
    // ----------------------------------------

    snapToGrid(canvas);

    // ----------------------------------------
    // Canvas(minX,minY) vs View (0,0) diff
    // ----------------------------------------

    canvas.updateXYSortedSet(draggedController);

    JViewport viewport = (JViewport) swingPanel.getParent();
    ARect rvw = ARect.r(viewport.getViewRect());

    Point cpt = swingPanel.viewToCanvas(new Point(rvw.x, 0));
    ARect rct;

    // ----------------------------------------
    // X
    // ----------------------------------------

    rct = canvas.getMinXController().getBounds();

    int preCanvasDiffX = cpt.x - canvas.getMinX();
    int newPosX = 0;

    if (rct.x < canvas.getMinX()) {
      canvas.setMinX(rct.x);
      swingPanel.updatePanelSize();

      int curCanvasDiffX = cpt.x - canvas.getMinX();

      if (preCanvasDiffX != 0) {
        newPosX = curCanvasDiffX * viewport.getViewPosition().x / preCanvasDiffX;
      } else {
        newPosX = (int) (curCanvasDiffX * canvas.getZoom());
      }

      viewport.setViewPosition(new Point(newPosX, viewport.getViewPosition().y));
    }

    rct = canvas.getMaxXController().getBounds();

    if (rct.maxX() > canvas.getMaxX()) {
      canvas.setMaxX(rct.maxX());
      swingPanel.updatePanelSize();
    }

    // ----------------------------------------
    // Y
    // ----------------------------------------

    rct = canvas.getMinYController().getBounds();

    int preCanvasDiffY = cpt.y - canvas.getMinY();
    int newPosY = 0;

    if (rct.y < canvas.getMinY()) {
      canvas.setMinY(rct.y);
      swingPanel.updatePanelSize();

      int curCanvasDiffY = cpt.y - canvas.getMinY();

      if (preCanvasDiffY != 0) {
        newPosY = curCanvasDiffY * viewport.getViewPosition().y / preCanvasDiffY;
      } else {
        newPosY = (int) (curCanvasDiffY * canvas.getZoom());
      }

      viewport.setViewPosition(new Point(viewport.getViewPosition().x, newPosY));
    }

    rct = canvas.getMaxYController().getBounds();

    if (rct.maxY() > canvas.getMaxY()) {
      canvas.setMaxY(rct.maxY());
      swingPanel.updatePanelSize();
    }

    // ----------------------------------------

    evt.addExcludedInteractor((APanelMouseInteractor) //
        evt.getPanelMouseInteractorMap().get(SelectionInteractor.class.getName()));

    swingPanel.repaint();
  }
}