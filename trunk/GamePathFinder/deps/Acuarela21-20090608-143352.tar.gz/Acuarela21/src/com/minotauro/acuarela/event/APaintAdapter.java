/*
 * Created on Jul 18, 2004
 */
package com.minotauro.acuarela.event;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class APaintAdapter implements APaintListener
{
	/**
	 *
	 */
	public APaintAdapter()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// APaintListener
	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public void prePaint(APaintEvent evt)
	{
		// Empty
	}

	/**
	 *
	 */
	public void posPaint(APaintEvent evt)
	{
		// Empty
	}
}
