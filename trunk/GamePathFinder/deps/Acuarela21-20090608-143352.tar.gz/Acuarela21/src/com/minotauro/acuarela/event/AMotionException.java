/*
 * Created on Jun 6, 2004
 */
package com.minotauro.acuarela.event;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class AMotionException extends Exception
{
	/**
	 *
	 */
	public AMotionException()
	{
		super();
	}

	/**
	 *
	 *
	 * @param message
	 */
	public AMotionException(String message)
	{
		super(message);
	}

	/**
	 *
	 *
	 * @param cause
	 */
	public AMotionException(Throwable cause)
	{
		super(cause);
	}

	/**
	 *
	 *
	 * @param message
	 * @param cause
	 */
	public AMotionException(String message, Throwable cause)
	{
		super(message, cause);
	}
}
