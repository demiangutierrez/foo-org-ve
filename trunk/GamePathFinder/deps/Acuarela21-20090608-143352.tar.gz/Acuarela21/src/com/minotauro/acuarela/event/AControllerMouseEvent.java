/*
 * Created on Dec 18, 2004
 */
package com.minotauro.acuarela.event;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.util.EventObject;


import com.minotauro.acuarela.base.AController;
import com.minotauro.acuarela.beans.ASwingPanel;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class AControllerMouseEvent extends EventObject
{
	private MouseEvent mouseEvent;

	private Point canvasPoint;

	// Beware, controller may be null and may change when the event is forwarded
	// to other controller from a parent controller. Always is guaranteed that
	// when the event is passed to a listener belonging to a controller, the controller
	// instance will match the controller to which the event is being passed to.
	private AController controller;

	// If the event is consumed then will not be forwarded to any other controller
	private boolean consumed;

	/**
	 *
	 *
	 * @param source
	 */
	public AControllerMouseEvent(Object source, MouseEvent mouseEvent)
	{
		super(source);

		this.mouseEvent = mouseEvent;

		// Source is always an ASwingPanel instance
		ASwingPanel aSwingPanel = (ASwingPanel) source;

		canvasPoint = aSwingPanel.viewToCanvas(mouseEvent.getPoint());
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public MouseEvent getMouseEvent()
	{
		return mouseEvent;
	}

	/**
	 *
	 *
	 * @param mouseEvent
	 */
	public void setMouseEvent(MouseEvent mouseEvent)
	{
		this.mouseEvent = mouseEvent;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public Point getCanvasPoint()
	{
		return canvasPoint;
	}

	/**
	 *
	 *
	 * @param canvasPoint
	 */
	public void setCanvasPoint(Point canvasPoint)
	{
		this.canvasPoint = canvasPoint;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public AController getController()
	{
		return controller;
	}

	/**
	 *
	 *
	 * @param controller
	 */
	public void setController(AController controller)
	{
		this.controller = controller;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public boolean isConsumed()
	{
		return consumed;
	}

	/**
	 *
	 *
	 * @param consumed
	 */
	public void setConsumed(boolean consumed)
	{
		this.consumed = consumed;
	}
}