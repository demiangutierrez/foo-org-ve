/*
 * Created on Sep 29, 2003
 */
package com.minotauro.acuarela.event;

import java.util.EventListener;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface AMotionListener extends EventListener
{
	/**
	 *
	 *
	 * @param evt
	 *
	 * @throws AMotionException
	 */
	public void controllerMoved(AMotionEvent evt) throws AMotionException;
}
