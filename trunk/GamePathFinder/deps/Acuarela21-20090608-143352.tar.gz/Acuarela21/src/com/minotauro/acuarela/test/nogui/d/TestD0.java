/**
 * @author DMI: Demian Gutierrez
 */
package com.minotauro.acuarela.test.nogui.d;

import com.minotauro.acuarela.test.nogui.BaseSimpleTest;

/*
 * Created on Aug 25, 2007
 */
public class TestD0 extends BaseSimpleTest {

  // Canvas W/H = paint W/H
  public void test() throws Exception {
    cW = 600;
    cH = 600;
    despX = -cW / 2;
    despY = -cH / 2;
    pW = 600;
    pH = 600;
    execute();
    assertTrue(compare());
  }
}
