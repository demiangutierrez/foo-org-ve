/**
 * @author DMI: Demian Gutierrez
 */
package com.minotauro.acuarela.test.nogui.g;

import com.minotauro.acuarela.test.nogui.BaseSimpleTest;

/*
 * Created on Aug 25, 2007
 */
public class TestG3 extends BaseSimpleTest {

  // Canvas H < paint H (cW = pW)
  public void test() throws Exception {
    cW = 600;
    cH = 600;
    despX = cW / 2;
    despY = cH / 2;
    pW = 300;
    pH = 800;
    zoom = 0.5;

    tpX1 = 100; // View/Red
    // tpY1 = 100; // View/Red

    execute();
    assertTrue(compare());
  }
}
