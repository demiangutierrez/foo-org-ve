/*
 * Created on Jul 18, 2004
 */
package com.minotauro.acuarela.event;

import java.awt.Graphics2D;
import java.util.EventObject;

import com.minotauro.acuarela.util.ARect;

/**
 * @author Demian Gutierrez
 */
public class APaintEvent extends EventObject {

  private Graphics2D graphics2D;

  private ARect viewRect;

  // --------------------------------------------------------------------------------

  public APaintEvent(Object source, Graphics2D graphics2D, ARect viewRect) {
    super(source);

    this.graphics2D = graphics2D;
    this.viewRect = viewRect;
  }

  // --------------------------------------------------------------------------------

  public Graphics2D getGraphics2D() {
    return graphics2D;
  }

  public ARect getViewRect() {
    return viewRect;
  }
}