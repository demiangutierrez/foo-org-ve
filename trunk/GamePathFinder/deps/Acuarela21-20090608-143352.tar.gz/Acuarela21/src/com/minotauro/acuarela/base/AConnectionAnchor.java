/*
 * Created on Jan 2, 2005
 */
package com.minotauro.acuarela.base;

import java.awt.Point;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface AConnectionAnchor extends AController
{
	/**
	 *
	 *
	 * @param point
	 * @return
	 */
	public Point getConnectionPoint(Point point);
}