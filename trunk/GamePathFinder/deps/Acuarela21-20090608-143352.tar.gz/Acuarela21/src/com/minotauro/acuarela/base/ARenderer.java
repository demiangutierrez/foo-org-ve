/*
 * Created on Oct 4, 2003
 */
package com.minotauro.acuarela.base;

import java.awt.Graphics2D;

import org.cyrano.xclass.base.XDataObject;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public abstract class ARenderer extends XDataObject
{
  public static final String CLR_PEN = "clrPen";
  public static final String CLR_FLL = "clrFll";
  public static final String STR_PEN = "strPen";

  public static final String CLR_PEN_ENA = CLR_PEN + "Ena";
  public static final String CLR_FLL_ENA = CLR_FLL + "Ena";
  public static final String STR_PEN_ENA = STR_PEN + "Ena";

  public static final String CLR_PEN_DIS = CLR_PEN + "Dis";
  public static final String CLR_FLL_DIS = CLR_FLL + "Dis";
  public static final String STR_PEN_DIS = STR_PEN + "Dis";

	protected String name;

	protected boolean enabled = true;

	/**
	 *
	 */
	public ARenderer()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param g2d
	 * @param controller
	 */
	public void update(Graphics2D g2d, AController controller)
	{
		if (enabled && controller.getVisible())
		{
			paint(g2d, controller);
		}
	}

	/**
	 *
	 *
	 * @param g2d
	 * @param controller
	 */
	public abstract void paint(Graphics2D g2d, AController controller);

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public String getName()
	{
		return name;
	}

	/**
	 *
	 *
	 * @param name
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public boolean getEnabled()
	{
		return enabled;
	}

	/**
	 *
	 *
	 * @param enabled
	 */
	public void setEnabled(boolean enabled)
	{
		this.enabled = enabled;
	}
}
