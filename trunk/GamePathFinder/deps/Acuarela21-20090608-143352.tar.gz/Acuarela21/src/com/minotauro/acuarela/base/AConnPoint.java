/*
 * Created on May 28, 2007
 */
package com.minotauro.acuarela.base;

import java.awt.Point;

/**
 * @author DMI: Demian Gutierrez
 */
public interface AConnPoint {

  public Point getPoint(Point dst);
}
