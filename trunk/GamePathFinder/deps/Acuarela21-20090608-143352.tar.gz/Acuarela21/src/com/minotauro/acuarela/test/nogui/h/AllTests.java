package com.minotauro.acuarela.test.nogui.h;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.apache.commons.lang.ClassUtils;

public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite(ClassUtils.getPackageName(AllTests.class));

    //$JUnit-BEGIN$
    suite.addTestSuite(TestH0.class);
    suite.addTestSuite(TestH1.class);
    suite.addTestSuite(TestH2.class);
    suite.addTestSuite(TestH3.class);
    suite.addTestSuite(TestH4.class);
    suite.addTestSuite(TestH5.class);
    suite.addTestSuite(TestH6.class);
    suite.addTestSuite(TestH7.class);
    suite.addTestSuite(TestH8.class);
    suite.addTestSuite(TestH9.class);
    //$JUnit-END$

    return suite;
  }
}
