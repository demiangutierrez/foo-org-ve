package com.minotauro.acuarela.test.nogui.d;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.apache.commons.lang.ClassUtils;

public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite(ClassUtils.getPackageName(AllTests.class));

    //$JUnit-BEGIN$
    suite.addTestSuite(TestD0.class);
    suite.addTestSuite(TestD1.class);
    suite.addTestSuite(TestD2.class);
    suite.addTestSuite(TestD3.class);
    suite.addTestSuite(TestD4.class);
    suite.addTestSuite(TestD5.class);
    suite.addTestSuite(TestD6.class);
    suite.addTestSuite(TestD7.class);
    suite.addTestSuite(TestD8.class);
    suite.addTestSuite(TestD9.class);
    //$JUnit-END$

    return suite;
  }
}
