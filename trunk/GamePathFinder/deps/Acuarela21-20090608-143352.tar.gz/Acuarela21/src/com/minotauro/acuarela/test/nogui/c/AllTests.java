package com.minotauro.acuarela.test.nogui.c;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.apache.commons.lang.ClassUtils;

public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite(ClassUtils.getPackageName(AllTests.class));

    //$JUnit-BEGIN$
    suite.addTestSuite(TestC0.class);
    suite.addTestSuite(TestC1.class);
    suite.addTestSuite(TestC2.class);
    suite.addTestSuite(TestC3.class);
    suite.addTestSuite(TestC4.class);
    suite.addTestSuite(TestC5.class);
    suite.addTestSuite(TestC6.class);
    suite.addTestSuite(TestC7.class);
    suite.addTestSuite(TestC8.class);
    suite.addTestSuite(TestC9.class);
    //$JUnit-END$

    return suite;
  }
}
