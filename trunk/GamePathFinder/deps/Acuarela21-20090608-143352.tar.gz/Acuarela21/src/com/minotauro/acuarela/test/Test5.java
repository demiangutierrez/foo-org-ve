/*
 * Created on Aug 14, 2004
 */
package com.minotauro.acuarela.test;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class Test5 {

  //private ASwingPanel swingPanel;

  private void doLayout(Container container) {
    // Layout this
    container.doLayout();

    // Layout children
    for (int i = container.getComponentCount() - 1; i >= 0; i--) {
      Component component = container.getComponent(i);

      if (component instanceof Container) {
        doLayout((Container) component);
      }
    }
  }

  private void paintContainer(Graphics2D g2d, Container container) {
    AffineTransform prevTransform = g2d.getTransform();

    // Translate relative to the parent
    AffineTransform currTransform = g2d.getTransform();
    currTransform.translate(container.getX(), container.getY());
    g2d.setTransform(currTransform);

    // Paint the container first
    container.paint(g2d);

    // For each child
    for (int i = container.getComponentCount() - 1; i >= 0; i--) {
      Component component = container.getComponent(i);

      if (component instanceof Container) {
        paintContainer(g2d, (Container) component);
      }
    }

    g2d.setTransform(prevTransform);
  }

  /**
   *
   */
  public Test5() throws Exception {
    JPanel panel = initPanel();

    panel.setSize(300, 300);

    BufferedImage bimg = new BufferedImage(panel.getSize().width, panel.getSize().height, BufferedImage.TYPE_INT_RGB);

    Graphics2D g2d = (Graphics2D) bimg.getGraphics();

    doLayout(panel);
    paintContainer(g2d, panel);

    g2d.dispose();

    ImageIO.write(bimg, "png", new File("panel.png"));
  }

  /**
   * @return
   */
  private JPanel initPanel() {
    JPanel ret = new JPanel();
    ret.setBackground(Color.WHITE);

    ret.setLayout(new GridBagLayout());

    GridBagConstraints gbc = new GridBagConstraints();

    JLabel lblHola = new JLabel("Hola");
    lblHola.setOpaque(true);
    lblHola.setBackground(Color.RED);
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 1;
    gbc.gridheight = 1;
    gbc.weightx = 0;
    gbc.weighty = 0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.CENTER;
    gbc.insets = new Insets(0, 0, 0, 0);
    ret.add(lblHola, gbc);

    JLabel lblMundo = new JLabel("Mundo");
    lblMundo.setOpaque(true);
    lblMundo.setBackground(Color.BLUE);
    gbc.gridx = 1;
    gbc.gridy = 0;
    gbc.gridwidth = 1;
    gbc.gridheight = 1;
    gbc.weightx = 0;
    gbc.weighty = 0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.EAST;
    gbc.insets = new Insets(0, 0, 0, 0);
    ret.add(lblMundo, gbc);

    JButton btnEstoEsUnBoton = new JButton("Esto Es Un Boton");
    btnEstoEsUnBoton.setBackground(Color.YELLOW);
    gbc.gridx = 0;
    gbc.gridy = 1;
    gbc.gridwidth = 2;
    gbc.gridheight = 1;
    gbc.weightx = 1;
    gbc.weighty = 0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.CENTER;
    gbc.insets = new Insets(0, 0, 0, 0);
    ret.add(btnEstoEsUnBoton, gbc);

    JTextField txtEjemplo = new JTextField("Hola Mundo");
    gbc.gridx = 2;
    gbc.gridy = 0;
    gbc.gridwidth = 1;
    gbc.gridheight = 3;
    gbc.weightx = 0;
    gbc.weighty = 1;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.CENTER;
    gbc.insets = new Insets(15, 15, 15, 15);
    ret.add(txtEjemplo, gbc);

    JPanel pnl1 = new JPanel(new FlowLayout());

    JCheckBox chkEjemplo = new JCheckBox("Un Check Box");
    chkEjemplo.setOpaque(true);
    chkEjemplo.setBackground(Color.GREEN);
    //		gbc.gridx = 0;
    //		gbc.gridy = 2;
    //		gbc.gridwidth = 1;
    //		gbc.gridheight = 1;
    //		gbc.weightx = 1;
    //		gbc.weighty = 0;
    //		gbc.fill = GridBagConstraints.NONE;
    //		gbc.anchor = GridBagConstraints.CENTER;
    //		gbc.insets = new Insets(0, 0, 0, 0);
    //		ret.add(chkEjemplo, gbc);
    pnl1.add(chkEjemplo);

    JComboBox cboCombo = new JComboBox(new Object[]{"Uno", "Dos", "Tres", "etc..."});
    gbc.gridx = 1;
    gbc.gridy = 2;
    gbc.gridwidth = 1;
    gbc.gridheight = 1;
    gbc.weightx = 0;
    gbc.weighty = 0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.NORTH;
    gbc.insets = new Insets(0, 0, 0, 0);
    ret.add(cboCombo, gbc);
    pnl1.add(cboCombo);

    gbc.gridx = 1;
    gbc.gridy = 2;
    gbc.gridwidth = 1;
    gbc.gridheight = 1;
    gbc.weightx = 0;
    gbc.weighty = 0;
    gbc.fill = GridBagConstraints.BOTH;
    gbc.anchor = GridBagConstraints.NORTH;
    gbc.insets = new Insets(0, 0, 0, 0);
    ret.add(pnl1, gbc);

    //		ret.add(cboCombo);

    return ret;
  }

  /**
   *
   *
   * @param args
   */
  public static void main(String[] args) throws Exception {
    Test5 t5 = new Test5();

    JFrame frm = new JFrame();

    frm.getContentPane().add(t5.initPanel());

    frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frm.setSize(300, 300);
    frm.setVisible(true);

  }
}