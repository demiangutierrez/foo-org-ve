/**
 * @author DMI: Demian Gutierrez
 */
package com.minotauro.acuarela.test.nogui.c;

import com.minotauro.acuarela.test.nogui.BaseSimpleTest;

/*
 * Created on Aug 25, 2007
 */
public class TestC6 extends BaseSimpleTest {

  // Canvas W < paint W (cH = pH)
  public void test() throws Exception {
    cW = 600;
    cH = 600;
    pW = 1180;
    pH = 1180;
    zoom = 2;

    // tpX1 = 600; // View/Red
    // tpY1 = 600; // View/Red

    execute();
    assertTrue(compare());
  }
}
