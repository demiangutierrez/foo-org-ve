/*
 * Created on Sep 27, 2003
 */
package com.minotauro.acuarela.base;

import java.awt.Point;
import java.awt.Shape;

import com.minotauro.acuarela.event.AMotionEvent;
import com.minotauro.acuarela.event.AMotionException;
import com.minotauro.acuarela.util.AConfig;
import com.minotauro.acuarela.util.ADist;
import com.minotauro.acuarela.util.ARect;

/**
 * @author DMI: Demian Gutierrez
 */
public class ACtrlPoint extends AControllerImpl {

  protected static int nextCtrlPointName = 0;

  protected static String defaultCtrlPointName() {
    synchronized (ACtrlPoint.class) {
      return Integer.toString(nextCtrlPointName++);
    }
  }

  // ----------------------------------------

  protected int x;
  protected int y;
  protected int w;
  protected int h;

  // ----------------------------------------

  public ACtrlPoint() {
    name = ACtrlPoint.defaultCtrlPointName();

    w = AConfig.getIntegerProperty(getClass().getName() + ".w");
    h = AConfig.getIntegerProperty(getClass().getName() + ".h");

    movable = true;
  }

  public ACtrlPoint(int x, int y) {
    name = ACtrlPoint.defaultCtrlPointName();

    this.x = x;
    this.y = y;

    w = AConfig.getIntegerProperty(getClass().getName() + ".w");
    h = AConfig.getIntegerProperty(getClass().getName() + ".h");

    movable = true;
  }

  public ACtrlPoint(int x, int y, int w, int h) {
    name = ACtrlPoint.defaultCtrlPointName();

    this.x = x;
    this.y = y;

    this.w = w;
    this.h = h;

    movable = true;
  }

  // --------------------------------------------------------------------------------
  // AController methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public void initController() {
    // Empty
  }

  /**
   *
   */
  public void attachController() {
    // Empty
  }

  /**
   *
   */
  public void detachController() {
    // Empty
  }

  // --------------------------------------------------------------------------------
  // AControllerImpl methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public Shape getShape() {
    return new ARect(x - (w / 2), y - (h / 2), w, h);
  }

  /**
   *
   */
  public Point getJoint(AController controller) {
    return new Point(x, y);
  }

  // --------------------------------------------------------------------------------
  // Move methods
  // --------------------------------------------------------------------------------

  /**
   *
   */
  public void move(int dx, int dy, AMotionEvent evt) throws AMotionException {
    if (evt.getController(this) != null) {
      return;
    }

    x += dx;
    y += dy;

    evt.addController(this, new ADist(dx, dy));

    fireMotionEvent(evt);
  }

  // --------------------------------------------------------------------------------
  // Properties methods
  //
  // Properties are:
  //
  // x
  // y
  // w
  // h
  // --------------------------------------------------------------------------------

  /**
   *
   *
   * @return
   */
  public int getX() {
    return x;
  }

  /**
   *
   *
   * @param x
   */
  public void setX(int x) {
    this.x = x;
  }

  // --------------------------------------------------------------------------------

  /**
   *
   *
   * @return
   */
  public int getY() {
    return y;
  }

  /**
   *
   *
   * @param y
   */
  public void setY(int y) {
    this.y = y;
  }

  // --------------------------------------------------------------------------------

  /**
   *
   *
   * @return
   */
  public int getW() {
    return w;
  }

  /**
   *
   *
   * @param w
   */
  public void setW(int w) {
    this.w = w;
  }

  // --------------------------------------------------------------------------------

  /**
   *
   *
   * @return
   */
  public int getH() {
    return h;
  }

  /**
   *
   *
   * @param h
   */
  public void setH(int h) {
    this.h = h;
  }

  @Override
  public String toString() {
    StringBuffer ret = new StringBuffer();

    ret.append("(");
    ret.append(name);
    ret.append(",");
    ret.append(x);
    ret.append(",");
    ret.append(y);
    ret.append(")");

    return ret.toString();
  }
}