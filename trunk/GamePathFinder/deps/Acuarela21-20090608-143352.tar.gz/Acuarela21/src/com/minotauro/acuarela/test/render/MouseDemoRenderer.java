/*
 * Created on Dec 30, 2004
 */
package com.minotauro.acuarela.test.render;

import java.awt.Color;
import java.awt.Graphics2D;


import com.minotauro.acuarela.base.AController;
import com.minotauro.acuarela.base.ARenderer;
import com.minotauro.acuarela.test.controllers.MouseDemoController;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class MouseDemoRenderer extends ARenderer
{
	/**
	 *
	 */
	public MouseDemoRenderer()
	{
		// Empty
	}

	/**
	 *
	 */
	public void paint(Graphics2D g2d, AController controller)
	{
		MouseDemoController mouseDemoController = (MouseDemoController) controller;

		if (mouseDemoController.isInsideCanvas())
		{
			g2d.setColor(Color.BLUE);
		}
		else
		{
			g2d.setColor(Color.RED);
		}

		if (mouseDemoController.isInsideController())
		{
			g2d.setColor(Color.GREEN);
		}

		g2d.fill(mouseDemoController.getBounds());

		g2d.setColor(Color.BLACK);
		g2d.draw(mouseDemoController.getBounds());
	}
}