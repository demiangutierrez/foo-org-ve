/*
 * Created on Dec 18, 2004
 */
package com.minotauro.acuarela.event;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class AControllerMouseAdapter implements AControllerMouseListener
{
	/**
	 * 
	 */
	public AControllerMouseAdapter()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// AControllerMouseListener
	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public void controllerMouseClicked(AControllerMouseEvent evt)
	{
		// Empty
	}

	/**
	 *
	 */
	public void controllerMouseEntered(AControllerMouseEvent evt)
	{
		// Empty
	}

	/**
	 *
	 */
	public void controllerMouseExited(AControllerMouseEvent evt)
	{
		// Empty
	}

	/**
	 *
	 */
	public void controllerMousePressed(AControllerMouseEvent evt)
	{
		// Empty
	}

	/**
	 *
	 */
	public void controllerMouseReleased(AControllerMouseEvent evt)
	{
		// Empty
	}

	/**
	 *
	 */
	public void controllerMouseDragged(AControllerMouseEvent evt)
	{
		// Empty
	}

	/**
	 *
	 */
	public void controllerMouseMoved(AControllerMouseEvent evt)
	{
		// Empty
	}
}