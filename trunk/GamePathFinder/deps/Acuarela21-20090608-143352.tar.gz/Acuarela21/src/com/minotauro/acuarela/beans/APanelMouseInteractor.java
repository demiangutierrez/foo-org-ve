/*
 * Created on Dec 19, 2004
 */
package com.minotauro.acuarela.beans;

import java.util.EventListener;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public abstract class APanelMouseInteractor implements EventListener {

  public static final int PANEL_MOUSE_CLICKED = 0;

  public static final int PANEL_MOUSE_ENTERED = 1;

  public static final int PANEL_MOUSE_EXITED = 2;

  public static final int PANEL_MOUSE_PRESSED = 3;

  public static final int PANEL_MOUSE_RELEASED = 4;

  public static final int PANEL_MOUSE_DRAGGED = 5;

  public static final int PANEL_MOUSE_MOVED = 6;

  // --------------------------------------------------------------------------------

  private String name;

  /**
   *
   *
   * @param name
   */
  public APanelMouseInteractor(String name) {
    this.name = name;
  }

  // --------------------------------------------------------------------------------

  /**
   *
   *
   * @return
   */
  public String getName() {
    return name;
  }

  // --------------------------------------------------------------------------------

  public abstract void attachPanelMouseInteractor(ASwingPanel swingPanel);

  public abstract void detachPanelMouseInteractor(ASwingPanel swingPanel);

  // --------------------------------------------------------------------------------

  public abstract void panelMouseClicked(APanelMouseEvent evt);

  /**
   *
   *
   * @param evt
   */
  public abstract void panelMouseEntered(APanelMouseEvent evt);

  /**
   *
   *
   * @param evt
   */
  public abstract void panelMouseExited(APanelMouseEvent evt);

  /**
   *
   *
   * @param evt
   */
  public abstract void panelMousePressed(APanelMouseEvent evt);

  /**
   *
   *
   * @param evt
   */
  public abstract void panelMouseReleased(APanelMouseEvent evt);

  /**
   *
   *
   * @param evt
   */
  public abstract void panelMouseDragged(APanelMouseEvent evt);

  /**
   *
   *
   * @param evt
   */
  public abstract void panelMouseMoved(APanelMouseEvent evt);
}