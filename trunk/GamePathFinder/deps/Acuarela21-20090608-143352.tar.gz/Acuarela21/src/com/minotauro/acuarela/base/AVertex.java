/*
 * Created on Jul 18, 2004
 */
package com.minotauro.acuarela.base;

import org.cyrano.graph.label.LabelVertex;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface AVertex extends AController, LabelVertex
{
	// Empty
}
