/*
 * Created on Aug 14, 2004
 */
package com.minotauro.acuarela.test;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;

import com.minotauro.acuarela.base.ACanvas;
import com.minotauro.acuarela.base.ACanvasFactory;
import com.minotauro.acuarela.base.ACtrlPoint;
import com.minotauro.acuarela.beans.ASwingPanel;
import com.minotauro.acuarela.controllers.ARectangle;
import com.minotauro.acuarela.render.AShapeDebugRenderer;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class Test4 extends JFrame {
  private ASwingPanel swingPanel;

  /**
   *
   */
  public Test4() {
    initGUI();

    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(640, 480);
    setVisible(true);
  }

  /**
   *
   */
  private void initGUI() {
    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(initToolBar(), BorderLayout.NORTH);
    getContentPane().add(initAcuarela(), BorderLayout.CENTER);
  }

  /**
   *
   *
   * @return
   */
  private JToolBar initToolBar() {
    JToolBar ret = new JToolBar();
    ret.setFloatable(false);

    JButton btnZoomIn = new JButton("+");
    btnZoomIn.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        double zoom = swingPanel.getZoom();

        double delta;

        if (zoom >= 1) {
          delta = 1;
        } else if (zoom >= 0.25) {
          delta = 0.25;
        } else {
          delta = 0.10;
        }

        if (zoom + delta <= 4) {
          swingPanel.setZoom(zoom + delta);
        }
      }
    });
    ret.add(btnZoomIn);

    JButton btnZoomOut = new JButton("-");
    btnZoomOut.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        double zoom = swingPanel.getZoom();

        double delta;

        if (zoom > 1) {
          delta = 1;
        } else if (zoom > 0.25) {
          delta = 0.25;
        } else {
          delta = 0.10;
        }

        if (zoom - delta >= 0.01) {
          swingPanel.setZoom(zoom - delta);
        }
      }
    });
    ret.add(btnZoomOut);

    return ret;
  }

  /**
   *
   *
   * @return
   */
  private JScrollPane initAcuarela() {
    ACanvas canvas = new ACanvas(new ACanvasFactory());
    //    canvas.setW(5000);
    //    canvas.setH(5000);
    canvas.setMinX(0);
    canvas.setMinY(0);
    canvas.setMaxX(5000);
    canvas.setMaxY(5000);

    swingPanel = new ASwingPanel(canvas);
    swingPanel.addPanelMouseInteractor(new MoveInteractor());
    swingPanel.addPanelMouseInteractor(new SelectionInteractor());

    for (int i = 0; i < canvas.getW() / 110; i++) {
      for (int j = 0; j < canvas.getH() / 110; j++) {
        ACtrlPoint ctrlBeg = new ACtrlPoint(i * 110, j * 110);
        ACtrlPoint ctrlEnd = new ACtrlPoint(i * 110 + 100, j * 110 + 100);
        ARectangle rectangle = new ARectangle(ctrlBeg, ctrlEnd);
        rectangle.setName(i + ";" + j);
        //				rectangle.initObject();
        rectangle.addRenderer(new AShapeDebugRenderer());
        rectangle.setVisible(true);
        canvas.addController(rectangle);
      }
    }

    return new JScrollPane(swingPanel);
  }

  /**
   *
   *
   * @param args
   */
  public static void main(String[] args) {
    new Test4();
  }
}