/*
 * Created on Jun 6, 2004
 */
package com.minotauro.acuarela.event;

import java.util.EventObject;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class ARepaintEvent extends EventObject
{
	/**
	 *
	 *
	 * @param source
	 */
	public ARepaintEvent(Object source)
	{
		super(source);
	}
}
