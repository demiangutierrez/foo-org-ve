/*
 * Created on Jul 18, 2004
 */
package com.minotauro.acuarela.base;

import org.cyrano.graph.label.LabelEdge;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface AEdge extends AController, LabelEdge
{
	// Empty
}
