/*
 * Created on Sep 28, 2003
 */
package com.minotauro.acuarela.controllers;


/**
 * @author DMI: Demian Gutierrez
 */
public class ACircle {
//  extends AControllerImpl {
//
//
//  /**
//   *
//   */
//  public ACircle() {
//    // Empty
//  }
//
//  /**
//   *
//   */
//  public ACircle(int x1, int y1, int x2, int y2) {
//    init(new ACtrlPoint(x1, y1), new ACtrlPoint(x2, y2));
//  }
//
//  /**
//   *
//   */
//  public ACircle(ACtrlPoint ctrlBeg, ACtrlPoint ctrlEnd) {
//    super(ctrlBeg, ctrlEnd);
//  }
//
//  /**
//   *
//   */
//  public void init(ACtrlPoint ctrlBeg, ACtrlPoint ctrlEnd) {
//    super.init(ctrlBeg, ctrlEnd);
//  }
//
//  // --------------------------------------------------------------------------------
//  // AObjectImpl methods
//  // --------------------------------------------------------------------------------
//
//  //	/**
//  //	 *
//  //	 */
//  //	public void initObject() {
//  //		super.initObject();
//  //
//  //		ctrlBeg.setDisable(true);
//  //	}
//  //
//  //	/**
//  //	 *
//  //	 */
//  //	public ARect getBounds() {
//  //		return ARect.r(getShape().getBounds());
//  //	}
//  //
//  //	/**
//  //	 *
//  //	 */
//  //	public Shape getShape() {
//  //		int dx = ctrlEnd.getX() - ctrlBeg.getX();
//  //		int dy = ctrlEnd.getY() - ctrlBeg.getY();
//  //
//  //		double d = Math.sqrt((dx * dx) + (dy * dy));
//  //
//  //		Ellipse2D.Double ret = new Ellipse2D.Double();
//  //
//  //		ret.x = ctrlBeg.getX() - d;
//  //		ret.y = ctrlBeg.getY() - d;
//  //
//  //		ret.width = 2 * d;
//  //		ret.height = 2 * d;
//  //
//  //		return ret;
//  //	}
//  //
//  //	/**
//  //	 *
//  //	 */
//  //	public Point getJoint(double angle) {
//  //		Point ret = new Point();
//  //
//  //		ARect r = getBounds();
//  //		double x = r.x + r.getW2();
//  //		double y = r.y + r.getH2();
//  //
//  //		int dx = ctrlEnd.getX() - ctrlBeg.getX();
//  //		int dy = ctrlEnd.getY() - ctrlBeg.getY();
//  //
//  //		double d = Math.sqrt((dx * dx) + (dy * dy));
//  //
//  //		ret.x = (int) (x + (d * Math.cos(angle)));
//  //		ret.y = (int) (y - (d * Math.sin(angle)));
//  //
//  //		return ret;
//  //	}
//
//  // --------------------------------------------------------------------------------
//  // AController methods
//  // --------------------------------------------------------------------------------
//
//  /**
//   *
//   */
//  public void initController() {
//    addCtrlPoint(ctrlBeg);
//    addCtrlPoint(ctrlEnd);
//
//    addCtrlPoint(ctrlBegAux);
//    addCtrlPoint(ctrlEndAux);
//
//    ctrlBeg.addMotionListener(new AMotionListener() {
//      public void controllerMoved(AMotionEvent evt) throws AMotionException {
//        ctrlBegAux.setX(ctrlBeg.getX());
//        ctrlEndAux.setY(ctrlBeg.getY());
//      }
//    });
//
//    ctrlEnd.addMotionListener(new AMotionListener() {
//      public void controllerMoved(AMotionEvent evt) throws AMotionException {
//        ctrlBegAux.setY(ctrlEnd.getY());
//        ctrlEndAux.setX(ctrlEnd.getX());
//      }
//    });
//
//    ctrlBegAux.addMotionListener(new AMotionListener() {
//      public void controllerMoved(AMotionEvent evt) throws AMotionException {
//        ctrlBeg.setX(ctrlBegAux.getX());
//        ctrlEnd.setY(ctrlBegAux.getY());
//      }
//    });
//
//    ctrlEndAux.addMotionListener(new AMotionListener() {
//      public void controllerMoved(AMotionEvent evt) throws AMotionException {
//        ctrlBeg.setY(ctrlEndAux.getY());
//        ctrlEnd.setX(ctrlEndAux.getX());
//      }
//    });
//  }
//
//  /**
//   *
//   */
//  public void attachController() {
//    // Empty
//  }
//
//  /**
//   *
//   */
//  public void detachController() {
//    // Empty
//  }
//
//  /**
//   *
//   */
//  public Shape getShape() {
//    ARect ret = new ARect();
//
//    ret.x = (ctrlBeg.getX() < ctrlEnd.getX()) ? ctrlBeg.getX() : ctrlEnd.getX();
//    ret.y = (ctrlBeg.getY() < ctrlEnd.getY()) ? ctrlBeg.getY() : ctrlEnd.getY();
//
//    ret.setW(Math.abs(ctrlEnd.getX() - ctrlBeg.getX()));
//    ret.setH(Math.abs(ctrlEnd.getY() - ctrlBeg.getY()));
//
//    return ret;
//  }
//
//  /**
//   *
//   */
//  public Point getJoint(AController controller) {
//    return null;
//  }

}