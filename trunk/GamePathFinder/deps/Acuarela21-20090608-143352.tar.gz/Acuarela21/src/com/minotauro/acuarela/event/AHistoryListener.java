/*
 * Created on Dec 18, 2004
 */
package com.minotauro.acuarela.event;

import java.util.EventListener;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public interface AHistoryListener extends EventListener
{
	/**
	 *
	 *
	 * @param evt
	 */
	public void historyChanged(AHistoryEvent evt);
}