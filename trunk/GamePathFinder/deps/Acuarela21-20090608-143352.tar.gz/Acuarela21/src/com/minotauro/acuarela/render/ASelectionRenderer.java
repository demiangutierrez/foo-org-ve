/*
 * Created on Dec 19, 2004
 */
package com.minotauro.acuarela.render;

import java.awt.Color;
import java.awt.Graphics2D;


import com.minotauro.acuarela.base.ACanvas;
import com.minotauro.acuarela.base.AController;
import com.minotauro.acuarela.event.APaintAdapter;
import com.minotauro.acuarela.event.APaintEvent;
import com.minotauro.acuarela.util.ARect;

/**
 * @author Demian Gutierrez
 */
public class ASelectionRenderer extends APaintAdapter {

  public ASelectionRenderer() {
    // Empty
  }

  @Override
  public void prePaint(APaintEvent evt) {
    ACanvas canvas = (ACanvas) evt.getSource();

    Graphics2D g2d = evt.getGraphics2D();

    ARect selRect = null;

    AController[] controllers = canvas.toSelectedArray();

    if (controllers.length == 1) {
      return;
    }

    for (AController controller : controllers) {
      if (selRect == null) {
        selRect = controller.getBounds();
      } else {
        selRect.add(controller.getBounds());
      }
    }

    if (selRect == null) {
      return;
    }

    g2d.setColor(Color.BLACK);
    g2d.draw(selRect);
  }
}