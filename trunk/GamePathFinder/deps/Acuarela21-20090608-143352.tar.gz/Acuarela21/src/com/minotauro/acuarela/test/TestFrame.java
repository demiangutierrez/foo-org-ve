/*
 * Created on Dec 30, 2004
 */
package com.minotauro.acuarela.test;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;


import com.minotauro.acuarela.base.ACanvas;
import com.minotauro.acuarela.base.AController;
import com.minotauro.acuarela.beans.ASwingPanel;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public abstract class TestFrame extends JFrame {
  protected ASwingPanel aSwingPanel;

  /**
   *
   */
  public TestFrame() {
    initGUI();

    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(1024, 768);
    setVisible(true);
  }

  /**
   *
   */
  private void initGUI() {
    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(initToolBar(), BorderLayout.NORTH);

    aSwingPanel = initSwingPanel();

    Dimension count = countControllers(aSwingPanel.getCanvas());
    System.err.println("RC: " + count.width + "/ CC: " + count.height + " / TC: " + (count.width + count.height));

    Runtime runtime = Runtime.getRuntime();
    System.err.println("FM: " + (runtime.freeMemory() / 1024 / 1024) + "MB / MM: "
        + (runtime.maxMemory() / 1024 / 1024) + "MB / TM: " + (runtime.totalMemory() / 1024 / 1024) + "MB");

    getContentPane().add(new JScrollPane(aSwingPanel), BorderLayout.CENTER);
  }

  /**
   *
   *
   * @return
   */
  protected JToolBar initToolBar() {
    JToolBar ret = new JToolBar();
    ret.setFloatable(false);

    ImageIcon icon = new ImageIcon(getClass().getResource("icons/zoom_out.png"));
    JButton btnZoomOut = new JButton(icon);
    btnZoomOut.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        double zoom = aSwingPanel.getZoom();

        if (zoom >= 0.25) {
          System.err.println("Set zoom to " + zoom / 2);
          aSwingPanel.setZoom(zoom / 2);
          aSwingPanel.repaint();
        }
      }
    });
    ret.add(btnZoomOut);

    icon = new ImageIcon(getClass().getResource("icons/zoom_in.png"));
    JButton btnZoomIn = new JButton(icon);
    btnZoomIn.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        double zoom = aSwingPanel.getZoom();

        if (zoom <= 8) {
          System.err.println("Set zoom to " + zoom * 2);
          aSwingPanel.setZoom(zoom * 2);
          aSwingPanel.repaint();
        }
      }
    });
    ret.add(btnZoomIn);

    return ret;
  }

  /**
   * width = root
   * height = child
   *
   * @param aCanvas
   * @return
   */
  public Dimension countControllers(ACanvas aCanvas) {
    int root = 0;
    int child = 0;

    Iterator itt = aCanvas.controllerIterator();

    while (itt.hasNext()) {
      AController aController = (AController) itt.next();

      root++;
      child += countControllers(aController);
    }

    // Count only children (child - root)
    return new Dimension(root, child - root);
  }

  /**
   *
   *
   * @param aController
   * @return
   */
  public int countControllers(AController aController) {
    // Count this too
    int child = 1;

    Iterator itt = aController.controllerIterator();

    while (itt.hasNext()) {
      AController aControllerChild = (AController) itt.next();

      child += countControllers(aControllerChild);
    }

    return child;
  }

  /**
   *
   *
   * @return
   */
  protected abstract ASwingPanel initSwingPanel();
}