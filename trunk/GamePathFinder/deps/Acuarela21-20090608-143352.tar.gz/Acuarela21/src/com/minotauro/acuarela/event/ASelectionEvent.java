/*
 * Created on Nov 23, 2003
 */
package com.minotauro.acuarela.event;

import java.util.EventObject;

import com.minotauro.acuarela.base.AController;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class ASelectionEvent extends EventObject
{
	private AController controller;

	private AController[] context;

	/**
	 *
	 *
	 * @param source
	 * @param controller
	 * @param context
	 */
	public ASelectionEvent(Object source, AController controller, AController[] context)
	{
		super(source);

		this.controller = controller;
		this.context = context;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public AController getController()
	{
		return controller;
	}

	/**
	 *
	 *
	 * @param controller
	 */
	public void setController(AController controller)
	{
		this.controller = controller;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public AController[] getContext()
	{
		return context;
	}

	/**
	 *
	 *
	 * @param controllers
	 */
	public void setContext(AController[] controllers)
	{
		context = controllers;
	}
}
