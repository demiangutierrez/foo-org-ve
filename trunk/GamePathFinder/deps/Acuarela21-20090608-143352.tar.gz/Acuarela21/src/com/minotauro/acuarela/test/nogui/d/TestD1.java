/**
 * @author DMI: Demian Gutierrez
 */
package com.minotauro.acuarela.test.nogui.d;

import com.minotauro.acuarela.test.nogui.BaseSimpleTest;

/*
 * Created on Aug 25, 2007
 */
public class TestD1 extends BaseSimpleTest {

  // Canvas W/H < paint W/H
  public void test() throws Exception {
    cW = 600;
    cH = 600;
    despX = -cW / 2;
    despY = -cH / 2;
    pW = 800;
    pH = 800;
    execute();
    assertTrue(compare());
  }
}
