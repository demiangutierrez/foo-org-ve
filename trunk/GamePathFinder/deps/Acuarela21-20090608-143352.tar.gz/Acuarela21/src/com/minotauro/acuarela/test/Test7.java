/*
 * Created on Dec 30, 2004
 */
package com.minotauro.acuarela.test;

import com.minotauro.acuarela.base.ACanvas;
import com.minotauro.acuarela.base.ACanvasFactory;
import com.minotauro.acuarela.base.ACtrlPoint;
import com.minotauro.acuarela.beans.ASwingPanel;
import com.minotauro.acuarela.test.controllers.MouseDemoController;
import com.minotauro.acuarela.test.render.MouseDemoRenderer;

/**
 * @author DMI: Demian Gutierrez
 */
public class Test7 extends TestFrame {
  /**
   *
   */
  public Test7() {
    // Empty
  }

  /**
   *
   */
  protected ASwingPanel initSwingPanel() {
    ACanvas canvas = new ACanvas(new ACanvasFactory());
    //    canvas.setW(5000);
    //    canvas.setH(5000);
    canvas.setMinX(0);
    canvas.setMinY(0);
    canvas.setMaxX(5000);
    canvas.setMaxY(5000);

    ASwingPanel ret = new ASwingPanel(canvas);
    ret.addPanelMouseInteractor(new MoveInteractor());
    ret.addPanelMouseInteractor(new SelectionInteractor());

    for (int i = 0; i < canvas.getW() / 110; i++) {
      for (int j = 0; j < canvas.getH() / 110; j++) {
        ACtrlPoint ctrlBeg = new ACtrlPoint(i * 110, j * 110);
        ACtrlPoint ctrlEnd = new ACtrlPoint(i * 110 + 100, j * 110 + 100);

        MouseDemoController aSwingContainer = new MouseDemoController(ctrlBeg, ctrlEnd);

        aSwingContainer.setName(i + ";" + j);
        aSwingContainer.addRenderer(new MouseDemoRenderer());
        aSwingContainer.setVisible(true);

        canvas.addController(aSwingContainer);
      }
    }
    return ret;
  }

  /**
   *
   *
   * @return
   */
  //  private JPanel initPanel() {
  //    // XXX: All containers must have double buffered set to false
  //    JPanel ret = new JPanel(new GridBagLayout());
  //    ret.setDoubleBuffered(false);
  //
  //    GridBagConstraints gbc = new GridBagConstraints();
  //
  //    JLabel lblHola = new JLabel("Hola");
  //    lblHola.setOpaque(true);
  //    lblHola.setBackground(Color.RED);
  //    gbc.gridx = 0;
  //    gbc.gridy = 0;
  //    gbc.gridwidth = 1;
  //    gbc.gridheight = 1;
  //    gbc.weightx = 0;
  //    gbc.weighty = 0;
  //    gbc.fill = GridBagConstraints.BOTH;
  //    gbc.anchor = GridBagConstraints.CENTER;
  //    gbc.insets = new Insets(0, 0, 0, 0);
  //    ret.add(lblHola, gbc);
  //
  //    JLabel lblMundo = new JLabel("Mundo");
  //    lblMundo.setOpaque(true);
  //    lblMundo.setBackground(Color.BLUE);
  //    gbc.gridx = 1;
  //    gbc.gridy = 0;
  //    gbc.gridwidth = 1;
  //    gbc.gridheight = 1;
  //    gbc.weightx = 0;
  //    gbc.weighty = 0;
  //    gbc.fill = GridBagConstraints.BOTH;
  //    gbc.anchor = GridBagConstraints.EAST;
  //    gbc.insets = new Insets(0, 0, 0, 0);
  //    ret.add(lblMundo, gbc);
  //
  //    JButton btnEstoEsUnBoton = new JButton("Esto Es Un Boton");
  //    btnEstoEsUnBoton.setBackground(Color.YELLOW);
  //    gbc.gridx = 0;
  //    gbc.gridy = 1;
  //    gbc.gridwidth = 2;
  //    gbc.gridheight = 1;
  //    gbc.weightx = 1;
  //    gbc.weighty = 0;
  //    gbc.fill = GridBagConstraints.BOTH;
  //    gbc.anchor = GridBagConstraints.CENTER;
  //    gbc.insets = new Insets(0, 0, 0, 0);
  //    ret.add(btnEstoEsUnBoton, gbc);
  //
  //    JTextField txtEjemplo = new JTextField("Hola Mundo");
  //    gbc.gridx = 2;
  //    gbc.gridy = 0;
  //    gbc.gridwidth = 1;
  //    gbc.gridheight = 3;
  //    gbc.weightx = 0;
  //    gbc.weighty = 1;
  //    gbc.fill = GridBagConstraints.BOTH;
  //    gbc.anchor = GridBagConstraints.CENTER;
  //    gbc.insets = new Insets(15, 15, 15, 15);
  //    ret.add(txtEjemplo, gbc);
  //
  //    JPanel pnlSouth = new JPanel(new FlowLayout());
  //    pnlSouth.setDoubleBuffered(false);
  //    gbc.gridx = 1;
  //    gbc.gridy = 2;
  //    gbc.gridwidth = 1;
  //    gbc.gridheight = 1;
  //    gbc.weightx = 0;
  //    gbc.weighty = 0;
  //    gbc.fill = GridBagConstraints.BOTH;
  //    gbc.anchor = GridBagConstraints.NORTH;
  //    gbc.insets = new Insets(0, 0, 0, 0);
  //    ret.add(pnlSouth, gbc);
  //
  //    JCheckBox chkEjemplo = new JCheckBox("Un Check Box");
  //    chkEjemplo.setOpaque(true);
  //    chkEjemplo.setBackground(Color.GREEN);
  //    pnlSouth.add(chkEjemplo);
  //
  //    JComboBox cboCombo = new JComboBox(new Object[]{"Uno", "Dos", "Tres", "etc..."});
  //    pnlSouth.add(cboCombo);
  //
  //    return ret;
  //  }
  /**
   *
   *
   * @param args
   */
  public static void main(String[] args) {
    new Test7();
  }
}