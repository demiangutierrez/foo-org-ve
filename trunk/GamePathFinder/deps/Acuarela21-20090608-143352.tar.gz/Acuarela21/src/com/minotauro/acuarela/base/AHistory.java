/*
 * Created on Jul 18, 2004
 */
package com.minotauro.acuarela.base;

import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.event.EventListenerList;

import com.minotauro.acuarela.event.AHistoryEvent;
import com.minotauro.acuarela.event.AHistoryListener;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class AHistory
{
	private EventListenerList eventListenerList = new EventListenerList();

	private LinkedList redoList = new LinkedList();

	private LinkedList undoList = new LinkedList();

	/**
	 *
	 */
	public AHistory()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// AHistoryListener methods
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @param listener
	 */
	public void addHistoryListener(AHistoryListener listener)
	{
		eventListenerList.add(AHistoryListener.class, listener);
	}

	/**
	 *
	 *
	 * @param listener
	 */
	public void delHistoryListener(AHistoryListener listener)
	{
		eventListenerList.remove(AHistoryListener.class, listener);
	}

	/**
	 *
	 *
	 * @return
	 */
	public AHistoryListener[] getHistoryListeners()
	{
		return (AHistoryListener[]) eventListenerList.getListeners(AHistoryListener.class);
	}

	/**
	 *
	 */
	public void fireHistoryEvent(AHistoryEntry historyEntry, int action)
	{
		AHistoryEvent evt = new AHistoryEvent(this, historyEntry, action);

		AHistoryListener[] listener = getHistoryListeners();

		for (int i = 0; i < listener.length; i++)
		{
			listener[i].historyChanged(evt);
		}
	}

	// --------------------------------------------------------------------------------
	// AHistory
	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public boolean canRedo()
	{
		Iterator itt = redoList.iterator();

		while (itt.hasNext())
		{
			AHistoryEntry historyEntry = (AHistoryEntry) itt.next();

			if (historyEntry.canRedo())
			{
				return true;
			}
		}

		return false;
	}

	/**
	 *
	 *
	 * @return
	 */
	public boolean canUndo()
	{
		Iterator itt = undoList.iterator();

		while (itt.hasNext())
		{
			AHistoryEntry historyEntry = (AHistoryEntry) itt.next();

			if (historyEntry.canUndo())
			{
				return true;
			}
		}

		return false;
	}

	/**
	 *
	 */
	public void execute(AHistoryEntry historyEntry)
	{
		if (historyEntry.canExecute())
		{
			undoList.addFirst(historyEntry);

			historyEntry.execute();
			fireHistoryEvent(historyEntry, AHistoryEvent.ACTION_EXECUTE);
		}
	}

	/**
	 *
	 */
	public void redo()
	{
		if (canRedo())
		{
			AHistoryEntry historyEntry;

			do
			{
				historyEntry = (AHistoryEntry) redoList.removeFirst();
				undoList.addFirst(historyEntry);
			}
			while (historyEntry.canRedo());

			historyEntry.redo();
			fireHistoryEvent(historyEntry, AHistoryEvent.ACTION_REDO);
		}
	}

	/**
	 *
	 */
	public void undo()
	{
		if (canUndo())
		{
			AHistoryEntry historyEntry;

			do
			{
				historyEntry = (AHistoryEntry) undoList.removeFirst();
				redoList.addFirst(historyEntry);
			}
			while (historyEntry.canUndo());

			historyEntry.undo();
			fireHistoryEvent(historyEntry, AHistoryEvent.ACTION_UNDO);
		}
	}
}