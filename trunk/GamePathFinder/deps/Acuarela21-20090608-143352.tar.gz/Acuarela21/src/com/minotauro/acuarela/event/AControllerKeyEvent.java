/*
 * Created on Dec 18, 2004
 */
package com.minotauro.acuarela.event;

import java.awt.event.KeyEvent;
import java.util.EventObject;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class AControllerKeyEvent extends EventObject
{
	private KeyEvent keyEvent;

	/**
	 *
	 *
	 * @param source
	 * @param keyEvent
	 */
	public AControllerKeyEvent(Object source, KeyEvent keyEvent)
	{
		super(source);

		this.keyEvent = keyEvent;
	}

	// --------------------------------------------------------------------------------

	/**
	 *
	 *
	 * @return
	 */
	public KeyEvent getKeyEvent()
	{
		return keyEvent;
	}

	/**
	 *
	 *
	 * @param keyEvent
	 */
	public void setKeyEvent(KeyEvent keyEvent)
	{
		this.keyEvent = keyEvent;
	}
}