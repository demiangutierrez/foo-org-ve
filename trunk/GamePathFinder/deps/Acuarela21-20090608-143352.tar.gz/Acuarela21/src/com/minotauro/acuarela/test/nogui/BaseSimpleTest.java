/**
 * @author DMI: Demian Gutierrez
 */
package com.minotauro.acuarela.test.nogui;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Arrays;

import javax.imageio.ImageIO;

import junit.framework.TestCase;

import com.minotauro.acuarela.base.ACanvas;
import com.minotauro.acuarela.base.ACanvasFactory;
import com.minotauro.acuarela.util.ARect;

/*
 * Created on Aug 25, 2007
 */
public class BaseSimpleTest extends TestCase {

  protected String refName = getClass().getName().replace(".", "/") + ".png";
  protected String tstName = "test.png";

  protected int pX = 0;
  protected int pY = 0;
  protected int cW = 0;
  protected int cH = 0;
  protected int pW = 0;
  protected int pH = 0;

  protected int tpX1 = 300; // View/Red
  protected int tpY1 = 300; // View/Red
  protected int tcX2 = 400; // Canv/Blue
  protected int tcY2 = 400; // Canv/Blue

  protected int rfX1 = 10;
  protected int rfY1 = 10;

  protected int rfX2 = 540;
  protected int rfY2 = 540;

  protected int despX = 0;
  protected int despY = 0;

  protected double zoom = 1;

  public BaseSimpleTest() {
    // Empty
  }

  public boolean compare() throws Exception {
    System.err.println("refName:" + refName);
    System.err.println("tstName:" + tstName);

    InputStream is;

    is = new FileInputStream(tstName);
    byte[] data1 = new byte[(int) new File(tstName).length()];
    is.read(data1);

    is = ClassLoader.getSystemResourceAsStream(refName);
    byte[] data2 = new byte[(int) new File( //
        ClassLoader.getSystemResource(refName).getFile()).length()];
    is.read(data2);

    return Arrays.equals(data1, data2);
  }

  public void execute() throws Exception {
    tcX2 += despX;
    tcY2 += despY;

    rfX1 += despX;
    rfY1 += despY;

    rfX2 += despX;
    rfY2 += despY;

    ACanvas canvas = new ACanvas(new ACanvasFactory());
    canvas.setZoom(zoom);

    canvas.setMinX(despX);
    canvas.setMinY(despY);
    canvas.setMaxX(despX + cW);
    canvas.setMaxY(despX + cH);

    System.err.println("Canvas extends: (" //
        + canvas.getMinX() + ", " + canvas.getMinY() + "), (" //
        + canvas.getMaxX() + ", " + canvas.getMaxY() + ")");

    ARect rct = new ARect(pX, pY, pW, pH);

    System.err.println("View rect is: (" //
        + rct.x + ", " + rct.y + ", " //
        + rct.getW() + ", " + rct.getH() + ")");

    // ----------------------------------------
    // Add test controllers
    // ----------------------------------------

    ATest test;

    test = new ATest(rfX1, rfY1, rfX1 + 50, rfY1 + 50, Color.CYAN);
    canvas.addController(test);
    System.err.println("Top-Left ATest: " + test);

    // Should never be on the screen
    test = new ATest(rfX1 - 60, rfY1 - 60, rfX1 - 10, rfY1 - 10, Color.BLACK);
    canvas.addController(test);
    System.err.println("Top-Left ATest (Outside canvas): " + test);

    test = new ATest(rfX2, rfY2, rfX2 + 50, rfY2 + 50, Color.GREEN);
    canvas.addController(test);
    System.err.println("Bottom-Right ATest: " + test);

    // Should never be on the screen
    test = new ATest(rfX2 + 60, rfY2 + 60, rfX2 + 110, rfY2 + 110, Color.BLACK);
    canvas.addController(test);
    System.err.println("Bottom-Right ATest(Outside canvas): " + test);

    // ----------------------------------------
    // Add view to canvas test controllers
    // ----------------------------------------
    // RED
    // ----------------------------------------

    Point ptp1 = new Point(tpX1, tpY1);
    Point ptc1 = canvas.transViewToCanv(rct, ptp1);
    test = new ATest(ptc1.x, ptc1.y, ptc1.x + 50, ptc1.y + 50, Color.RED);
    canvas.addController(test);
    System.err.println("Red ATest: " + test);

    // ----------------------------------------
    // Add canvas to view test controllers
    // ----------------------------------------
    // BLUE
    // ----------------------------------------

    Point ptc2 = new Point(tcX2, tcY2);
    Point ptp2 = canvas.transCanvToView(rct, ptc2);
    test = new ATest(tcX2, tcY2, tcX2 + 50, tcY2 + 50, Color.BLUE);
    canvas.addController(test);
    System.err.println("Blue ATest: " + test);

    // ----------------------------------------
    // Draw all
    // ----------------------------------------

    BufferedImage bimg = canvas.getCanvasFactory().getBufferedImage(rct.getW(), rct.getH());
    Graphics2D g2d = (Graphics2D) bimg.getGraphics();
    canvas.paint(g2d, rct);

    // ----------------------------------------
    // Draw view to canvas reference
    // ----------------------------------------

    g2d.setColor(Color.RED);
    g2d.drawLine(ptp1.x - 50, ptp1.y, ptp1.x + 50, ptp1.y);
    g2d.drawLine(ptp1.x, ptp1.y - 50, ptp1.x, ptp1.y + 50);
    System.err.println("Red line: (" + ptp1.x + ", " + ptp1.y + ")");

    // ----------------------------------------
    // Draw canvas to view reference
    // ----------------------------------------

    g2d.setColor(Color.BLUE);
    g2d.drawLine(ptp2.x - 50, ptp2.y, ptp2.x + 50, ptp2.y);
    g2d.drawLine(ptp2.x, ptp2.y - 50, ptp2.x, ptp2.y + 50);
    System.err.println("Blue line: (" + ptp2.x + ", " + ptp2.y + ")");

    g2d.drawString(refName.substring(refName.lastIndexOf('/') + 1), 10, pH - 20);

    g2d.dispose();

    // ----------------------------------------
    // Write file
    // ----------------------------------------

    ImageIO.write(bimg, "png", new FileOutputStream(tstName));
  }
}
