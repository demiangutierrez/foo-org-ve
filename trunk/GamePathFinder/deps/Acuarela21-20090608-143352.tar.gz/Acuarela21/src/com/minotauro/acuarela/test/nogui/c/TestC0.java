/**
 * @author DMI: Demian Gutierrez
 */
package com.minotauro.acuarela.test.nogui.c;

import com.minotauro.acuarela.test.nogui.BaseSimpleTest;

/*
 * Created on Aug 25, 2007
 */
public class TestC0 extends BaseSimpleTest {

  // Canvas W/H = paint W/H
  public void test() throws Exception {
    cW = 600;
    cH = 600;
    pW = 1200;
    pH = 1200;
    zoom = 2;
    execute();
    assertTrue(compare());
  }
}
