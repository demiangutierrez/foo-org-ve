package com.minotauro.acuarela.test.nogui.a;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.apache.commons.lang.ClassUtils;

public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite(ClassUtils.getPackageName(AllTests.class));

    //$JUnit-BEGIN$
    suite.addTestSuite(TestA0.class);
    suite.addTestSuite(TestA1.class);
    suite.addTestSuite(TestA2.class);
    suite.addTestSuite(TestA3.class);
    suite.addTestSuite(TestA4.class);
    suite.addTestSuite(TestA5.class);
    suite.addTestSuite(TestA6.class);
    suite.addTestSuite(TestA7.class);
    suite.addTestSuite(TestA8.class);
    suite.addTestSuite(TestA9.class);
    //$JUnit-END$

    return suite;
  }
}
