/*
 * Created on Nov 23, 2003
 */
package com.minotauro.acuarela.event;

/**
 *
 *
 * @author DMI: Demian Gutierrez
 */
public class ASelectionAdapter implements ASelectionListener
{
	/**
	 *
	 */
	public ASelectionAdapter()
	{
		// Empty
	}

	// --------------------------------------------------------------------------------
	// ASelectionListener
	// --------------------------------------------------------------------------------

	/**
	 *
	 */
	public void selectionGained(ASelectionEvent evt)
	{
		// Empty
	}

	/**
	 *
	 */
	public void selectionLost(ASelectionEvent evt)
	{
		// Empty
	}
}
