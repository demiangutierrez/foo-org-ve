/*
 * Created on 04/02/2008
 */
package com.minotauro.state.demo.protocol;

import com.minotauro.state.generator.BaseSMMain;

/**
 * @author Demián Gutierrez
 */
public class Main extends BaseSMMain {

  public static void main(String[] args) throws Exception {
    Main m = new Main();

    m.stateMachine("global");
    m.stateMachine("client");
  }
}
